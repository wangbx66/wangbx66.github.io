# -*- coding: utf-8 -*-

Continents = {'Eastern Kingdoms': 0, 'Other': 1, 'Ouland': 2, 'The Great Sea': 3, 'Northrend': 4, 'Kalimdor': 5, 'Outland': 6}
Areas = {'Null': 0, 'Lordaeron': 1, 'Outland': 2, 'Khaz Modan': 3, 'Southern Kalimdor': 4, "Quel'Thalas": 5, 'Azeroth': 6, 'The Veiled Sea': 7, 'Northern Kalimdor': 8, 'Central Kalimdor': 9, 'Northrend': 10, 'The Forbidding Sea': 11}
Zonetypes = {'Sea': 0, 'Battleground': 1, 'Transit': 2, 'Dungeon': 3, 'City': 4, 'Event': 5, 'Arena': 6, 'Zone': 7}
Lords = {'PvP': 0, 'Sanctuary': 1, 'Horde': 2, 'Contested': 3, 'Alliance': 4}
