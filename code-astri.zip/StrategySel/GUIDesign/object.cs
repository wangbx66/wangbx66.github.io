﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUIDesign
{
    public class Bar
    {
        public DateTime TradeDate;
        public double OpenPrice;
        public double HighPrice;
        public double LowPrice;
        public double ClosePrice;
        public double Volume;
    }
}
