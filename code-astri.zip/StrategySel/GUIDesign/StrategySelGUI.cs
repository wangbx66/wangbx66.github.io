﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Microsoft.Win32;

using ModulusFE.TASDK;
using ModulusFE;

using CommonObjects;

using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;
using MathNet.Numerics;

using StrategySel;

namespace GUIDesign
{
    public partial class StrategySelectionForm : Form
    {
        private StockRNN modelForPredict;
        private Simulator simulator;
        System.IO.StreamWriter logger = new System.IO.StreamWriter(@"logging.txt");
        int[] networkArchitecture = new int[] { 3, 32, 64, 7 };
        string modelFileName = @"model.pdat";

        //private PeriodicDBLoader.OnPercentChangeCall showPercent = delegate(int percent)
        private void showPercent(int percent)
        {
            statusLabel.Text = String.Format("{0}%", percent);
        }

        public StrategySelectionForm()
        {
            InitializeComponent();
        }

        private void StrategySelectionFormLoad(object sender, EventArgs e)
        {
            //for the maket combobox
            currentMarketBox.Items.Add("SSE");
            currentMarketBox.Items.Add("SZSE");
            currentMarketBox.Items.Add("ANY");
            string market = "SZSE";
            currentMarketBox.SelectedValue = market;
            currentMarketBox.Text = market;
            miscKeyBox.Items.Add("#E-Step");
            miscKeyBox.Items.Add("#T-Step");
            miscKeyBox.Items.Add("Batch Size");
            miscKeyBox.Items.Add("Rng Seed");
            miscKeyBox.Items.Add("Decay");
            miscKeyBox.Items.Add("Clip");
            miscKeyBox.Items.Add("#Max Epochs");
            miscKeyBox.Items.Add("#No-best Epochs");
            miscKeyBox.Items.Add("LR");
            miscKeyBox.Items.Add("Momentum");
            miscKeyBox.Items.Add("Loss");
            miscKeyBox.Items.Add("Log Path");
            miscKeyBox.Items.Add("Dropout");

            //checkedListBox1.Items.Add("All", CheckState.Unchecked);
            ToShowChecklist.Items.Add("Model Performance", CheckState.Unchecked);
            ToShowChecklist.Items.Add("Strategy Performance", CheckState.Unchecked);
            ToShowChecklist.Items.Add("Selection Statistics", CheckState.Unchecked);
            for (int i = 1; i < ToShowChecklist.Items.Count; i++)
            {
                ;
            }
            logger.WriteLine("form initialization finished");
            logger.Flush();

            simulator = new Simulator();
        }

        private void trainingButtonClick(object sender, EventArgs e)
        {
            if (simulator.strategies.Count == 0)
            {
                simulator.LoadDefault();
            }

            logger.WriteLine("trainingset dump begins");
            logger.Flush();

            Periodicity period = Periodicity.Daily;
            if (periodicityBox.Text.ToLower().StartsWith("daily"))
            {
                period = Periodicity.Daily;
            }
            if (periodicityBox.Text.ToLower().StartsWith("Minutely"))
            {
                period = Periodicity.Minutely;
            }

            TimeSpan seqSpan = TimeSpan.FromDays(365);
            string spanStr = seqSpanBox.Text;
            int number = Convert.ToInt32(Regex.Split(spanStr, " ")[0]);
            string unit = Regex.Split(spanStr, " ")[1];
            if (unit.ToLower().StartsWith("day"))
            {
                seqSpan = TimeSpan.FromDays(number);
            }
            else if (unit.ToLower().StartsWith("minute"))
            {
                seqSpan = TimeSpan.FromMinutes(number);
            }

            DateTime startPicker = trainStartTimePicker.Value;
            DateTime endPicker = trainEndTimePicker.Value;
            DateTime start = new DateTime(startPicker.Year, startPicker.Month, startPicker.Day, 8, 0, 0);
            DateTime end = new DateTime(endPicker.Year, endPicker.Month, endPicker.Day, 8, 0, 0);

            Dumper dumper = new Dumper
            {
                CommissionFeeNTax = Convert.ToDouble(commissionFeeNTaxBox.Text),
                CurrentMarket = currentMarketBox.Text,
                TotalSequences = Convert.ToInt32(totalSequencesBox.Text),
                name = nameBox.Text,
                seqSpan = seqSpan,
                period = period,
                simulator = simulator,
                Start = start,
                End = end,
                onPercentChangeCall = showPercent,
            };
            statusLabel.ResetText();
            dumper.TrainingDatasetDump();
            statusLabel.Text = "Available";

            logger.WriteLine("trainingset dump finished");
            logger.Flush();
        }

        private void predictButtonClick(object sender, EventArgs e)
        {
            logger.WriteLine("prediction begins");
            logger.Flush();
            string market = Regex.Split(symbolBox.Text, "-")[1];
            string symbol = Regex.Split(symbolBox.Text, "-")[0];
            List<string> symbols = new List<string>();
            symbols.Add(symbol);
            List<string> markets = new List<string>();
            markets.Add(market);
            DateTime startPicker = startDateTimePicker.Value;
            DateTime endPicker = endDateTimePicker.Value;
            DateTime start = new DateTime(startPicker.Year, startPicker.Month, startPicker.Day, 8, 0, 0);
            DateTime end = new DateTime(endPicker.Year, endPicker.Month, endPicker.Day, 8, 0, 0);
            loadModel(networkArchitecture, modelFileName);

            Periodicity period = Periodicity.Daily;
            if (periodicityBox.Text.ToLower().StartsWith("daily"))
            {
                period = Periodicity.Daily;
            }
            if (periodicityBox.Text.ToLower().StartsWith("Minutely"))
            {
                period = Periodicity.Minutely;
            }

            TimeSpan seqSpan = TimeSpan.FromDays(365);
            string spanStr = seqSpanBox.Text;
            int number = Convert.ToInt32(Regex.Split(spanStr, " ")[0]);
            string unit = Regex.Split(spanStr, " ")[1];
            if (unit.ToLower().StartsWith("day"))
            {
                seqSpan = TimeSpan.FromDays(number);
            }
            else if (unit.ToLower().StartsWith("minute"))
            {
                seqSpan = TimeSpan.FromMinutes(number);
            }

            // All StockChartX part are excluded from GUIDesign part. Mainly Because that a) it is unstable b) it has severe copyright problem
            //StockChartXForm stockChartXForm = new StockChartXForm(symbol);

            PeriodicDBLoader dataLoader = new PeriodicDBLoader(start, end, symbols, markets, period, seqSpan, showPercent);

            int idxSeq = 0;
            foreach (List<CommonObjects.Bar> bars in dataLoader)
            {
                logger.WriteLine(String.Format("On input sequence #{0}", idxSeq));
                idxSeq++;

                Navigator DBNavigator = PeriodicUtils.GetDatabaseNavigator(bars);
                Recordset DBRecordSet = DBNavigator.Recordset_;

                /*
                List<int[]> simulationSignals = simulator.GetTradeSignals(DBNavigator);

                List<List<double>> slidingWindowProfit = StrategySel.Program.trackPortfolio(DBRecordSet, simulationSignals, numOfBars, commisionFee, 45);
                foreach (List<double> profit in slidingWindowProfit)
                {
                    double bestProfit = profit.Max();
                    for (int i = 0; i < profit.Count; i++)
                    {
                        profit[i] = Math.Round(bestProfit - profit[i], precision);
                    }
                }
                */

                double previousClose = 0;
                foreach (CommonObjects.Bar bar in bars)
                {
                    if (previousClose == 0)
                    {
                        previousClose = bar.Close;
                    }
                    double[] inputArray = PeriodicUtils.PreprocessBar(bar.Open, bar.High, bar.Low, bar.Close, bar.Volume, previousClose, 7).ToArray();
                    Vector<double> input = Vector<double>.Build.DenseOfArray(inputArray);
                    Vector<double> output = modelForPredict.StepFProp(input);
                    logger.WriteLine("Recommend Strategy #{0}, confidence {1}", output.MaximumIndex(), output.Maximum() * 4);
                    previousClose = bar.Close;
                }
                modelForPredict.Reset();
                //stockChartXForm.AddBars(bars);
            }
            logger.WriteLine("prediction ends");
            logger.Flush();
            statusLabel.Text = "Available";
            //stockChartXForm.Show();
        }

        private void testButtonClick(object sender, EventArgs e)
        {
            statusLabel.ResetText();
            System.Threading.Thread.Sleep(10000);

            CheckedListBox.CheckedItemCollection checkedItems = ToShowChecklist.CheckedItems;
            foreach (string x in checkedItems)
            {
                logger.WriteLine(x);
            }

            int numOfStra = networkArchitecture[networkArchitecture.Count() - 1];
            int barLength = networkArchitecture[0];
            loadModel(networkArchitecture, modelFileName);
            System.IO.StreamReader testDataStream = new System.IO.StreamReader(@"testdata.pdat");
            int explorationLength = Convert.ToInt32(ExploreBox.Text);
            int trailLength = Convert.ToInt32(trailBox.Text);
            string barsInfoStr;
            int totalSeq = 0;
            double totalLoss = 0;
            double[] straLoss = new double[numOfStra];
            double[] straChoice = new double[numOfStra];
            while ((barsInfoStr = testDataStream.ReadLine()) != null)
            {
                totalSeq++;
                double[] barsInfo = Array.ConvertAll(barsInfoStr.Trim().Split(' '), Double.Parse);
                int validLength = barsInfo.Count() / barLength - trailLength - explorationLength - 1;
                for (int position = 0; position < barsInfo.Count() / barLength; position++)
                {
                    string lossLine = testDataStream.ReadLine();

                    if (position <= explorationLength || position >= barsInfo.Count() / barLength - trailLength)
                    {
                        continue;
                    }

                    double[] input = barsInfo.Skip(position * barLength).Take(barLength).ToArray();
                    Vector<double> inputVector = Vector<double>.Build.Dense(input);
                    Vector<double> strategyProba = modelForPredict.StepFProp(inputVector);

                    double[] loss = Array.ConvertAll(lossLine.Trim().Split(' '), Double.Parse);
                    Debug.Assert(loss.Count() == 7);
                    for (int i = 0; i < loss.Length; i++)
                    {
                        totalLoss += strategyProba[i] * loss[i] / validLength;
                        straLoss[i] += loss[i] / validLength;
                        straChoice[i] += strategyProba[i] / validLength;
                    }
                    logger.WriteLine("Sequence No. {0}", totalSeq);
                    logger.WriteLine("Selection Probability: {0}", String.Join<double>(",", strategyProba));
                    logger.WriteLine("Corresponding Loss: {0}:", String.Join<double>(",", loss));
                    logger.Flush();
                }
                modelForPredict.Reset();
            }
            logger.WriteLine("Total tested sequences: {0}", totalSeq);
            logger.WriteLine("Average loss: {0}", totalLoss / totalSeq - 0.02);
            for (int idxStra = 0; idxStra < numOfStra; idxStra++)
            {
                logger.WriteLine("Strategy {0} selected {1}%, consist loss {2}", idxStra, straChoice[idxStra] / totalSeq / 100, straLoss[idxStra] / totalSeq);
            }
            logger.Flush();
            testDataStream.Close();

            statusLabel.Text = "Available";
        }

        private void addZScriptButtonClick(object sender, EventArgs e)
        {
            //simulator.strategies.Add(BuildinStrategies.ZScript(textBox9.Text, textBox10.Text));
            logger.Write(String.Format("ZScript strategy added\nBuy Signal:{0}\nSell Signal:{1}\n", textBox9.Text, textBox10.Text));
            logger.Flush();
        }

        private void addDefaultButtonClick(object sender, EventArgs e)
        {
            simulator.LoadDefault();
            logger.WriteLine("default strategies loaded");
            logger.Flush();
        }

        private void loadModel(int[] networkArchitecture, string modelFileName)
        {
            modelForPredict = new StockRNN(networkArchitecture, modelFileName);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            statusLabel.Text = "test";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

    }
}