﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

using STOCKCHARTXLib;

using CommonObjects;

namespace GUIDesign
{
    public partial class StockChartXForm : Form
    {
        public string symbol;
        private List<GUIDesign.Bar> bars = new List<GUIDesign.Bar>();
        public StockChartXForm(string symbolToShow)
        {
            InitializeComponent();
            this.symbol = symbolToShow;
            
            List<GUIDesign.Bar> bars = new List<GUIDesign.Bar>();
            for (int i = 10; i < 20; i++)
            {
                GUIDesign.Bar bar = new GUIDesign.Bar();

                bar.OpenPrice = i;
                bar.HighPrice = i + 2;
                bar.LowPrice = i - 1;
                bar.ClosePrice = i + 1;
                bar.Volume = 10 * i;
                bar.TradeDate = DateTime.Now.AddDays(-i);
                bars.Add(bar);
            }
            
            InitRTChartHeader();
            //InitRTChartFooter(bars);
        }

        public void AddBars(List<CommonObjects.Bar> barsToAdd)
        {
            foreach (CommonObjects.Bar barToAdd in barsToAdd)
            {
                GUIDesign.Bar bar = new GUIDesign.Bar();
                bar.ClosePrice = barToAdd.Close;
                bar.HighPrice = barToAdd.High;
                bar.LowPrice = barToAdd.Low;
                bar.OpenPrice = barToAdd.Open;
                bar.Volume = barToAdd.Volume;
                bar.TradeDate = barToAdd.Date;
                this.bars.Add(bar);
            }
            InitRTChartFooter(this.bars);
        }

        private bool InitRTChartHeader()
        {
            StockChartX1.Symbol = symbol;

            //First setup the chart for real time data
            StockChartX1.RemoveAllSeries();
            StockChartX1.RealTimeXLabels = true;

            //First add a panel (chart area) for the OHLC data:
            long panel = StockChartX1.AddChartPanel();

            //Now add the open, high, low and close series to that panel:
            StockChartX1.AddSeries(symbol + ".open", SeriesType.stCandleChart, (int)panel);
            StockChartX1.AddSeries(symbol + ".high", SeriesType.stCandleChart, (int)panel);
            StockChartX1.AddSeries(symbol + ".low", SeriesType.stCandleChart, (int)panel);
            StockChartX1.AddSeries(symbol + ".close", SeriesType.stCandleChart, (int)panel);
            StockChartX1.AddSeries(symbol + ".closeLine", SeriesType.stLineChart, (int)panel);

            //Change the color:
            StockChartX1.set_SeriesColor(symbol + ".close", ColorTranslator.ToOle(Color.Lime));
            StockChartX1.set_SeriesColor(symbol + ".closeLine", ColorTranslator.ToOle(Color.Lime));

            //Add the volume chart panel
            panel = StockChartX1.AddChartPanel();
            StockChartX1.AddSeries(symbol + ".volume", SeriesType.stVolumeChart, (int)panel);

            //Change volume color and weight of the volume panel:
            StockChartX1.set_SeriesColor(symbol + ".volume", ColorTranslator.ToOle(Color.FromArgb(206, 203, 0)));
            StockChartX1.set_SeriesWeight(symbol + ".volume", 3);

            //Resize the volume panel to make it smaller
            StockChartX1.set_PanelY1(1, (int)Math.Round(StockChartX1.Height * 0.75));


            StockChartX1.UpColor = Color.Green;
            StockChartX1.DownColor = Color.Red;
            StockChartX1.ThreeDStyle = false;
            StockChartX1.RightDrawingSpacePixels = 20;
            StockChartX1.UpColor = System.Drawing.Color.Lime;
            StockChartX1.DownColor = System.Drawing.Color.Red;
            StockChartX1.ChartForeColor = System.Drawing.Color.FromArgb(255, 0, 0);
            StockChartX1.XGrid = false;
            StockChartX1.YGrid = true;

            return true;
        }

        private void InitRTChartFooter(List<GUIDesign.Bar> bars)
        {
            Stopwatch sw = new Stopwatch();
            double prevJDate = 0;
            sw.Start();
            foreach (GUIDesign.Bar bar in bars)
            {
                if (sw.ElapsedMilliseconds > 100)
                {
                    //loading 50.000 on main thread may freeze app. Can't append data into chart in a separate thread cause chart is created in main GUI thread
                    Application.DoEvents();
                    sw.Reset();
                }
                double jdate = StockChartX1.ToJulianDate(bar.TradeDate.Year, bar.TradeDate.Month, bar.TradeDate.Day, bar.TradeDate.Hour, bar.TradeDate.Minute, bar.TradeDate.Second);
                if (jdate != prevJDate)
                {
                    prevJDate = jdate;
                    StockChartX1.AppendValue(symbol + ".open", jdate, bar.OpenPrice);
                    StockChartX1.AppendValue(symbol + ".high", jdate, bar.HighPrice);
                    StockChartX1.AppendValue(symbol + ".low", jdate, bar.LowPrice);
                    StockChartX1.AppendValue(symbol + ".close", jdate, bar.ClosePrice);
                    StockChartX1.AppendValue(symbol + ".closeLine", jdate, bar.ClosePrice);
                    StockChartX1.AppendValue(symbol + ".volume", jdate, bar.Volume);

                    //StockChartX1.set_SeriesVisible(m_Symbol + ".closeLine", false);
                    Application.DoEvents();
                }
            }
            //Debug.WriteLine("Last Values " + bars.Last());

            //if (bars[0].Volume == 0.0) StockChartX1.RemoveSeries(m_Symbol + ".volume");
            StockChartX1.RealTimeXLabels = true;
            StockChartX1.HorizontalSeparators = true;
            StockChartX1.DisplayTitles = true;

            //UpdateChartColors(m_frmMain.m_Style);

            if (StockChartX1.RecordCount > 100)
            {
                StockChartX1.FirstVisibleRecord = StockChartX1.RecordCount - 100;
            }

            StockChartX1.Update();

            StockChartX1.Visible = true;

        }


    }
}
