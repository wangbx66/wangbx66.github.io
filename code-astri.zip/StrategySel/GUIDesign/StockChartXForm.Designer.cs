﻿namespace GUIDesign
{
    partial class StockChartXForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StockChartXForm));
            this.StockChartX1 = new AxSTOCKCHARTXLib.AxStockChartX();
            ((System.ComponentModel.ISupportInitialize)(this.StockChartX1)).BeginInit();
            this.SuspendLayout();
            // 
            // StockChartX1
            // 
            this.StockChartX1.Enabled = true;
            this.StockChartX1.Location = new System.Drawing.Point(-1, -2);
            this.StockChartX1.Name = "StockChartX1";
            this.StockChartX1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("StockChartX1.OcxState")));
            this.StockChartX1.Size = new System.Drawing.Size(859, 522);
            this.StockChartX1.TabIndex = 0;
            // 
            // StockChartXForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(858, 532);
            this.Controls.Add(this.StockChartX1);
            this.Name = "StockChartXForm";
            this.Text = "StockChartXForm";
            ((System.ComponentModel.ISupportInitialize)(this.StockChartX1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxSTOCKCHARTXLib.AxStockChartX StockChartX1;
    }
}