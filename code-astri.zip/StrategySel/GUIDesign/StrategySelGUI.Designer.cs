﻿namespace GUIDesign
{
    partial class StrategySelectionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.currentMarketBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ToShowChecklist = new System.Windows.Forms.CheckedListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.seqSpanBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.periodicityBox = new System.Windows.Forms.TextBox();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.symbolBox = new System.Windows.Forms.TextBox();
            this.trainingButton = new System.Windows.Forms.Button();
            this.trainStartTimePicker = new System.Windows.Forms.DateTimePicker();
            this.trainEndTimePicker = new System.Windows.Forms.DateTimePicker();
            this.commissionFeeNTaxBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.endDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.startDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.totalSequencesBox = new System.Windows.Forms.TextBox();
            this.miscKeyBox = new System.Windows.Forms.ComboBox();
            this.predictButton = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.testButton = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.addZScriptButton = new System.Windows.Forms.Button();
            this.addDefaultButton = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.statusLabel = new System.Windows.Forms.Label();
            this.realtimeCheckBox1 = new System.Windows.Forms.CheckBox();
            this.trailBox = new System.Windows.Forms.TextBox();
            this.ExploreBox = new System.Windows.Forms.TextBox();
            this.trailLabel = new System.Windows.Forms.Label();
            this.exploreLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 77);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Market";
            // 
            // currentMarketBox
            // 
            this.currentMarketBox.FormattingEnabled = true;
            this.currentMarketBox.Location = new System.Drawing.Point(42, 101);
            this.currentMarketBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.currentMarketBox.Name = "currentMarketBox";
            this.currentMarketBox.Size = new System.Drawing.Size(120, 28);
            this.currentMarketBox.TabIndex = 1;
            this.currentMarketBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(572, 209);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "To-Show";
            // 
            // ToShowChecklist
            // 
            this.ToShowChecklist.CheckOnClick = true;
            this.ToShowChecklist.FormattingEnabled = true;
            this.ToShowChecklist.Location = new System.Drawing.Point(576, 239);
            this.ToShowChecklist.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ToShowChecklist.Name = "ToShowChecklist";
            this.ToShowChecklist.Size = new System.Drawing.Size(265, 172);
            this.ToShowChecklist.TabIndex = 7;
            this.ToShowChecklist.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(37, 259);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Seq Span";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // seqSpanBox
            // 
            this.seqSpanBox.Location = new System.Drawing.Point(40, 283);
            this.seqSpanBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.seqSpanBox.Name = "seqSpanBox";
            this.seqSpanBox.Size = new System.Drawing.Size(148, 26);
            this.seqSpanBox.TabIndex = 11;
            this.seqSpanBox.Text = "365 day";
            this.seqSpanBox.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(37, 139);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Commission Fee";
            // 
            // periodicityBox
            // 
            this.periodicityBox.Location = new System.Drawing.Point(40, 344);
            this.periodicityBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.periodicityBox.Name = "periodicityBox";
            this.periodicityBox.Size = new System.Drawing.Size(148, 26);
            this.periodicityBox.TabIndex = 13;
            this.periodicityBox.Text = "Daily";
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(40, 464);
            this.nameBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(148, 26);
            this.nameBox.TabIndex = 14;
            this.nameBox.Text = "day";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(37, 440);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 20);
            this.label8.TabIndex = 15;
            this.label8.Text = "name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(42, 13);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(199, 29);
            this.label9.TabIndex = 16;
            this.label9.Text = "Training Setting";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(37, 381);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 20);
            this.label10.TabIndex = 17;
            this.label10.Text = "#Seq";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(572, 13);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(190, 29);
            this.label11.TabIndex = 19;
            this.label11.Text = "Testing Setting";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(572, 77);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 20);
            this.label12.TabIndex = 20;
            this.label12.Text = "Symbol";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // symbolBox
            // 
            this.symbolBox.Location = new System.Drawing.Point(576, 103);
            this.symbolBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.symbolBox.Name = "symbolBox";
            this.symbolBox.Size = new System.Drawing.Size(148, 26);
            this.symbolBox.TabIndex = 21;
            this.symbolBox.Text = "000001-SZSE";
            this.symbolBox.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // trainingButton
            // 
            this.trainingButton.Location = new System.Drawing.Point(227, 9);
            this.trainingButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.trainingButton.Name = "trainingButton";
            this.trainingButton.Size = new System.Drawing.Size(79, 36);
            this.trainingButton.TabIndex = 28;
            this.trainingButton.Text = "start";
            this.trainingButton.UseVisualStyleBackColor = true;
            this.trainingButton.Click += new System.EventHandler(this.trainingButtonClick);
            // 
            // trainStartTimePicker
            // 
            this.trainStartTimePicker.Location = new System.Drawing.Point(210, 129);
            this.trainStartTimePicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.trainStartTimePicker.Name = "trainStartTimePicker";
            this.trainStartTimePicker.Size = new System.Drawing.Size(192, 26);
            this.trainStartTimePicker.TabIndex = 29;
            this.trainStartTimePicker.Value = new System.DateTime(2012, 1, 1, 0, 0, 0, 0);
            // 
            // trainEndTimePicker
            // 
            this.trainEndTimePicker.Location = new System.Drawing.Point(210, 168);
            this.trainEndTimePicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.trainEndTimePicker.Name = "trainEndTimePicker";
            this.trainEndTimePicker.Size = new System.Drawing.Size(192, 26);
            this.trainEndTimePicker.TabIndex = 30;
            this.trainEndTimePicker.Value = new System.DateTime(2012, 7, 31, 0, 0, 0, 0);
            // 
            // commissionFeeNTaxBox
            // 
            this.commissionFeeNTaxBox.Location = new System.Drawing.Point(40, 168);
            this.commissionFeeNTaxBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.commissionFeeNTaxBox.Name = "commissionFeeNTaxBox";
            this.commissionFeeNTaxBox.Size = new System.Drawing.Size(121, 26);
            this.commissionFeeNTaxBox.TabIndex = 31;
            this.commissionFeeNTaxBox.Text = "0.0021";
            this.commissionFeeNTaxBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 101);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 32;
            this.label2.Text = "From-to";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(771, 103);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 20);
            this.label3.TabIndex = 36;
            this.label3.Text = "From-to";
            // 
            // endDateTimePicker
            // 
            this.endDateTimePicker.Location = new System.Drawing.Point(774, 169);
            this.endDateTimePicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.endDateTimePicker.Name = "endDateTimePicker";
            this.endDateTimePicker.Size = new System.Drawing.Size(192, 26);
            this.endDateTimePicker.TabIndex = 35;
            this.endDateTimePicker.Value = new System.DateTime(2012, 8, 24, 0, 0, 0, 0);
            this.endDateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged_1);
            // 
            // startDateTimePicker
            // 
            this.startDateTimePicker.Location = new System.Drawing.Point(774, 131);
            this.startDateTimePicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.startDateTimePicker.Name = "startDateTimePicker";
            this.startDateTimePicker.Size = new System.Drawing.Size(192, 26);
            this.startDateTimePicker.TabIndex = 34;
            this.startDateTimePicker.Value = new System.DateTime(2012, 1, 1, 0, 0, 0, 0);
            this.startDateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 320);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 20);
            this.label5.TabIndex = 33;
            this.label5.Text = "Periodicity";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // totalSequencesBox
            // 
            this.totalSequencesBox.Location = new System.Drawing.Point(40, 405);
            this.totalSequencesBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.totalSequencesBox.Name = "totalSequencesBox";
            this.totalSequencesBox.Size = new System.Drawing.Size(148, 26);
            this.totalSequencesBox.TabIndex = 37;
            this.totalSequencesBox.Text = "240";
            this.totalSequencesBox.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // miscKeyBox
            // 
            this.miscKeyBox.FormattingEnabled = true;
            this.miscKeyBox.Location = new System.Drawing.Point(210, 283);
            this.miscKeyBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.miscKeyBox.Name = "miscKeyBox";
            this.miscKeyBox.Size = new System.Drawing.Size(148, 28);
            this.miscKeyBox.TabIndex = 38;
            this.miscKeyBox.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // predictButton
            // 
            this.predictButton.Location = new System.Drawing.Point(748, 9);
            this.predictButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.predictButton.Name = "predictButton";
            this.predictButton.Size = new System.Drawing.Size(79, 36);
            this.predictButton.TabIndex = 39;
            this.predictButton.Text = "pred";
            this.predictButton.UseVisualStyleBackColor = true;
            this.predictButton.Click += new System.EventHandler(this.predictButtonClick);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(207, 259);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 20);
            this.label13.TabIndex = 40;
            this.label13.Text = "Misc Key";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(207, 317);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(86, 20);
            this.label14.TabIndex = 41;
            this.label14.Text = "Misc Value";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(210, 341);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(148, 26);
            this.textBox7.TabIndex = 42;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(246, 393);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 36);
            this.button4.TabIndex = 43;
            this.button4.Text = "Add Misc";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(246, 440);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(112, 36);
            this.button5.TabIndex = 44;
            this.button5.Text = "Show Paras";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(576, 168);
            this.textBox8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(148, 26);
            this.textBox8.TabIndex = 45;
            this.textBox8.Text = "database";
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(573, 139);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 20);
            this.label15.TabIndex = 46;
            this.label15.Text = "Data Source";
            // 
            // testButton
            // 
            this.testButton.Location = new System.Drawing.Point(836, 9);
            this.testButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.testButton.Name = "testButton";
            this.testButton.Size = new System.Drawing.Size(79, 36);
            this.testButton.TabIndex = 49;
            this.testButton.Text = "test";
            this.testButton.UseVisualStyleBackColor = true;
            this.testButton.Click += new System.EventHandler(this.testButtonClick);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(40, 548);
            this.textBox9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(318, 116);
            this.textBox9.TabIndex = 50;
            // 
            // addZScriptButton
            // 
            this.addZScriptButton.Location = new System.Drawing.Point(40, 505);
            this.addZScriptButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.addZScriptButton.Name = "addZScriptButton";
            this.addZScriptButton.Size = new System.Drawing.Size(122, 36);
            this.addZScriptButton.TabIndex = 52;
            this.addZScriptButton.Text = "Add ZScript";
            this.addZScriptButton.UseVisualStyleBackColor = true;
            this.addZScriptButton.Click += new System.EventHandler(this.addZScriptButtonClick);
            // 
            // addDefaultButton
            // 
            this.addDefaultButton.Location = new System.Drawing.Point(171, 505);
            this.addDefaultButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.addDefaultButton.Name = "addDefaultButton";
            this.addDefaultButton.Size = new System.Drawing.Size(126, 36);
            this.addDefaultButton.TabIndex = 53;
            this.addDefaultButton.Text = "Add Default";
            this.addDefaultButton.UseVisualStyleBackColor = true;
            this.addDefaultButton.Click += new System.EventHandler(this.addDefaultButtonClick);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(368, 548);
            this.textBox10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(318, 116);
            this.textBox10.TabIndex = 54;
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(1019, 645);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(72, 20);
            this.statusLabel.TabIndex = 55;
            this.statusLabel.Text = "Available";
            this.statusLabel.Click += new System.EventHandler(this.label16_Click);
            // 
            // realtimeCheckBox1
            // 
            this.realtimeCheckBox1.AutoSize = true;
            this.realtimeCheckBox1.Location = new System.Drawing.Point(849, 101);
            this.realtimeCheckBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.realtimeCheckBox1.Name = "realtimeCheckBox1";
            this.realtimeCheckBox1.Size = new System.Drawing.Size(98, 24);
            this.realtimeCheckBox1.TabIndex = 56;
            this.realtimeCheckBox1.Text = "Realtime";
            this.realtimeCheckBox1.UseVisualStyleBackColor = true;
            // 
            // trailBox
            // 
            this.trailBox.Location = new System.Drawing.Point(849, 324);
            this.trailBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.trailBox.Name = "trailBox";
            this.trailBox.Size = new System.Drawing.Size(148, 26);
            this.trailBox.TabIndex = 57;
            this.trailBox.Text = "20";
            // 
            // ExploreBox
            // 
            this.ExploreBox.Location = new System.Drawing.Point(849, 263);
            this.ExploreBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ExploreBox.Name = "ExploreBox";
            this.ExploreBox.Size = new System.Drawing.Size(148, 26);
            this.ExploreBox.TabIndex = 58;
            this.ExploreBox.Text = "30";
            // 
            // trailLabel
            // 
            this.trailLabel.AutoSize = true;
            this.trailLabel.Location = new System.Drawing.Point(850, 300);
            this.trailLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.trailLabel.Name = "trailLabel";
            this.trailLabel.Size = new System.Drawing.Size(38, 20);
            this.trailLabel.TabIndex = 59;
            this.trailLabel.Text = "Trail";
            // 
            // exploreLabel
            // 
            this.exploreLabel.AutoSize = true;
            this.exploreLabel.Location = new System.Drawing.Point(850, 239);
            this.exploreLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.exploreLabel.Name = "exploreLabel";
            this.exploreLabel.Size = new System.Drawing.Size(62, 20);
            this.exploreLabel.TabIndex = 60;
            this.exploreLabel.Text = "Explore";
            // 
            // StrategySelectionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1144, 841);
            this.Controls.Add(this.exploreLabel);
            this.Controls.Add(this.trailLabel);
            this.Controls.Add(this.ExploreBox);
            this.Controls.Add(this.trailBox);
            this.Controls.Add(this.realtimeCheckBox1);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.addDefaultButton);
            this.Controls.Add(this.addZScriptButton);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.testButton);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.predictButton);
            this.Controls.Add(this.miscKeyBox);
            this.Controls.Add(this.totalSequencesBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.endDateTimePicker);
            this.Controls.Add(this.startDateTimePicker);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.commissionFeeNTaxBox);
            this.Controls.Add(this.trainEndTimePicker);
            this.Controls.Add(this.trainStartTimePicker);
            this.Controls.Add(this.trainingButton);
            this.Controls.Add(this.symbolBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.periodicityBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.seqSpanBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ToShowChecklist);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.currentMarketBox);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "StrategySelectionForm";
            this.Text = "Strategy Selection Alpha";
            this.Load += new System.EventHandler(this.StrategySelectionFormLoad);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox currentMarketBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckedListBox ToShowChecklist;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox seqSpanBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox periodicityBox;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox symbolBox;
        private System.Windows.Forms.Button trainingButton;
        private System.Windows.Forms.DateTimePicker trainStartTimePicker;
        private System.Windows.Forms.DateTimePicker trainEndTimePicker;
        private System.Windows.Forms.TextBox commissionFeeNTaxBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker endDateTimePicker;
        private System.Windows.Forms.DateTimePicker startDateTimePicker;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox totalSequencesBox;
        private System.Windows.Forms.ComboBox miscKeyBox;
        private System.Windows.Forms.Button predictButton;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button testButton;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button addZScriptButton;
        private System.Windows.Forms.Button addDefaultButton;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.CheckBox realtimeCheckBox1;
        private System.Windows.Forms.TextBox trailBox;
        private System.Windows.Forms.TextBox ExploreBox;
        private System.Windows.Forms.Label trailLabel;
        private System.Windows.Forms.Label exploreLabel;
    }
}

