# Brief

We use tflearn pythonAPI to build the model on Linux (tested on Ubuntu 14.04). To do this, we need tensorflow, h5py and tflearn. The python program is to build a series of tensorflow graph protobuffers, and is expected to be called only once.

To build tflearn on windows, we need Bazel. To build Bazel, we need JDK8, msys2, and pacman distribution of gcc, git, curl, zip, unzip, and zlib-devel.

# Step Guide

### Install Tensorflow (Linux)
1. Install **lastest** python3 version. We assume everything take place on a 64-bit linux distribution, which is not necessarily debian
1. Refer *python3.5* or *python3.4* executable to *python3* alias
1. Visit https://www.tensorflow.org/, and go wherever talking about *pip installation*; Then copy the *googleapis* address where the **Linux & cpu** version locates
1. For python3.5, download the wheel first, then rename the wheel, from *cp34*, to *cp35*
1. $pip3 install --upgrade --user [googleapis]

### Install tflearn (Linux)
1. $sudo apt-get install libhdf5-dev (Alternatively, $sudo pacman -S hdf5)
1. $pip3 install --upgrade --user git+git://github.com/tflearn/tflearn

### Generate Graphs (Linux)
1. $cd tfgenerator/src
1. $python3 generate_multi_models.py
1. Copy *tfgenerator/models* to the directory of *tfload* project (mentioned below)

### Install JDK8

### Install MSYS2
1. Download from https://msys2.github.io/
1. Install on C:\tools\msys64\
1. Run MSYS2 shell
1. $update-core
1. Close the shell using ALT-F4
1. Run MSYS2 shell
1. $pacman -Syuu

### Install dev basics
1. $pacman -S gcc git curl zip unzip zlib-devel  

### Install Bazel
1. Run MSYS2 shell
1. $git clone https://github.com/bazelbuild/bazel
1. $export JAVA_HOME="$(ls -d C:/Program\ Files/Java/jdk* | sort | tail -n 1)"
1. $export TMPDIR=c:/temp
1. $export BAZEL_SH=c:/tools/msys64/usr/bin/bash.exe
1. $./bazel/compile.sh  

### Install TensorFlow
1. $git clone --recursive https://github.com/tensorflow/tensorflow
1. Alternatively, if you already have it at the corresponding position, update it via $git submodule update --remote --merge
1. Make configurations in order to **not** spam the repository with Visual Studio related files, including but not limited to  
Tools -> Options -> Text Editor -> C/C++ -> Advanced -> set "Disable Database", "Always Use Fallback Location", and "Do Not Warn If Fallback Location Used" to True;  
Delete the unused, auto-generated sdf, VC, etc. files, before synchroing to the repository;  
Have a read on *.gitignore*, and make sure the files you deemed necessary to be synchroed are not ignored;

### Build CC Graph Loader (MSYS2)
1. $cp -r tfload tensorflow/tensorflow/
1. $cd tensorflow
1. $bazel clean
1. $bazel build -c opt --jobs 4 tensorflow/tfload :loader
1. $cp -r tensorflow/tfload/models bazel-bin/tensorflow/tfload/
1. $cd bazel-bin/tensorflow/tfload/
1. $./loader
