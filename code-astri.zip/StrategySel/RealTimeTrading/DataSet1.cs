﻿namespace RealTimeTrading {
    
    
    public partial class DataSet1 {
    }
}
