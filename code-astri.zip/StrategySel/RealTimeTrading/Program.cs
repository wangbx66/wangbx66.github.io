﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

using AxiomObjects;
using System.Configuration;
using System.IO;
using Microsoft.MSR.CNTK.Extensibility.Managed;
using System.Threading;
using Modulus.TradeScript;
using ModulusFE.TASDK;

namespace RealTimeTrading
{
    public class InfoContainer
    {
        public StrategySelByLarry.Simulator simulator;
        public List<double> moneyOnHand;

        public InfoContainer()
        {
            simulator = new StrategySelByLarry.Simulator();
            //StrategySelByLarry.StrategiesReader strategyReader = new StrategySelByLarry.StrategiesReader();
            //strategyReader.LongOnly(simulator);
            simulator.LoadDefault();
        }
    }

    class Program
    {
        static List<Bar> marketInfoBarList = new List<Bar>();
        static string modelFilePath = @"..\..\..\..\CNTK_StrategySel\Models\Trained_StrategySel_Model.dnn";
        static List<List<double>> features;
        static List<List<double>> modelPrediction;

        static InfoContainer container = new InfoContainer();

        static double moneyAssignPerPeriod = 95238;
        static double commissionFeeNTax = 0.0002;
        static List<double> moneyOnHand = Enumerable.Repeat(Convert.ToDouble(0), container.simulator.strategies.Count).ToList();
        //static List<double> moneyOnHand = Enumerable.Repeat(Convert.ToDouble(0), 21).ToList();
        static List<Tuple<int, double, double, int, int>> tradingRecords = new List<Tuple<int, double, double, int, int>>();
        static List<int> positionTracker = new List<int>();
        static int lotSize = 0;

        static void Main(string[] args)
        {
            var exitEvent = new ManualResetEvent(false);
            Console.CancelKeyPress += (sender, eventArgs) =>
            {
                eventArgs.Cancel = true;
                exitEvent.Set();
            };

            string mqServer = ConfigurationManager.AppSettings["MqServer"];
            ushort mqPort = Convert.ToUInt16(ConfigurationManager.AppSettings["MqPort"]);
            string mqUser = ConfigurationManager.AppSettings["MqUser"];
            string mqPassword = ConfigurationManager.AppSettings["MqPassword"];
            string requestQueue = ConfigurationManager.AppSettings["RequestQueue"];
            string httpServer = ConfigurationManager.AppSettings["DataStoreManagerIp"];
            ushort httpPort = Convert.ToUInt16(ConfigurationManager.AppSettings["DataStoreManagerPort"]);

            DataAPI.DataAPI api = new DataAPI.DataAPI(mqServer, mqPort, mqUser, mqPassword, requestQueue, httpServer, httpPort, Handler);
            api.Start();
            Console.WriteLine("API started");

            //api.SubscribeBar("601988-SSE", '1');
            api.Subscribe("601988-SSE", '1');
            //api.SubscribeBar("IF1610-CFFEX", '1');
            //api.Subscribe("IF1610-CFFEX", '1');
            //api.Subscribe("EURUSD-MT4", '1');

            exitEvent.WaitOne();
            api.Stop();
            Console.WriteLine("DataAPI Console Stopped");
        }

        private static void Handler(object o)
        {
            
            if (o is Bar)
            {
                #region
                Bar data = o as Bar;
                marketInfoBarList.Add(data);

                DataSet1TableAdapters.tb_machine_signalTableAdapter machine_signal_adapter = new DataSet1TableAdapters.tb_machine_signalTableAdapter();

                string symbol = data.Symbol.Split('-')[0];
                string exchange = data.Symbol.Split('-')[1];
                DataSet1TableAdapters.tb_stock_lot_sizeTableAdapter lot_size_adapter = new DataSet1TableAdapters.tb_stock_lot_sizeTableAdapter();
                DataTable dt = lot_size_adapter.GetDataBySymbol(symbol);
                if (dt.Rows.Count > 0)
                {
                    lotSize = Convert.ToInt32(dt.Rows[0]["lotSize"]);
                }
                else
                {
                    lotSize = 100;
                }

                if (marketInfoBarList.Count > 31)
                {
                    features = featureConstructor(marketInfoBarList);
                    modelPrediction = ModelExecutor.DoublePrecision(modelFilePath, features);
                    Navigator dataBaseNavigator = StrategySelByLarry.PeriodicUtils.GetDatabaseNavigator(marketInfoBarList);
                    List<int[]> tradeSignals = container.simulator.GetTradeSignals(dataBaseNavigator);

                    for (int straIdx = 0; straIdx < modelPrediction[modelPrediction.Count - 1].Count; straIdx++)
                    {
                        moneyOnHand[straIdx] += moneyAssignPerPeriod * modelPrediction[modelPrediction.Count - 1][straIdx];
                        if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 1)
                        {
                            int temp_share = Convert.ToInt32(Math.Floor(moneyOnHand[straIdx] / Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close))) / lotSize;
                            int share = temp_share * lotSize;
                            double takeProfit = Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) + container.simulator.takeProfitNStopLoss[straIdx][0];
                            double stopLoss = Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) - container.simulator.takeProfitNStopLoss[straIdx][1];
                            moneyOnHand[straIdx] = 0;
                            tradingRecords.Add(Tuple.Create<int, double, double, int, int>(share, takeProfit, stopLoss, straIdx, marketInfoBarList.Count - 1));
                        }
                        else if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 2)
                        {
                            int temp_share = Convert.ToInt32(Math.Ceiling(-moneyOnHand[straIdx] / Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close))) / lotSize;
                            int share = temp_share * lotSize;
                            double takeProfit = Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) - container.simulator.takeProfitNStopLoss[straIdx][3];
                            double stopLoss = Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) + container.simulator.takeProfitNStopLoss[straIdx][4];
                            moneyOnHand[straIdx] += -share * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 - commissionFeeNTax);
                            tradingRecords.Add(Tuple.Create<int, double, double, int, int>(share, takeProfit, stopLoss, straIdx, marketInfoBarList.Count - 1));
                        }
                        else if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 3)
                        {
                            if (tradingRecords.Count > 0)
                            {
                                for (int record = 0; record < tradingRecords.Count - 1; record++)
                                {
                                    if (tradingRecords[record].Item1 > 0 && tradingRecords[record].Item4 == straIdx)
                                    {
                                        moneyOnHand[straIdx] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                                        tradingRecords.RemoveAt(record);
                                    }
                                }
                            }
                        }
                        else if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 4)
                        {
                            if (tradingRecords.Count > 0)
                            {
                                for (int record = 0; record < tradingRecords.Count; record++)
                                {
                                    if (tradingRecords[record].Item1 < 0 && tradingRecords[record].Item4 == straIdx)
                                    {
                                        moneyOnHand[straIdx] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                                        tradingRecords.RemoveAt(record);
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine(data.Time + " " + data.Symbol + " " + (DateTime.Now - data.Time).TotalMilliseconds + "ms");
                }

                if (tradingRecords.Count > 0)
                {
                    for (int record = 0; record < tradingRecords.Count; record++)
                    {
                        if ((tradingRecords[record].Item1 > 0) && (tradingRecords[record].Item2 <= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].High)) && (tradingRecords[record].Item5 < (marketInfoBarList.Count - 1)))
                        {
                            moneyOnHand[tradingRecords[record].Item4] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                            tradingRecords.RemoveAt(record);
                        }
                        else if ((tradingRecords[record].Item1 > 0) && (tradingRecords[record].Item3 >= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Low)) && (tradingRecords[record].Item5 < (marketInfoBarList.Count - 1)))
                        {
                            moneyOnHand[tradingRecords[record].Item4] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                            tradingRecords.RemoveAt(record);
                        }
                        else if ((tradingRecords[record].Item1 < 0) && (tradingRecords[record].Item2 >= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Low)) && (tradingRecords[record].Item5 < (marketInfoBarList.Count - 1)))
                        {
                            moneyOnHand[tradingRecords[record].Item4] -= tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                            tradingRecords.RemoveAt(record);
                        }
                        else if ((tradingRecords[record].Item1 < 0) && (tradingRecords[record].Item2 <= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].High)) && (tradingRecords[record].Item5 < (marketInfoBarList.Count - 1)))
                        {
                            moneyOnHand[tradingRecords[record].Item4] -= tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                            tradingRecords.RemoveAt(record);
                        }
                    }
                }

                if (tradingRecords.Count == 0)
                {
                    positionTracker.Add(0);
                }
                else
                {
                    int position = 0;
                    for (int record = 0; record < tradingRecords.Count; record++)
                    {
                        position += tradingRecords[record].Item1;
                    }
                    positionTracker.Add(position);
                }

                if (positionTracker.Count == 1)
                {
                    Console.WriteLine(positionTracker[0]);
                }
                else
                {
                    if ((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) > 0)
                    {
                        string strategy = null;
                        string orderAction = "buy";
                        string tradeAction = null;
                        int quantity = Math.Abs(positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]);
                        decimal signalprice = 0;
                        DateTime signalTime = DateTime.Now;
                        int executionFlag = 0;

                        machine_signal_adapter.InsertQuery(strategy, symbol, exchange, orderAction, tradeAction, quantity, signalprice, signalTime, null, executionFlag);
                        Console.WriteLine((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) + " " + marketInfoBarList[marketInfoBarList.Count - 1].Symbol);
                    }
                    else if ((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) < 0)
                    {
                        string strategy = null;
                        string orderAction = "sell";
                        string tradeAction = null;
                        int quantity = Math.Abs(positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]);
                        decimal signalprice = 0;
                        DateTime signalTime = DateTime.Now;
                        int executionFlag = 0;

                        machine_signal_adapter.InsertQuery(strategy, symbol, exchange, orderAction, tradeAction, quantity, signalprice, signalTime, null, executionFlag);
                        Console.WriteLine((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) + " " + marketInfoBarList[marketInfoBarList.Count - 1].Symbol);
                    }
                    else if ((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) == 0)
                    {
                        Console.WriteLine("No Trade");
                    }

                    Console.WriteLine("moneyOnHand:" + " " + String.Join(" ", moneyOnHand));
                    if (moneyAssignPerPeriod * (marketInfoBarList.Count - 31) > 0)
                    {
                        Console.WriteLine("Total Money Invested:" + " " + moneyAssignPerPeriod * (marketInfoBarList.Count - 31));
                    }
                    else
                    {
                        Console.WriteLine("Total Money Invested:" + " " + 0);
                    }
                    Console.WriteLine("portfolio:" + " " + (moneyOnHand.Sum() + positionTracker[positionTracker.Count - 1] * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close)));
                    Console.WriteLine("prev_shareOnHand:" + " " + positionTracker[positionTracker.Count - 2]);
                    Console.WriteLine("shareOnHand:" + positionTracker[positionTracker.Count - 1]);
                }
                #endregion
            }
            else if (o is MarketData)
            {
                #region
                MarketData data = o as MarketData;
                Bar temp = new Bar();
                temp.Time = data.Time;
                temp.Symbol = data.Symbol;
                temp.Open = data.LastPrice;
                temp.High = data.LastPrice + 1;
                temp.Low = data.LastPrice - 1;
                temp.Close = data.LastPrice + Convert.ToDecimal(0.5);
                temp.Volume = data.LastVolume;
                marketInfoBarList.Add(temp);

                DataSet1TableAdapters.tb_machine_signalTableAdapter machine_signal_adapter = new DataSet1TableAdapters.tb_machine_signalTableAdapter();

                string symbol = temp.Symbol.Split('-')[0];
                string exchange = temp.Symbol.Split('-')[1];
                DataSet1TableAdapters.tb_stock_lot_sizeTableAdapter lot_size_adapter = new DataSet1TableAdapters.tb_stock_lot_sizeTableAdapter();
                DataTable dt = lot_size_adapter.GetDataBySymbol(symbol);
                if (dt.Rows.Count > 0)
                {
                    lotSize = Convert.ToInt32(dt.Rows[0]["lotSize"]);
                }
                else
                {
                    lotSize = 100;
                }

                if (marketInfoBarList.Count > 31)
                {
                    features = featureConstructor(marketInfoBarList);
                    modelPrediction = ModelExecutor.DoublePrecision(modelFilePath, features);
                    Navigator dataBaseNavigator = StrategySelByLarry.PeriodicUtils.GetDatabaseNavigator(marketInfoBarList);
                    List<int[]> tradeSignals = container.simulator.GetTradeSignals(dataBaseNavigator);

                    for (int straIdx = 0; straIdx < modelPrediction[modelPrediction.Count - 1].Count; straIdx++)
                    {
                        moneyOnHand[straIdx] += moneyAssignPerPeriod * modelPrediction[modelPrediction.Count - 1][straIdx];
                        if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 1)
                        {
                            int temp_share = Convert.ToInt32(Math.Floor(moneyOnHand[straIdx] / Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close))) / lotSize;
                            int share = temp_share * lotSize;
                            double takeProfit = Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) + container.simulator.takeProfitNStopLoss[straIdx][0];
                            double stopLoss = Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) - container.simulator.takeProfitNStopLoss[straIdx][1];
                            moneyOnHand[straIdx] = moneyOnHand[straIdx] - share * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                            tradingRecords.Add(Tuple.Create<int, double, double, int, int>(share, takeProfit, stopLoss, straIdx, marketInfoBarList.Count - 1));
                        }
                        else if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 2)
                        {
                            int temp_share = Convert.ToInt32(Math.Ceiling(-moneyOnHand[straIdx] / Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close))) / lotSize;
                            int share = temp_share * lotSize;
                            double takeProfit = Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) - container.simulator.takeProfitNStopLoss[straIdx][3];
                            double stopLoss = Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) + container.simulator.takeProfitNStopLoss[straIdx][4];
                            moneyOnHand[straIdx] += -share * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 - commissionFeeNTax);
                            tradingRecords.Add(Tuple.Create<int, double, double, int, int>(share, takeProfit, stopLoss, straIdx, marketInfoBarList.Count - 1));
                        }
                        else if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 3)
                        {
                            if (tradingRecords.Count > 0)
                            {
                                for (int record = 0; record < tradingRecords.Count - 1; record++)
                                {
                                    if (tradingRecords[record].Item1 > 0 && tradingRecords[record].Item4 == straIdx)
                                    {
                                        moneyOnHand[straIdx] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                                        tradingRecords.RemoveAt(record);
                                    }
                                }
                            }
                        }
                        else if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 4)
                        {
                            if (tradingRecords.Count > 0)
                            {
                                for (int record = 0; record < tradingRecords.Count; record++)
                                {
                                    if (tradingRecords[record].Item1 < 0 && tradingRecords[record].Item4 == straIdx)
                                    {
                                        moneyOnHand[straIdx] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                                        tradingRecords.RemoveAt(record);
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine(data.Time + " " + (DateTime.Now - data.Time).TotalMilliseconds + "ms " + data.Symbol + " " + data.TickLevel + " " + data.LastPrice);
                }

                if (tradingRecords.Count > 0)
                {
                    for (int record = 0; record < tradingRecords.Count; record++)
                    {
                        if ((tradingRecords[record].Item1 > 0) && (tradingRecords[record].Item2 <= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].High)) && (tradingRecords[record].Item5 < (marketInfoBarList.Count - 1)))
                        {
                            moneyOnHand[tradingRecords[record].Item4] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                            tradingRecords.RemoveAt(record);
                        }
                        else if ((tradingRecords[record].Item1 > 0) && (tradingRecords[record].Item3 >= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Low)) && (tradingRecords[record].Item5 < (marketInfoBarList.Count - 1)))
                        {
                            moneyOnHand[tradingRecords[record].Item4] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                            tradingRecords.RemoveAt(record);
                        }
                        else if ((tradingRecords[record].Item1 < 0) && (tradingRecords[record].Item2 >= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Low)) && (tradingRecords[record].Item5 < (marketInfoBarList.Count - 1)))
                        {
                            moneyOnHand[tradingRecords[record].Item4] -= tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                            tradingRecords.RemoveAt(record);
                        }
                        else if ((tradingRecords[record].Item1 < 0) && (tradingRecords[record].Item2 <= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].High)) && (tradingRecords[record].Item5 < (marketInfoBarList.Count - 1)))
                        {
                            moneyOnHand[tradingRecords[record].Item4] -= tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close);
                            tradingRecords.RemoveAt(record);
                        }
                    }
                }

                if (tradingRecords.Count == 0)
                {
                    positionTracker.Add(0);
                }
                else
                {
                    int position = 0;
                    for (int record = 0; record < tradingRecords.Count; record++)
                    {
                        position += tradingRecords[record].Item1;
                    }
                    positionTracker.Add(position);
                }

                if (positionTracker.Count == 1)
                {
                    Console.WriteLine(positionTracker[0]);
                }
                else
                {
                    if ((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) > 0)
                    {
                        string strategy = null;
                        string orderAction = "buy";
                        string tradeAction = null;
                        int quantity = Math.Abs(positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]);
                        decimal signalprice = marketInfoBarList[marketInfoBarList.Count - 1].Close;
                        DateTime signalTime = DateTime.Now;
                        int executionFlag = 0;

                        machine_signal_adapter.InsertQuery(strategy, symbol, exchange, orderAction, tradeAction, quantity, signalprice, signalTime, null, executionFlag);
                        Console.WriteLine((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) + " " + marketInfoBarList[marketInfoBarList.Count - 1].Symbol);
                    }
                    else if ((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) < 0)
                    {
                        string strategy = null;
                        string orderAction = "sell";
                        string tradeAction = null;
                        int quantity = Math.Abs(positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]);
                        decimal signalprice = marketInfoBarList[marketInfoBarList.Count - 1].Close;
                        DateTime signalTime = DateTime.Now;
                        int executionFlag = 0;

                        machine_signal_adapter.InsertQuery(strategy, symbol, exchange, orderAction, tradeAction, quantity, signalprice, signalTime, null, executionFlag);
                        Console.WriteLine((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) + " " + marketInfoBarList[marketInfoBarList.Count - 1].Symbol);
                    }
                    else if ((positionTracker[positionTracker.Count - 1] - positionTracker[positionTracker.Count - 2]) == 0)
                    {
                        Console.WriteLine("No Trade");
                    }

                    Console.WriteLine("moneyOnHand:" + " " + String.Join(" ", moneyOnHand));
                    if (moneyAssignPerPeriod * (marketInfoBarList.Count - 31) > 0)
                    {
                        Console.WriteLine("Total Money Invested:" + " " + moneyAssignPerPeriod * (marketInfoBarList.Count - 31));
                    }
                    else
                    {
                        Console.WriteLine("Total Money Invested:" + " " + 0);
                    }
                    Console.WriteLine("portfolio:" + " " + (moneyOnHand.Sum() + positionTracker[positionTracker.Count - 1] * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close)));
                    Console.WriteLine("prev_shareOnHand:" + " " + positionTracker[positionTracker.Count - 2]);
                    Console.WriteLine("shareOnHand:" + positionTracker[positionTracker.Count - 1]);
                }
                #endregion
            }
        }

        private static List<List<double>> featureConstructor(List<Bar> marketInfoBarList)
        {
            List<List<double>> featuresList = new List<List<double>>();

            ScriptOutput o = new ScriptOutput();
            o.License = "XRT93NQR79ABTW788XR48";

            foreach (Bar bar in marketInfoBarList)
            {
                o.AppendRecord(bar.Time,
                    Convert.ToDouble(bar.Open), Convert.ToDouble(bar.High), Convert.ToDouble(bar.Low), Convert.ToDouble(bar.Close),
                    Convert.ToInt64(bar.Volume));
            }

            List<TaSdkField> fields = new List<TaSdkField>(o.GetScriptOutput("HVI(CLOSE,30,60480,1) + R2(CLOSE,30) + SLOPE(CLOSE,30) + AVG(VOLUME,30) + VO(12,26,EXPONENTIAL,PERCENT)"));
            for (int i = 0; i < fields.First().Data.Count; i++)
            {
                List<double> period = new List<double>();
                for (int j = 1; j < fields.Count(); j++)
                {
                    if (Double.IsNaN(fields[j][i]))
                    {
                        period.Add(0);
                    }
                    else
                    {
                        period.Add(fields[j][i]);
                    }
                }

                featuresList.Add(period);
            }

            StreamReader meanStdFile = new StreamReader(@"..\..\..\..\StrategySelByLarry\bin\Release\MeanStd.txt");
            int rowIndex = 0;
            string line;
            List<double> meanX = new List<double>();
            List<double> stdX = new List<double>();
            List<double> numOfX = new List<double>();
            while ((line = meanStdFile.ReadLine()) != null)
            {
                if (rowIndex == 0)
                {
                    List<string> slicingMeanX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingMeanX.Count; i++)
                    {
                        meanX.Add(Convert.ToDouble(slicingMeanX[i]));
                    }
                    rowIndex++;
                }
                else if (rowIndex == 1)
                {
                    List<string> slicingStdX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingStdX.Count; i++)
                    {
                        stdX.Add(Convert.ToDouble(slicingStdX[i]));
                    }
                    rowIndex++;
                }
                else if (rowIndex == 2)
                {
                    List<string> slicingNumOfX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingNumOfX.Count; i++)
                    {
                        numOfX.Add(Convert.ToDouble(slicingNumOfX[i]));
                    }
                    rowIndex++;
                }
                else
                {
                    break;
                }
            }

            for (int period = 0; period < featuresList.Count; period++)
            {
                for (int elementIdx = 0; elementIdx < featuresList[period].Count; elementIdx++)
                {
                    if (stdX[elementIdx] == 0)
                    {
                        featuresList[period][elementIdx] = 0;
                    }
                    else
                    {
                        double tempMean = meanX[elementIdx];
                        numOfX[elementIdx] = numOfX[elementIdx] + 1;
                        meanX[elementIdx] = meanX[elementIdx] + (featuresList[period][elementIdx] - meanX[elementIdx]) / numOfX[elementIdx];
                        stdX[elementIdx] = stdX[elementIdx] + (featuresList[period][elementIdx] - tempMean) * (featuresList[period][elementIdx] - meanX[elementIdx]);
                        featuresList[period][elementIdx] = (featuresList[period][elementIdx] - meanX[elementIdx]) / stdX[elementIdx];
                    }
                }
            }

            return featuresList;
        }
    }
}
