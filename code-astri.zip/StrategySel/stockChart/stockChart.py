from pylab import *
from matplotlib.finance import candlestick2_ohlc
from datetime import datetime

fname = 'Strategy14_BuyNSellPicture.txt'

with open(fname) as f:
    content = f.readlines()

quotes = []

for line in content:
    quotes.append(line.split(','))

del quotes[0]

Datetimes = []
Opens = []
Closes = []
Highs = []
Lows = []
Actions = []

for line in quotes:
    Datetimes.append(datetime.strptime(line[0], "%m/%d/%Y %H:%M"))
    Opens.append(float(line[1]))
    Closes.append(float(line[2]))
    Highs.append(float(line[3]))
    Lows.append(float(line[4]))
    Actions.append(int(line[5]))

fig, ax = subplots()
candlestick2_ohlc(ax, Opens, Highs, Lows, Closes, width=0.5, colorup='black', colordown='red', alpha=0.75)
ax.autoscale_view()

Index = 0
for action in Actions:
    if action == 2:
        h = Highs[Index]
        d = Index
        ax.annotate('Buy', xy = (d-1,h), xytext = (d-1, h+0.003), arrowprops = dict(facecolor='red',width=1,shrink=0.25))
    elif action == 3:
        h = Highs[Index]
        d = Index
        ax.annotate('Sell', xy = (d-1,h), xytext = (d-1, h+0.003), arrowprops = dict(facecolor='yellow',width=1,shrink=0.25))
    Index = Index + 1

# ax.autoscale_view()

plt.show()

