Strategy Selection Project
======
###Structure###

Strategy Selection is a project meant to select and recommende a strategy at the moment, according to historical information. The project is divided into 3 parts

  - SelectSel (c#): generating training dataset
  - GUIDesign (c#): making recommendation using the trained model
  - cntk (c++): cloned cntk source code developed by Microsoft
  - tra-stra.py: simple logestic regression implement of the training module
  - ZScript: the wiki generator

### Versions
 - V1.0 Jul 10, 2015: Profit at minute-interval data
 - V1.1 Aug 15, 2015: Code now extendable
 - V1.2 Aug 27, 2015: Add some test on daytrading data and wavelet
 - V1.4.1 Sep 1, 2015: Minors
 - V1.4.2 Sep 2, 2015: Minors
 - V1.4.3 Dec 26, 2015: GUI bug fixes
 - V?.? May 26, 2016: Support ZScript strategies
 - V?.? May ?, 2016: Adopt pure Windows+CC/CS environment

### Dependencies

Some non-public dependencies in dll format are needed to run the program. They should be put into the binary path, or otherwise specified. Note that the dll at your hand with the same name may **not** be the needed one, use those from *StrategySel/lib* instead.
 - GTADatabase.dll
 - AxiomObjects.dll
 - TASDK.dll
 - Modulus.License.dll
 - Modulus.TradeScript.dll

### Generate Trainingset

To generate a trainingset using solution StrategySel, it's necessary to install json and numerics packages using NuGet or otherwise. 

```sh
PM> Install-Package Newtonsoft.Json
PM> Install-Package MathNet.Numerics
```

Some files are necessary. Examples are under code branch.

  - symbols: The file "symbols" indecates the list of symbols we are going to test on. One symbol per line formatted as [symbol]-[market][space][name], for example "000001-SZSE 平安银行". [symbol] and [market] follow the convention in GTADatabase
  - strategy.ini: See next section
  - config.ini: It configs the GTADatabase.dll, which should be like the following script with proper authentication and log capacity

```sh
[SQLServer]
url=
username=
password=

[Log]
output_path=
```

In solution StrategySel, under class StrategySel::Program, 3 functions are available. Each will dump a trainingset using a series of build-in parameters. To change the parameters please write your own session in "TestIni.ini" file under the binary's location.

* [MiniuteInterval] - Evaluate the performance of the strategies minute-by-minute and record their profitability at every moment.
* [DayInterval] - Day-by-day evaluation
* [DayWavelet] - This generate the profitability of Moving Average Crossover strategy w/ diffeerent periods. It's intended to test the best or most active period of the market.

You can change the corresponding session (e.g. day, minute) to modify the settings. Note that a instance of Simulator will be initialized in each function, you can also change the instance and its strategies loaded to simulate different strategies.

### strategy.ini Attributes

 - [Session Name] - The name of your customized dataset. The output file will be named after Session Name followed by suffixes.
 - Market - The string filtering the market so that symbols not in the selected market will be ignored. Market name should be "SZSE" for Shenzhen, "SSZ" for Shanghai, or otherwise recognized by GTADatabase. Put Market into "ANY" will skip this tag. Default "SZSE".
 - CommissionFeeNTax - The summation of commission fees, taxes, and otherwise contributing to the transaction cost. Default 0.0021
 - Precision - The number of digits after decimal recorded in the output dataset. Default 7
 - Decay - The Decay value in simulation indicating the extent we care about of the performance on the bars immediately after evoking the trade signals, than the bars coming in the future. Ranging in [0,1] the lower the more. Default 0.95
 - WindowLength - The maximum number of bars looking forward after evoking a trade strategy in backtest.
 - ExplorationLength - The number of bars at the begining of each sequence where a trade strategy will not general trade signals.
 - TrailLength - The number of bars at the end of each sequence where a trade strategy will no longer be evaluated because of the lack of incoming bars.
 - MinimumGap - The absolute difference of prices of most diversed 2 bars in a sequence that we can afford. If that difference is lower than MinimumGap, the sequence will be discarded because of lack of volatility. Default 0.15
 - MinimumVolume - The minimum total amount of volume in a sqeuence we can afford. Default 2e6
 - TotalSequences - The maximum number of sequences one wants to dump. Must be specified.

### Training (Python, deprecated)

To train the model using the python script, you need to first install numpy and theano, using pip for example, or otherwise

```sh
$ pip install -U numpy
$ pip install -U theano
```

Then execute the python code using python3. it's expected to finish quickly (< 1min). The output will be in the file 'model', in a human-understandable format.

```sh
python tra-stra.py
```

### Acknowledgement

I'd express my gratitude to Jihyoun, Kelly, Carlos.J, Carlos.S, James, Kent, Matt, Zuyao for your invaluable help. It's you guys making my intership a memorable experience.

The idea of trading strategy selection is from Kelly and James.

### Todos

 - Tracker return <reward, networthtrack> pair instead of reward
 - integrate zscript and make it on gui
 - give gui zscript evaluator and require helper to make strategies
 - work on "ticktest" and "tickutils"
 - make tick strategies protocols and some examples

License
----

 - The project was developed by Wang Baoxiang when he was an intern in ASTRI Inc. as a student intern. Codes and data are confidential. No unauthorised use allowed.
