# CNTK Setup

Eventually what we need is a cntk.exe binary, which is used to process the NDL configure files. One of the applicable ways is to clone the cntk repository from github, and manually build the code following [the official guide](https://github.com/Microsoft/CNTK/wiki/Setup-CNTK-on-Windows). We give some further hints.
 - Make sure you have Visual Studio 2013, standing alone **without** a Visual Studio 2012 or lower aside. Update your visual studio to latest subversion under 2013
 - Make sure your system language is English, and system locale set to English. Also the system must be 64-bit
 - For environment variable settings *setx*, make sure **not** to add /M option, also **not** to use administrative powershell/cmd
 - Skip *opencv*, *libzip* and *zlib* if not needed. Basically, skip everything optional dependencies that is not necessary
 - Clone the source tree with *git clone https://github.com/Microsoft/cntk*; If you already have cntk submodule pulled, simply run *git pull* in the submodule to save some time.
 - Build the code with the *release* option, and find the cntk.exe binary in release path of the solution directory.
 
# Additional Information for GPU Build
 - First of first, make sure you have a GPU better than Nvidia Pascal 1070. If not, use the CPU build instead.
