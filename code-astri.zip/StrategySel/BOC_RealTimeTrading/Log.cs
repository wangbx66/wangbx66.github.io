﻿using AxiomObjects;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace BOC_RealTimeTrading
{
    public class Log
    {
        private static StreamWriter streamWriterLog = null;
        //private static string path = "c:\\temp";
        private static Configure config = new Configure();
        private static string path = config.Log.outputPath == null || config.Log.outputPath.Equals("") ? "c:\\temp" : config.Log.outputPath;

        private static string programName = string.Empty;

        public Log()
        {
        }

        public static void trace(string line)
        {
            if (config.Log.trace_function == 1)
            {
                string flag = string.Empty;
                write(line, flag);
            }
        }

        public static void debug(string line)
        {
            string flag = string.Empty;
            write(line, flag);
        }

        public static void Info(string line)
        {
            string flag = string.Empty;
            write(line, flag);
        }

        public static void Warn(string line)
        {
            string flag = "Warn: ";
            write(line, flag);
        }

        public static void Error(string line)
        {
            string flag = "Error: ";
            write(line, flag);
        }

        private static int write(string line, string flag)
        {
            lock (path)
            {
                if (streamWriterLog == null)
                {
                    //create path
                    if (Directory.Exists(path) == false)
                    {
                        Directory.CreateDirectory(path);
                    }

                    //create file
                    //string strLastDateTime = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
                    string strLastDateTime = DateTime.Now.ToString("yyyy-MM-dd");
                    string[] prgPath = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName.Split('\\');
                    //string fullName = prgPath.Length > 0 ? prgPath[prgPath.Length - 1].Split('.')[0] : string.Empty;

                    programName = prgPath.Length > 0 ? prgPath[prgPath.Length - 1].Split('.')[0] : programName;
                    
                    string fileName = path + "\\" + strLastDateTime + "_" + programName + "_" + Process.GetCurrentProcess().Id + ".log";
                    //string fileName = path + "\\" + strLastDateTime  + ".log";
                    streamWriterLog = new StreamWriter(fileName, true, Encoding.UTF8);


                    streamWriterLog.WriteLine(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName + "\r\n");
                }

                string nowTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffff");

                streamWriterLog.WriteLine(nowTime + ": " + flag  + line + "\r\n");
                //streamWriterLog.WriteLine(nowTime + ": " + " ThreadId=" + Thread.CurrentThread.ManagedThreadId + ": " + line + "\r\n");
                streamWriterLog.Flush();
            }

            return 0;
        }
    }
}
