﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using System.Data;

namespace BOC_RealTimeTrading
{
    class UnusualSeqChecker
    {
        public UnusualSeqChecker()
        {
            ;
        }

        public void MinuteSeqVolumeCheck(List<AxiomObjects.Bar> tradingBars)
        {
            double length = tradingBars.Count;
            int halfLength = Convert.ToInt32(Math.Ceiling((length / 2)));
            int zeroVolumeBarsCount = 0;
            for (int period = 0; period < tradingBars.Count; period++)
            {
                if (tradingBars[period].Volume == 0)
                {
                    zeroVolumeBarsCount++;
                }
            }

            if (zeroVolumeBarsCount > halfLength)
            {
                string errorString = String.Format("Detected {0} bars with 0 volume which exceed half of the barList({1})", zeroVolumeBarsCount + 1, halfLength + 1); 
                Log.Error(errorString);
                Environment.Exit(0);
            }
        }

        public void SymbolCheck(List<AxiomObjects.Bar> tradingBars)
        {
            lotsizedbTableAdapters.tb_stock_staticTableAdapter tb_stock_staticTableAdapter = new lotsizedbTableAdapters.tb_stock_staticTableAdapter();
            lotsizedbTableAdapters.tb_stock_lot_sizeTableAdapter tb_stock_lot_sizeTableAdapter = new lotsizedbTableAdapters.tb_stock_lot_sizeTableAdapter();

            string symbol = tradingBars[0].Symbol.Split('-')[0];
            string exchange = tradingBars[0].Symbol.Split('-')[1];

            DataTable chineseStock = tb_stock_staticTableAdapter.GetDataBySymbolNExchange(symbol, exchange);
            DataTable hkStock = tb_stock_lot_sizeTableAdapter.GetDataBySymbolNExchange(symbol, exchange);

            if ((chineseStock.Rows.Count == 0 && hkStock.Rows.Count == 0) || (chineseStock.Rows.Count > 1 || hkStock.Rows.Count > 1))
            {
                string errorString = String.Format("{0} records detected from tb_stock_lot_size AND {1} records detected from tb_stock_static", chineseStock.Rows.Count, hkStock.Rows.Count);
                Log.Error(errorString);
                Environment.Exit(0);
            }
        }
    }
}
