﻿namespace BOC_RealTimeTrading {
    
    
    public partial class lotsizedb {
    }
}
