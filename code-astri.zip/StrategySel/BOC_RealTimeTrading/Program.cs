﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;
using System.Configuration;

namespace BOC_RealTimeTrading
{
    class Program
    {
        static void Main(string[] args)
        {
            DataAPIRealTime("600623-SSE");
        }

        static void DataAPIRealTime(string symbol = "")
        {
            var exitEvent = new ManualResetEvent(false);
            Console.CancelKeyPress += (sender, eventArgs) =>
            {
                eventArgs.Cancel = true;
                exitEvent.Set();
            };

            RealTimeHandler realTimeHandler = new RealTimeHandler(symbol);

            string mqServer = ConfigurationManager.AppSettings["MqServer"];
            ushort mqPort = Convert.ToUInt16(ConfigurationManager.AppSettings["MqPort"]);
            string mqUser = ConfigurationManager.AppSettings["MqUser"];
            string mqPassword = ConfigurationManager.AppSettings["MqPassword"];
            string requestQueue = ConfigurationManager.AppSettings["RequestQueue"];
            string httpServer = ConfigurationManager.AppSettings["DataStoreManagerIp"];
            ushort httpPort = Convert.ToUInt16(ConfigurationManager.AppSettings["DataStoreManagerPort"]);

            DataAPI.DataAPI api = new DataAPI.DataAPI(mqServer, mqPort, mqUser, mqPassword, requestQueue, httpServer, httpPort, realTimeHandler.StockDataHandler);
            api.Start();
            Console.WriteLine("API started");

            //api.SubscribeBar("601988-SSE", '1');
            //api.Subscribe("601988-SSE", '1');
            //api.SubscribeBar("IF1610-CFFEX", '1');
            //api.Subscribe("IF1610-CFFEX", '1');
            api.Subscribe(symbol, '1');

            exitEvent.WaitOne();
            api.Stop();
            Console.WriteLine("DataAPI Console Stopped");
        }
    }
}
