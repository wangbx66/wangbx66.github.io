﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AxiomObjects;
using ModulusFE.TASDK;
using System.Configuration;
using ATPluginInterface;

namespace BOC_RealTimeTrading
{
    public class InfoContainer
    {
        public TrainingDataDump.Simulator simulator;

        public InfoContainer()
        {
            int maxStrategiesNum = 8;
            simulator = new TrainingDataDump.Simulator();
            //simulator.LoadDefault();
            TrainingDataDump.StrategiesReader strategiesReader = new TrainingDataDump.StrategiesReader();
            strategiesReader.csvStrategiesLoader(simulator, maxStrategiesNum);
        }
    }

    class RealTimeHandler
    {
        static string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
        int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, "minute", "ExplorationLength", "30"));
        int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, "minute", "TrailLength", "0"));
        int minimumPeriods = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, "minute", "minimumPeriods", "30"));

        List<Bar> marketInfoBarList = new List<Bar>();
        List<Bar> historicalTradingSymbolBarsList = new List<Bar>();
        List<Bar> tradingSymbolBarsList = new List<Bar>();
        string modelFilePath = @"..\..\..\..\CNTK_StrategySel\Models\Trained_StrategySel_Model.dnn";
        //string strategyName = "LarryModel";

        static InfoContainer container = new InfoContainer();
        TrainingDataDump.DataCleaner dataCleaner = new TrainingDataDump.DataCleaner();

        static OrderSender.OrderSender mqClient;
        TradeClient.TradeClient TC;
        UserIdentity uInfo = new UserIdentity();
        int brokerAccountID = 5;
        string brokerAccountName = "BOCCNY";
        string brokerAccountType = Constants.BROKER_TYPE_BOC;
        bool allowToTrade = false;

        string symbol;
        int seqLength = 241 * 39;
        double moneyRemained;
        double commissionFeeNTax = 0.003;
        int realPosition;
        List<double> moneyInvested = new List<double>(new double[container.simulator.strategies.Count]);
        List<double> orderMoney = new List<double>(new double[container.simulator.strategies.Count]);
        List<Tuple<int, double, double, int, DateTime>> tradingRecords = new List<Tuple<int, double, double, int, DateTime>>();
        List<Tuple<int, double, double, int, DateTime>> recordsToBeRemoved;
        List<int> positionTracker = new List<int>();
        TimeSpan seqSpan = TimeSpan.FromDays(1);
        int interval = 1;

        public RealTimeHandler(string symbol = "")
        {
            this.symbol = symbol;

            ////////////////////////////////////////
            //DataAPI to get one day historical data from now
            string mqServer = ConfigurationManager.AppSettings["MqServer"];
            ushort mqPort = Convert.ToUInt16(ConfigurationManager.AppSettings["MqPort"]);
            string mqUser = ConfigurationManager.AppSettings["MqUser"];
            string mqPassword = ConfigurationManager.AppSettings["MqPassword"];
            string requestQueue = ConfigurationManager.AppSettings["RequestQueue"];
            string httpServer = ConfigurationManager.AppSettings["DataStoreManagerIp"];
            ushort httpPort = Convert.ToUInt16(ConfigurationManager.AppSettings["DataStoreManagerPort"]);

            DataAPI.DataAPI api = new DataAPI.DataAPI(mqServer, mqPort, mqUser, mqPassword, requestQueue, httpServer, httpPort, null);

            DateTime historicalStart = DateTime.Today.Subtract(seqSpan);
            DateTime historicalEnd = DateTime.Today;
            do
            {
                historicalStart = historicalStart - seqSpan;
                historicalEnd = historicalEnd - seqSpan;
            } while (api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval).Count <= minimumPeriods);
            historicalTradingSymbolBarsList = api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval);

            marketInfoBarList = api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval);

            /////////////////////////////////////////
            //TradeClient related
            mqClient = new OrderSender.OrderSender("10.6.88.26", 61616, "ORDER_Larry_1", 10000);
            TC = new TradeClient.TradeClient("Amir_test", infoCallBack, mqClient);
            mqClient.ReceivedReplyHandler = TC.infoCallback;
            mqClient.Start();

            uInfo.UserAccountName = "ddd@astri.org";
            uInfo.Password = "ddd@astri.org";

            TC.Login(uInfo);
        }

        public void StockDataHandler(object o)
        {
            if (o is Bar)
            {
                Bar data = o as Bar;
                marketInfoBarList.Add(data);
                tradingSymbolBarsList.Add(data);

                                //data smothing
                //currently, method SmothData_test do nothing at all, should be developed in the future if keep position to next day
                dataCleaner.SmothData_test(marketInfoBarList);

                Console.WriteLine("");
                Console.WriteLine(data.Time + " " + data.Symbol + " " + data.Close);

                TradingRecordHandler tradingRecordHandler = new TradingRecordHandler(seqLength, explorationLength, trailLength, commissionFeeNTax, container);

                if (tradingSymbolBarsList.Count <= minimumPeriods)
                {
                    ///////////////////////////////////////////////////
                    ////////should be decided if close when market open
                    /*
                    if (allowToTrade && realPosition > 0)
                    {
                        MTPA_SOrder3 order = new MTPA_SOrder3()
                        {
                            Action = MTPA_OrdrActn.eMTPA_OA_Sell,

                            Type = MTPA_OrdrType.eMTPA_OT_Exit,

                            Category = MTPA_OrdrCtgry.eMTPA_OC_Limit,

                            Quantity = realPosition,

                            StopPrice = 0.0,

                            LimitPrice = 0.0,

                            FromEntryID = 0,

                            ReplacedOrderID = 0,

                            tag = 0,

                            TIFType = MTPA_OrdrTimeInForce.eMTPA_TIF_GTC,
                        };

                        TC.PlaceOrder(TC.LoginedUser, symbol, order, new TradeDecisionExecute());
                    }
                    */
                }
                else if (tradingSymbolBarsList.Count > minimumPeriods && tradingSymbolBarsList.Count < seqLength - trailLength)
                {
                    ///////////////
                    ///////////////Currently We do not handle unusual event check, should be further developed
                    /*
                    UnusualSeqChecker checker = new UnusualSeqChecker();
                    checker.MinuteSeqVolumeCheck(marketInfoBarList);
                    checker.SymbolCheck(marketInfoBarList);
                    */

                    LotsizedbHandler lotsizedbHandler = new LotsizedbHandler();
                    int lotsize = lotsizedbHandler.GetLotsize(historicalTradingSymbolBarsList);

                    TrainingDataDump.FeaturesSource featuresSource = new TrainingDataDump.FeaturesSource();
                    PerformanceEvaluation.FeaturesConstructor constructor = new PerformanceEvaluation.FeaturesConstructor();
                    //get model prediction
                    List<Dictionary<DateTime, List<double>>> timeDominFeaturesList = new List<Dictionary<DateTime, List<double>>>();
                    timeDominFeaturesList.Add(featuresSource.TradeScript_Indicator(tradingSymbolBarsList, historicalTradingSymbolBarsList, marketInfoBarList));
                    List<List<double>> marketInfo = constructor.TimeDominFeaturesConstructor(timeDominFeaturesList);
                    List<List<float>> marketInfo_Float = dataCleaner.FeaturesList_ChangeToFloat(marketInfo);
                    List<List<float>> modelPrediction = PerformanceEvaluation.ModelExecutor.FloatPrecision(modelFilePath, marketInfo_Float);

                    Navigator dataBaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(marketInfoBarList);
                    List<int[]> tradeSignals = container.simulator.GetTradeSignals(dataBaseNavigator);
                    dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBarsList);

                    tradingRecordHandler.tradingSymbolBarsList = tradingSymbolBarsList;
                    tradingRecordHandler.modelPrediction = modelPrediction;
                    tradingRecordHandler.tradeSignals = tradeSignals;
                    tradingRecordHandler.lotSize = lotsize;
                    //tradingRecordHandler.MoneyRecoverCheck(marketInfoBarList, strategyName, moneyInvested, orderMoney);
                    tradingRecordHandler.GenerateTradingRecord(moneyInvested, moneyRemained, tradingRecords, recordsToBeRemoved, orderMoney);
                    tradingRecordHandler.TakeProfitNStopLossCheck(tradingRecords, recordsToBeRemoved, marketInfoBarList, moneyInvested, orderMoney);
                    tradingRecordHandler.PositioinCalculate(tradingRecords, positionTracker);
                    tradingRecordHandler.OrderPlacement(positionTracker, realPosition, TC, allowToTrade, symbol);
                }
                else
                {
                    ;
                }
            }
            else if (o is MarketData)
            {
                MarketData data = o as MarketData;
                Bar temp = new Bar();
                temp.Time = data.Time;
                temp.Symbol = data.Symbol;
                temp.Open = data.LastPrice;
                temp.High = data.LastPrice + 1;
                temp.Low = data.LastPrice - 1;
                temp.Close = data.LastPrice + Convert.ToDecimal(0.5);
                temp.Volume = data.LastVolume;
                marketInfoBarList.Add(temp);
                tradingSymbolBarsList.Add(temp);

                //data smothing
                //currently, method SmothData_test do nothing at all, should be developed in the future if keep position to next day
                dataCleaner.SmothData_test(marketInfoBarList);

                Console.WriteLine("");
                Console.WriteLine(data.Time + " " + (DateTime.Now - data.Time).TotalMilliseconds + "ms " + data.Symbol + " " + data.TickLevel + " " + data.LastPrice);

                TradingRecordHandler tradingRecordHandler = new TradingRecordHandler(seqLength, explorationLength, trailLength, commissionFeeNTax, container);

                if (tradingSymbolBarsList.Count <= minimumPeriods)
                {
                    ///////////////////////////////////////////////////
                    ////////should be decided if close when market open
                    /*
                    if (allowToTrade && realPosition > 0)
                    {
                        MTPA_SOrder3 order = new MTPA_SOrder3()
                        {
                            Action = MTPA_OrdrActn.eMTPA_OA_Sell,

                            Type = MTPA_OrdrType.eMTPA_OT_Exit,

                            Category = MTPA_OrdrCtgry.eMTPA_OC_Limit,

                            Quantity = realPosition,

                            StopPrice = 0.0,

                            LimitPrice = 0.0,

                            FromEntryID = 0,

                            ReplacedOrderID = 0,

                            tag = 0,

                            TIFType = MTPA_OrdrTimeInForce.eMTPA_TIF_GTC,
                        };

                        TC.PlaceOrder(TC.LoginedUser, symbol, order, new TradeDecisionExecute());
                    }
                    */
                }
                else if (tradingSymbolBarsList.Count > minimumPeriods && tradingSymbolBarsList.Count < seqLength - trailLength)
                {
                    ///////////////
                    ///////////////Currently We do not handle unusual event check, should be further developed
                    /*
                    UnusualSeqChecker checker = new UnusualSeqChecker();
                    checker.MinuteSeqVolumeCheck(marketInfoBarList);
                    checker.SymbolCheck(marketInfoBarList);
                    */

                    LotsizedbHandler lotsizedbHandler = new LotsizedbHandler();
                    int lotsize = lotsizedbHandler.GetLotsize(historicalTradingSymbolBarsList);

                    TrainingDataDump.FeaturesSource featuresSource = new TrainingDataDump.FeaturesSource();
                    PerformanceEvaluation.FeaturesConstructor constructor = new PerformanceEvaluation.FeaturesConstructor();
                    //get model prediction
                    List<Dictionary<DateTime, List<double>>> timeDominFeaturesList = new List<Dictionary<DateTime, List<double>>>();
                    timeDominFeaturesList.Add(featuresSource.TradeScript_Indicator(tradingSymbolBarsList, historicalTradingSymbolBarsList, marketInfoBarList));
                    List<List<double>> marketInfo = constructor.TimeDominFeaturesConstructor(timeDominFeaturesList);
                    List<List<float>> marketInfo_Float = dataCleaner.FeaturesList_ChangeToFloat(marketInfo);
                    List<List<float>> modelPrediction = PerformanceEvaluation.ModelExecutor.FloatPrecision(modelFilePath, marketInfo_Float);

                    Navigator dataBaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(marketInfoBarList);
                    List<int[]> tradeSignals = container.simulator.GetTradeSignals(dataBaseNavigator);
                    dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBarsList);

                    tradingRecordHandler.tradingSymbolBarsList = tradingSymbolBarsList;
                    tradingRecordHandler.modelPrediction = modelPrediction;
                    tradingRecordHandler.tradeSignals = tradeSignals;
                    tradingRecordHandler.lotSize = lotsize;
                    //tradingRecordHandler.MoneyRecoverCheck(marketInfoBarList, strategyName, moneyInvested, orderMoney);
                    tradingRecordHandler.GenerateTradingRecord(moneyInvested, moneyRemained, tradingRecords, recordsToBeRemoved, orderMoney);
                    tradingRecordHandler.TakeProfitNStopLossCheck(tradingRecords, recordsToBeRemoved, marketInfoBarList, moneyInvested, orderMoney);
                    tradingRecordHandler.PositioinCalculate(tradingRecords, positionTracker);
                    tradingRecordHandler.OrderPlacement(positionTracker, realPosition, TC, allowToTrade, symbol);
                }
                else
                {
                    ;
                }
            }
        }

        private void infoCallBack(Information info)
        {
            try
            {
                if (info.Type.Equals(AxiomObjects.Constants.AUTHEN_REPLY))
                {
                    RlyAuthenUserAccountInfo rlyInfo = (RlyAuthenUserAccountInfo)info;

                    if(rlyInfo.connectSuccess)
                    {
                        List<BrokerAccount> brokerAccountList = rlyInfo.BrokerAccs;
                        List<CapitalAccount> capitalAccountList = rlyInfo.CapitalAccs;
                        List<TradePosition> tradePositionList = rlyInfo.PrevPositionsV2;

                        foreach(BrokerAccount ba in brokerAccountList)
                        {
                            if (ba.BrokerAccountID == brokerAccountID && ba.BrokerAccountName == brokerAccountName && ba.BrokerAccountType.ToString() == brokerAccountType)
                            {
                                uInfo = rlyInfo.UserIdentity;
                                uInfo.ChoosedBrokerAccountID = ba.BrokerAccountID;
                                uInfo.ChoosedBrokerAccountName = ba.BrokerAccountName;
                                uInfo.ChoosedBrokerAccountNo = uInfo.ChoosedBrokerAccountID.ToString();
                                uInfo.ChoosedBrokerAccountType = ba.BrokerAccountType.ToString();
                                TC.LoginedUser = uInfo;

                                string subAccountName = uInfo.UserAccountName + "-BOCCNY";

                                foreach (CapitalAccount ca in capitalAccountList)
                                {
                                    if (ca.SubAccountName == subAccountName && ca.BrokerAccountID == brokerAccountID)
                                    {
                                        moneyRemained = Convert.ToDouble(ca.ValidCash);
                                    }
                                }

                                foreach (TradePosition tp in tradePositionList)
                                {
                                    if (tp.BrokerAccountName == brokerAccountName && tp.BrokerAccountID == brokerAccountID && tp.Product == symbol)
                                    {
                                        realPosition = tp.Volume;
                                    }
                                }

                                allowToTrade = true;
                            }
                        }
                    }
                }
                else if (info.Type.Equals(AxiomObjects.Constants.TRADE_INFO_REPLY))
                {
                    ReplyTradeInfo rlyInfo = (ReplyTradeInfo)info;
                    
                    if (rlyInfo.status == MTPA_OrdrsStatus.eMTPA_OS_Filled)
                    {
                        List<double> orderMoney = new List<double>(new double[container.simulator.strategies.Count]);
                        recordsToBeRemoved = new List<Tuple<int, double, double, int, DateTime>>();
                        realPosition = rlyInfo.LongPositionV2.Volume;
                    }
                    else if (rlyInfo.status == MTPA_OrdrsStatus.eMTPA_OS_Rejected)
                    {
                        for (int orderMoneyIdx = 0; orderMoneyIdx < orderMoney.Count; orderMoneyIdx++)
                        {
                            moneyInvested[orderMoneyIdx] += orderMoney[orderMoneyIdx];
                        }
                        orderMoney = new List<double>(new double[container.simulator.strategies.Count]);

                        foreach (Tuple<int, double, double, int, DateTime> record in recordsToBeRemoved)
                        {
                            tradingRecords.Add(record);
                        }
                        recordsToBeRemoved = new List<Tuple<int, double, double, int, DateTime>>();

                        realPosition = rlyInfo.LongPositionV2.Volume;
                    }
                }
            }
            catch (Exception e)
            {
                Log.Error("Exception: " + e.ToString());
            }
        }
    }
}
