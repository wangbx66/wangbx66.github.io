﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;

namespace BOC_RealTimeTrading
{
    class LotsizedbHandler
    {
        public LotsizedbHandler()
        {
            ;
        }

        public int GetLotsize(List<AxiomObjects.Bar> tradingBars)
        {
            string symbol = tradingBars[0].Symbol.Split('-')[0];
            string exchange = tradingBars[0].Symbol.Split('-')[1];

            if (exchange == "SSE" || exchange == "SZSE")
            {
                lotsizedbTableAdapters.tb_stock_staticTableAdapter tb_stock_staticTableAdapter = new lotsizedbTableAdapters.tb_stock_staticTableAdapter();
                DataTable dt = tb_stock_staticTableAdapter.GetDataBySymbolNExchange(symbol, exchange);
                return Convert.ToInt32(dt.Rows[0]["lotSize"]);
            }
            else            
            {
                lotsizedbTableAdapters.tb_stock_lot_sizeTableAdapter tb_stock_lot_sizeTableAdapter = new lotsizedbTableAdapters.tb_stock_lot_sizeTableAdapter();
                DataTable dt = tb_stock_lot_sizeTableAdapter.GetDataBySymbolNExchange(symbol, exchange);
                return Convert.ToInt32(dt.Rows[0]["lotSize"]);
            }
        }
    }
}
