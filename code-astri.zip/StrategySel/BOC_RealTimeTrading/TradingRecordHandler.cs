﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

using ATPluginInterface;
using AxiomObjects;

namespace BOC_RealTimeTrading
{
    class TradingRecordHandler
    {
        public List<List<float>> modelPrediction;
        public List<int[]> tradeSignals;
        public List<AxiomObjects.Bar> tradingSymbolBarsList;
        int seqLength;
        int explorationLength;
        int trailLength;
        public int lotSize;
        double commissionFeeNTax;
        InfoContainer container;

        public TradingRecordHandler(int classSeqLength, int classExplorationLength, int classTrailLength, double classCommissionNTax, InfoContainer classContainer)
        {
            seqLength = classSeqLength;
            explorationLength = classExplorationLength;
            trailLength = classTrailLength;
            commissionFeeNTax = classCommissionNTax;
            container = classContainer;
        }

        public void MoneyRecoverCheck(List<AxiomObjects.Bar> tradingBars, string strategyName, List<double> moneyInvested, List<double> orderMoney)
        {
            string symbol = tradingBars[0].Symbol.Split('-')[0];
            string exchange = tradingBars[0].Symbol.Split('-')[1];

            lotsizedbTableAdapters.tb_machine_signalTableAdapter tb_machine_signalTableAdaptr = new lotsizedbTableAdapters.tb_machine_signalTableAdapter();
            DataTable unreviewRecord = tb_machine_signalTableAdaptr.GetUnreviewOrder(symbol, exchange, strategyName);

            if (unreviewRecord.Rows.Count > 1)
            {
                Log.Error(String.Format("{0} UnreviewRecord detected", unreviewRecord.Rows.Count));
                Environment.Exit(1);
            }
            else
            {
                if ((int)unreviewRecord.Rows[0]["executionFlag"] == 1)
                {
                    orderMoney = new List<double>(new double[container.simulator.strategies.Count]);
                    tb_machine_signalTableAdaptr.UpdateUnreviewOrderFlag(1, (int)unreviewRecord.Rows[0]["OrderID"]);
                }
                else
                {
                    for (int straIdx = 0; straIdx < moneyInvested.Count; straIdx++)
                    {
                        moneyInvested[straIdx] -= orderMoney[straIdx];
                    }
                    tb_machine_signalTableAdaptr.UpdateUnreviewOrderFlag(1, (int)unreviewRecord.Rows[0]["OrderID"]);
                }
            }
        }

        public void GenerateTradingRecord(List<double> moneyInvested, double moneyRemained, List<Tuple<int, double, double, int, DateTime>> tradingRecords, List<Tuple<int, double, double, int, DateTime>> recordsToBeRemoved, List<double> orderMoney)
        {
            PerformanceEvaluation.MoneyDistributor moneyDistributor = new PerformanceEvaluation.MoneyDistributor();

            for (int straIdx = 0; straIdx < modelPrediction[modelPrediction.Count - 1].Count; straIdx++)
            {
                moneyInvested[straIdx] += moneyDistributor.Realtime_EquallyDistribute(moneyRemained, tradingSymbolBarsList, explorationLength, trailLength, seqLength) * modelPrediction[modelPrediction.Count - 1][straIdx];
                moneyRemained -= moneyDistributor.Realtime_EquallyDistribute(moneyRemained, tradingSymbolBarsList, explorationLength, trailLength, seqLength) * modelPrediction[modelPrediction.Count - 1][straIdx];
                if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 1)
                {
                    int temp_share = Convert.ToInt32(Math.Floor(moneyInvested[straIdx] / Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) / (1 + commissionFeeNTax) / Convert.ToDouble(lotSize))) ;
                    int share = temp_share * lotSize;
                    double takeProfit = Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) + container.simulator.takeProfitNStopLoss[straIdx][0];
                    double stopLoss = Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) - container.simulator.takeProfitNStopLoss[straIdx][1];
                    moneyInvested[straIdx] = moneyInvested[straIdx] - share * Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) * (1 + commissionFeeNTax);
                    orderMoney[straIdx] = -share * Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) * (1 + commissionFeeNTax);
                    tradingRecords.Add(Tuple.Create<int, double, double, int, DateTime>(share, takeProfit, stopLoss, straIdx, tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Time));
                }
                else if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 2)
                {
                    int temp_share = Convert.ToInt32(Math.Ceiling(-moneyInvested[straIdx] / Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) / (1 + commissionFeeNTax)) / Convert.ToDouble(lotSize));
                    int share = temp_share * lotSize;
                    double takeProfit = Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) - container.simulator.takeProfitNStopLoss[straIdx][3];
                    double stopLoss = Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) + container.simulator.takeProfitNStopLoss[straIdx][4];
                    moneyInvested[straIdx] += -share * Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) * (1 - commissionFeeNTax);
                    orderMoney[straIdx] = -share * Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) * (1 - commissionFeeNTax);
                    tradingRecords.Add(Tuple.Create<int, double, double, int, DateTime>(share, takeProfit, stopLoss, straIdx, tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Time));
                }
                else if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 3)
                {
                    if (tradingRecords.Count > 0)
                    {
                        for (int record = 0; record < tradingRecords.Count - 1; record++)
                        {
                            if (tradingRecords[record].Item1 > 0 && tradingRecords[record].Item4 == straIdx && tradingRecords[record].Item5.Date < DateTime.Today.Date)
                            {
                                moneyInvested[straIdx] += tradingRecords[record].Item1 * Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) * (1 - commissionFeeNTax);
                                orderMoney[straIdx] = tradingRecords[record].Item1 * Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) * (1 - commissionFeeNTax);
                                recordsToBeRemoved.Add(tradingRecords[record]);
                                tradingRecords.RemoveAt(record);
                            }
                        }
                    }
                }
                else if (tradeSignals[straIdx][tradeSignals[straIdx].Length - 1] == 4)
                {
                    if (tradingRecords.Count > 0)
                    {
                        for (int record = 0; record < tradingRecords.Count; record++)
                        {
                            if (tradingRecords[record].Item1 < 0 && tradingRecords[record].Item4 == straIdx && tradingRecords[record].Item5.Date < DateTime.Today.Date)
                            {
                                moneyInvested[straIdx] += tradingRecords[record].Item1 * Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) * (1 + commissionFeeNTax);
                                orderMoney[straIdx] = tradingRecords[record].Item1 * Convert.ToDouble(tradingSymbolBarsList[tradingSymbolBarsList.Count - 1].Close) * (1 + commissionFeeNTax);
                                recordsToBeRemoved.Add(tradingRecords[record]);
                                tradingRecords.RemoveAt(record);
                            }
                        }
                    }
                }
            }
        }

        public void TakeProfitNStopLossCheck(List<Tuple<int, double, double, int, DateTime>> tradingRecords, List<Tuple<int, double, double, int, DateTime>> recordsToBeRemoved, List<AxiomObjects.Bar> marketInfoBarList, List<double> moneyInvested, List<double> orderMoney)
        {
            if (tradingRecords.Count > 0)
            {
                for (int record = 0; record < tradingRecords.Count; record++)
                {
                    if ((tradingRecords[record].Item1 > 0) && (tradingRecords[record].Item2 <= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].High)) && (tradingRecords[record].Item5.Date < DateTime.Today.Date))
                    {
                        moneyInvested[tradingRecords[record].Item4] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 - commissionFeeNTax);
                        orderMoney[tradingRecords[record].Item4] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 - commissionFeeNTax);
                        recordsToBeRemoved.Add(tradingRecords[record]);
                        tradingRecords.RemoveAt(record);
                    }
                    else if ((tradingRecords[record].Item1 > 0) && (tradingRecords[record].Item3 >= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Low)) && (tradingRecords[record].Item5.Date < DateTime.Today.Date))
                    {
                        moneyInvested[tradingRecords[record].Item4] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 - commissionFeeNTax);
                        orderMoney[tradingRecords[record].Item4] += tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 - commissionFeeNTax);
                        recordsToBeRemoved.Add(tradingRecords[record]);
                        tradingRecords.RemoveAt(record);
                    }
                    else if ((tradingRecords[record].Item1 < 0) && (tradingRecords[record].Item2 >= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Low)) && (tradingRecords[record].Item5.Date < DateTime.Today.Date))
                    {
                        moneyInvested[tradingRecords[record].Item4] -= tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 + commissionFeeNTax);
                        orderMoney[tradingRecords[record].Item4] -= tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 + commissionFeeNTax);
                        recordsToBeRemoved.Add(tradingRecords[record]);
                        tradingRecords.RemoveAt(record);
                    }
                    else if ((tradingRecords[record].Item1 < 0) && (tradingRecords[record].Item2 <= Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].High)) && (tradingRecords[record].Item5.Date < DateTime.Today.Date))
                    {
                        moneyInvested[tradingRecords[record].Item4] -= tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 + commissionFeeNTax);
                        orderMoney[tradingRecords[record].Item4] -= tradingRecords[record].Item1 * Convert.ToDouble(marketInfoBarList[marketInfoBarList.Count - 1].Close) * (1 + commissionFeeNTax);
                        recordsToBeRemoved.Add(tradingRecords[record]);
                        tradingRecords.RemoveAt(record);
                    }
                }
            }
        }

        public void PositioinCalculate(List<Tuple<int, double, double, int, DateTime>> tradingRecords, List<int> positionTracker)
        {
            if (tradingRecords.Count == 0)
            {
                positionTracker.Add(0);
            }
            else
            {
                int position = 0;
                for (int record = 0; record < tradingRecords.Count; record++)
                {
                    position += tradingRecords[record].Item1;
                }
                positionTracker.Add(position);
            }
        }

        public void OrderPlacement(List<int> positionTracker, int realPosition, TradeClient.TradeClient TC, bool allowToTrade, string symbol)
        {
            if (allowToTrade)
            {
                if (positionTracker[positionTracker.Count - 1] - realPosition == 0)
                {
                    Console.WriteLine("No Trade");
                }
                else if (positionTracker[positionTracker.Count - 1] - realPosition > 0)
                {
                    MTPA_SOrder3 order = new MTPA_SOrder3()
                    {
                        Action = MTPA_OrdrActn.eMTPA_OA_Buy,

                        Type = MTPA_OrdrType.eMTPA_OT_Entry,

                        Category = MTPA_OrdrCtgry.eMTPA_OC_Limit,

                        Quantity = positionTracker[positionTracker.Count - 1] - realPosition,

                        StopPrice = 0.0,

                        LimitPrice = 0.0,

                        FromEntryID = 0,

                        ReplacedOrderID = 0,

                        tag = 0,

                        TIFType = MTPA_OrdrTimeInForce.eMTPA_TIF_GTC,
                    };

                    TC.PlaceOrder(TC.LoginedUser, symbol, order, new TradeDecisionExecute());
                }
                else
                {
                    MTPA_SOrder3 order = new MTPA_SOrder3()
                    {
                        Action = MTPA_OrdrActn.eMTPA_OA_Sell,

                        Type = MTPA_OrdrType.eMTPA_OT_Exit,

                        Category = MTPA_OrdrCtgry.eMTPA_OC_Limit,

                        Quantity = Math.Abs(positionTracker[positionTracker.Count - 1] - realPosition),

                        StopPrice = 0.0,

                        LimitPrice = 0.0,

                        FromEntryID = 0,

                        ReplacedOrderID = 0,

                        tag = 0,

                        TIFType = MTPA_OrdrTimeInForce.eMTPA_TIF_GTC,
                    };

                    TC.PlaceOrder(TC.LoginedUser, symbol, order, new TradeDecisionExecute());
                }
            }
            else
            {
                Console.WriteLine("Can not connect to TradeManager yet");
            }
        }
    }
}
