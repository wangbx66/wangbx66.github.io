Larry has redefined the dependencies of the whole solution since 2016-08-04.

When you download such solution for the first time, please follow the next few steps.

- 1, Copy the folder Release_CpuOnly built in CNTK repo to the root of StrategySel repo.
- 2, Set solution platform to x64 and solution Configurations to Release_CpuOnly.
- 3, Rebuild entire solution.
- 4, Set project StrategySelByLarry as the startup point, run it.
- 5, Set project StrategyEval as the startup point, run it.

After these steps, you should get the solution work.
