﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;

using ModulusFE.TASDK;

namespace PerformanceEvaluation
{
    class Trader
    {
        public string modelFile;

        public const string POSITION_CLOSED = "_close";
        public const string POSITION_LONG = "_long";
        public const string POSITION_SHORT = "_short";

        public TrainingDataDump.Simulator simulator;
        public TrainingDataDump.FeaturesSource featuresSource;
        public TrainingDataDump.DataCleaner dataCleaner;
        public MoneyDistributor moneyDistributor;
        public Recorder recorder;
        public FeaturesConstructor constructor;

        public string name;
        public double commissionFeeNTax = -1;

        public Trader(string model, TrainingDataDump.Simulator classSimulator, double classCommissionFeeNTax, string className)
        {
            modelFile = @"..\..\..\..\CNTK_StrategySel\Models\" + model;
            name = className;
            simulator = classSimulator;
            commissionFeeNTax = classCommissionFeeNTax;
            featuresSource = new TrainingDataDump.FeaturesSource();
            dataCleaner = new TrainingDataDump.DataCleaner();
            moneyDistributor = new MoneyDistributor();
            recorder = new Recorder();
            constructor = new FeaturesConstructor();
        }

        public void ModelTrader(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq, double modelInitMoney, Dictionary<DateTime, Dictionary<DateTime, decimal>> modelDailyPerformance, Dictionary<DateTime, Dictionary<DateTime, List<float>>> modelDailySel, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals, Dictionary<DateTime, List<decimal>> modelTrader_StrategiesSignal)
        {
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
            int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            recorder.InitStrategiesSignal(tradingBars, modelTrader_StrategiesSignal, simulator);

            //get model prediction
            List<Dictionary<DateTime, List<double>>> timeDominFeaturesList = new List<Dictionary<DateTime, List<double>>>();
            timeDominFeaturesList.Add(featuresSource.TradeScript_Indicator(tradingBars, historicalTradingSymbolBars, twoDaySeq));
            List<List<double>> marketInfo = constructor.TimeDominFeaturesConstructor(timeDominFeaturesList);
            List<List<float>> marketInfo_Float = dataCleaner.FeaturesList_ChangeToFloat(marketInfo);
            List<List<float>> modelPrediction = ModelExecutor.FloatPrecision(modelFile, marketInfo_Float);
            recorder.AddModelSelInDayRecord(tradingBars, modelPrediction, modelDailySel);

            Navigator DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
            DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(tradingBars);

            List<decimal> modelPeriodPerformance = new List<decimal>(new decimal[tradingBars.Count]);
            List<decimal> totalInvest = new List<decimal>(new decimal[tradingBars.Count]);
            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                for (int startingBar = 1; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    if (startingBar <= explorationLength)
                    {
                        tradeSignals[idxStra][startingBar - 1] = 0;
                        continue;
                    }
                    else if (startingBar > DatabaseNavigator.RecordCount - trailLength)
                    {
                        modelPeriodPerformance[startingBar - 1] = modelPeriodPerformance[startingBar - 2];
                        totalInvest[startingBar - 1] = totalInvest[startingBar - 2];
                        tradeSignals[idxStra][startingBar - 1] = 0;
                        continue;
                    }

                    if (startingBar == explorationLength + 1)
                    {
                        #region markDownTradeSignals
                        decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal share = 0;
                        string position = POSITION_CLOSED;
                        decimal exitPrice = 0;
                        decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                        decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                        decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                        decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                        decimal takeProfit = 0;
                        decimal stopLoss = 0;

                        for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                        {
                            #region TradeLogic
                            if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                            {
                                if (position == POSITION_LONG)
                                {
                                    cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 - commissionFeeNTax);
                                    //DateTime time = tradingBars[idxBar - 1].Time;
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] - share;
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }
                                else if (position == POSITION_SHORT)
                                {
                                    cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 + commissionFeeNTax);
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] - share;
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }

                                totalInvest[idxBar - 1] += init;
                                modelPeriodPerformance[idxBar - 1] += portfolio;
                                tradeSignals[idxStra][idxBar - 1] = 1;
                                break;
                            }

                            if (position == POSITION_CLOSED)
                            {
                                if (tradeSignals[idxStra][idxBar - 1] == 1)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] + share;
                                    cash = 0;
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_LONG;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                                    tradeSignals[idxStra][idxBar - 1] = 2;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 2)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = -init / exitPrice;
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] + share;
                                    cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_SHORT;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                                    tradeSignals[idxStra][idxBar - 1] = 3;
                                }
                            }
                            else if (position == POSITION_LONG)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 4;
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 5;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 3)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    tradeSignals[idxStra][idxBar - 1] = 6;
                                }
                                else
                                {
                                    tradeSignals[idxStra][idxBar - 1] = 0;
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] - share;
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            else if (position == POSITION_SHORT)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 7;
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 8;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 4)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    tradeSignals[idxStra][idxBar - 1] = 9;
                                }
                                else
                                {
                                    tradeSignals[idxStra][idxBar - 1] = 0;
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] - share;
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            #endregion TradeLogic

                            modelPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                            totalInvest[idxBar - 1] += init;
                        }
                        #endregion markDownTradeSignals
                    }
                    else
                    {
                        #region continueProcessing
                        decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal share = 0;
                        string position = POSITION_CLOSED;
                        decimal exitPrice = 0;
                        decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                        decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                        decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                        decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                        decimal takeProfit = 0;
                        decimal stopLoss = 0;

                        for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                        {
                            #region TradeLogic
                            if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                            {
                                if (position == POSITION_LONG)
                                {
                                    cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 - commissionFeeNTax);
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] - share;
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }
                                else if (position == POSITION_SHORT)
                                {
                                    cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 + commissionFeeNTax);
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] - share;
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }

                                totalInvest[idxBar - 1] += init;
                                modelPeriodPerformance[idxBar - 1] += portfolio;
                                break;
                            }

                            if (position == POSITION_CLOSED)
                            {
                                if (tradeSignals[idxStra][idxBar - 1] == 1)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] + share;
                                    cash = 0;
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_LONG;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 2)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = -init / exitPrice;
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] + share;
                                    cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_SHORT;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                                }
                            }
                            else if (position == POSITION_LONG)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 3)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] - share;
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            else if (position == POSITION_SHORT)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 4)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                    modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] = modelTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] - share;
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            #endregion TradeLogic

                            modelPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                            totalInvest[idxBar - 1] += init;
                        }
                        #endregion continueProcessing
                    }
                }
            }

            for (int period = 0; period < modelPeriodPerformance.Count; period++ )
            {
                modelPeriodPerformance[period] = modelPeriodPerformance[period] - totalInvest[period];
            }

            recorder.AddModelDailyPerformance(tradingBars, modelPeriodPerformance, modelDailyPerformance);
            recorder.AddModelTradeSignalInDayRecord(tradingBars, tradeSignals, modelDailyTradeSignals);
        }

        public void ModelTrader_WithoutDayClose(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq, double modelInitMoney, Dictionary<DateTime, Dictionary<DateTime, decimal>> modelDailyPerformance, Dictionary<DateTime, Dictionary<DateTime, List<float>>> modelDailySel, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals)
        {
            Console.WriteLine("Model Start");

            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
            int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            //get model prediction
            List<Dictionary<DateTime, List<double>>> timeDominFeaturesList = new List<Dictionary<DateTime, List<double>>>();
            timeDominFeaturesList.Add(featuresSource.TradeScript_Indicator(tradingBars, historicalTradingSymbolBars, twoDaySeq));
            List<List<double>> marketInfo = constructor.TimeDominFeaturesConstructor(timeDominFeaturesList);
            List<List<float>> marketInfo_Float = dataCleaner.FeaturesList_ChangeToFloat(marketInfo);
            List<List<float>> modelPrediction = ModelExecutor.FloatPrecision(modelFile, marketInfo_Float);
            recorder.AddModelSelInDayRecord(tradingBars, modelPrediction, modelDailySel);

            Navigator DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
            DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(tradingBars);

            List<decimal> modelPeriodPerformance = new List<decimal>(new decimal[tradingBars.Count]);
            List<decimal> totalInvest = new List<decimal>(new decimal[tradingBars.Count]);
            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                for (int startingBar = 1; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    if (startingBar <= explorationLength)
                    {
                        tradeSignals[idxStra][startingBar - 1] = 0;
                        continue;
                    }
                    else if (startingBar > DatabaseNavigator.RecordCount - trailLength)
                    {
                        modelPeriodPerformance[startingBar - 1] = modelPeriodPerformance[startingBar - 2];
                        totalInvest[startingBar - 1] = totalInvest[startingBar - 2];
                        tradeSignals[idxStra][startingBar - 1] = 0;
                        continue;
                    }

                    if (startingBar == explorationLength + 1)
                    {
                        #region markDownTradeSignals
                        decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal share = 0;
                        string position = POSITION_CLOSED;
                        decimal exitPrice = 0;
                        decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                        decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                        decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                        decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                        decimal takeProfit = 0;
                        decimal stopLoss = 0;

                        for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                        {
                            #region TradeLogic
                            if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                            {
                                if (position == POSITION_LONG)
                                {
                                    cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 - commissionFeeNTax);
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }
                                else if (position == POSITION_SHORT)
                                {
                                    cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 + commissionFeeNTax);
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }

                                totalInvest[idxBar - 1] += init;
                                modelPeriodPerformance[idxBar - 1] += portfolio;
                                tradeSignals[idxStra][idxBar - 1] = 1;
                                break;
                            }

                            if (position == POSITION_CLOSED)
                            {
                                if (tradeSignals[idxStra][idxBar - 1] == 1)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                    cash = 0;
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_LONG;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                                    tradeSignals[idxStra][idxBar - 1] = 2;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 2)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = -init / exitPrice;
                                    cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_SHORT;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                                    tradeSignals[idxStra][idxBar - 1] = 3;
                                }
                            }
                            else if (position == POSITION_LONG)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 4;
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 5;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 3)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    tradeSignals[idxStra][idxBar - 1] = 6;
                                }
                                else
                                {
                                    tradeSignals[idxStra][idxBar - 1] = 0;
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            else if (position == POSITION_SHORT)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 7;
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 8;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 4)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    tradeSignals[idxStra][idxBar - 1] = 9;
                                }
                                else
                                {
                                    tradeSignals[idxStra][idxBar - 1] = 0;
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            #endregion TradeLogic

                            modelPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                            totalInvest[idxBar - 1] += init;
                        }
                        #endregion markDownTradeSignals
                    }
                    else
                    {
                        #region continueProcessing
                        decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal share = 0;
                        string position = POSITION_CLOSED;
                        decimal exitPrice = 0;
                        decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                        decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                        decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                        decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                        decimal takeProfit = 0;
                        decimal stopLoss = 0;

                        for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                        {
                            #region TradeLogic
                            if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                            {
                                if (position == POSITION_LONG)
                                {
                                    cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 - commissionFeeNTax);
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }
                                else if (position == POSITION_SHORT)
                                {
                                    cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 + commissionFeeNTax);
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }

                                totalInvest[idxBar - 1] += init;
                                modelPeriodPerformance[idxBar - 1] += portfolio;
                                break;
                            }

                            if (position == POSITION_CLOSED)
                            {
                                if (tradeSignals[idxStra][idxBar - 1] == 1)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                    cash = 0;
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_LONG;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 2)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = -init / exitPrice;
                                    cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_SHORT;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                                }
                            }
                            else if (position == POSITION_LONG)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 3)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            else if (position == POSITION_SHORT)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 4)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            #endregion TradeLogic

                            modelPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                            totalInvest[idxBar - 1] += init;
                        }
                        #endregion continueProcessing
                    }
                }

                Console.WriteLine(String.Format("Strategy {0} finished", idxStra + 1));
            }

            for (int period = 0; period < modelPeriodPerformance.Count; period++)
            {
                modelPeriodPerformance[period] = modelPeriodPerformance[period] - totalInvest[period];
            }

            recorder.AddModelDailyPerformance(tradingBars, modelPeriodPerformance, modelDailyPerformance);
            recorder.AddModelTradeSignal_WithoutDayClose(tradingBars, tradeSignals, modelDailyTradeSignals);
        }

        public void ModelTrader_NextDayOpenClose(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq, List<AxiomObjects.Bar> nextDayBarsList, double modelInitMoney, Dictionary<DateTime, Dictionary<DateTime, decimal>> modelDailyPerformance, Dictionary<DateTime, Dictionary<DateTime, List<float>>> modelDailySel, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals)
        {
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
            int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            //get model prediction
            List<Dictionary<DateTime, List<double>>> timeDominFeaturesList = new List<Dictionary<DateTime, List<double>>>();
            timeDominFeaturesList.Add(featuresSource.TradeScript_Indicator(tradingBars, historicalTradingSymbolBars, twoDaySeq));
            List<List<double>> marketInfo = constructor.TimeDominFeaturesConstructor(timeDominFeaturesList);
            List<List<float>> marketInfo_Float = dataCleaner.FeaturesList_ChangeToFloat(marketInfo);
            List<List<float>> modelPrediction = ModelExecutor.FloatPrecision(modelFile, marketInfo_Float);
            recorder.AddModelSelInDayRecord(tradingBars, modelPrediction, modelDailySel);

            Navigator DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
            DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(tradingBars);

            List<decimal> modelPeriodPerformance = new List<decimal>(new decimal[tradingBars.Count]);
            List<decimal> totalInvest = new List<decimal>(new decimal[tradingBars.Count]);
            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                for (int startingBar = 1; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    if (startingBar <= explorationLength)
                    {
                        tradeSignals[idxStra][startingBar - 1] = 0;
                        continue;
                    }
                    else if (startingBar > DatabaseNavigator.RecordCount - trailLength)
                    {
                        modelPeriodPerformance[startingBar - 1] = modelPeriodPerformance[startingBar - 2];
                        totalInvest[startingBar - 1] = totalInvest[startingBar - 2];
                        tradeSignals[idxStra][startingBar - 1] = 0;
                        continue;
                    }

                    if (startingBar == explorationLength + 1)
                    {
                        #region markDownTradeSignals
                        decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal share = 0;
                        string position = POSITION_CLOSED;
                        decimal exitPrice = 0;
                        decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                        decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                        decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                        decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                        decimal takeProfit = 0;
                        decimal stopLoss = 0;

                        for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                        {
                            #region TradeLogic
                            if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                            {
                                if (position == POSITION_LONG)
                                {
                                    cash += share * nextDayBarsList[1].Open * Convert.ToDecimal(1 - commissionFeeNTax);
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }
                                else if (position == POSITION_SHORT)
                                {
                                    cash += share * nextDayBarsList[1].Open * Convert.ToDecimal(1 + commissionFeeNTax);
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }

                                totalInvest[idxBar - 1] += init;
                                modelPeriodPerformance[idxBar - 1] += portfolio;
                                tradeSignals[idxStra][idxBar - 1] = 1;
                                break;
                            }

                            if (position == POSITION_CLOSED)
                            {
                                if (tradeSignals[idxStra][idxBar - 1] == 1)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                    cash = 0;
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_LONG;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                                    tradeSignals[idxStra][idxBar - 1] = 2;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 2)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = -init / exitPrice;
                                    cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_SHORT;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                                    tradeSignals[idxStra][idxBar - 1] = 3;
                                }
                            }
                            else if (position == POSITION_LONG)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 4;
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 5;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 3)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    tradeSignals[idxStra][idxBar - 1] = 6;
                                }
                                else
                                {
                                    tradeSignals[idxStra][idxBar - 1] = 0;
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            else if (position == POSITION_SHORT)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 7;
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                    tradeSignals[idxStra][idxBar - 1] = 8;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 4)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    tradeSignals[idxStra][idxBar - 1] = 9;
                                }
                                else
                                {
                                    tradeSignals[idxStra][idxBar - 1] = 0;
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            #endregion TradeLogic

                            modelPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                            totalInvest[idxBar - 1] += init;
                        }
                        #endregion markDownTradeSignals
                    }
                    else
                    {
                        #region continueProcessing
                        decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(modelInitMoney), DatabaseNavigator, explorationLength, trailLength) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                        decimal share = 0;
                        string position = POSITION_CLOSED;
                        decimal exitPrice = 0;
                        decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                        decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                        decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                        decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                        decimal takeProfit = 0;
                        decimal stopLoss = 0;

                        for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                        {
                            #region TradeLogic
                            if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                            {
                                if (position == POSITION_LONG)
                                {
                                    cash += share * nextDayBarsList[1].Open * Convert.ToDecimal(1 - commissionFeeNTax);
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }
                                else if (position == POSITION_SHORT)
                                {
                                    cash += share * nextDayBarsList[1].Open * Convert.ToDecimal(1 + commissionFeeNTax);
                                    portfolio = cash;
                                    share = 0;
                                    position = POSITION_CLOSED;
                                }

                                totalInvest[idxBar - 1] += init;
                                modelPeriodPerformance[idxBar - 1] += portfolio;
                                break;
                            }

                            if (position == POSITION_CLOSED)
                            {
                                if (tradeSignals[idxStra][idxBar - 1] == 1)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                    cash = 0;
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_LONG;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 2)
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                    share = -init / exitPrice;
                                    cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    //portfolio = share * exitPrice + cash;
                                    position = POSITION_SHORT;
                                    takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                    stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                                }
                            }
                            else if (position == POSITION_LONG)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 3)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            else if (position == POSITION_SHORT)
                            {
                                if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                                {
                                    position = POSITION_CLOSED;
                                    if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = takeProfit;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                                {
                                    position = POSITION_CLOSED;
                                    if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                    {
                                        exitPrice = stopLoss;
                                    }
                                    else
                                    {
                                        exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    }
                                }
                                else if (tradeSignals[idxStra][idxBar - 1] == 4)
                                {
                                    position = POSITION_CLOSED;
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                }

                                if (position == POSITION_CLOSED)
                                {
                                    cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                    share = 0;
                                    //portfolio = cash;
                                }
                            }
                            #endregion TradeLogic

                            modelPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                            totalInvest[idxBar - 1] += init;
                        }
                        #endregion continueProcessing
                    }
                }
            }

            for (int period = 0; period < modelPeriodPerformance.Count; period++)
            {
                modelPeriodPerformance[period] = modelPeriodPerformance[period] - totalInvest[period];
            }

            recorder.AddModelDailyPerformance(tradingBars, modelPeriodPerformance, modelDailyPerformance);
            recorder.AddModelTradeSignalInDayRecord_NextDayOpenClose(tradingBars, nextDayBarsList, tradeSignals, modelDailyTradeSignals);
        }

        public void AvgDistributeTrader(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq, double avgModelInitMoney, Dictionary<DateTime, Dictionary<DateTime, decimal>> avgModelDailyPerformance, Dictionary<DateTime, List<decimal>> avgDistributeTrader_StrategiesSignal)
        {
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
            int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            recorder.InitStrategiesSignal(tradingBars, avgDistributeTrader_StrategiesSignal, simulator);

            Navigator DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
            DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(tradingBars);

            List<decimal> avgModelPeriodPerformance = new List<decimal>(new decimal[tradingBars.Count]);
            List<decimal> totalInvest = new List<decimal>(new decimal[tradingBars.Count]);

            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                for (int startingBar = 1; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    if (startingBar <= explorationLength)
                    {
                        continue;
                    }
                    else if (startingBar > DatabaseNavigator.RecordCount - trailLength)
                    {
                        avgModelPeriodPerformance[startingBar - 1] = avgModelPeriodPerformance[startingBar - 2];
                        totalInvest[startingBar - 1] = totalInvest[startingBar - 2];
                        continue;
                    }

                    decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(avgModelInitMoney), DatabaseNavigator, explorationLength, trailLength) * (Convert.ToDecimal(1) / simulator.strategies.Count);
                    decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(avgModelInitMoney), DatabaseNavigator, explorationLength, trailLength) * (Convert.ToDecimal(1) / simulator.strategies.Count);
                    decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(avgModelInitMoney), DatabaseNavigator, explorationLength, trailLength) * (Convert.ToDecimal(1) / simulator.strategies.Count);
                    decimal share = 0;
                    string position = POSITION_CLOSED;
                    decimal exitPrice = 0;
                    decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                    decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                    decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                    decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                    decimal takeProfit = 0;
                    decimal stopLoss = 0;

                    for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                    {
                        #region TradeLogic
                        if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 - commissionFeeNTax);
                                avgDistributeTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] -= share;
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 + commissionFeeNTax);
                                avgDistributeTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] -= share;
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }

                            totalInvest[idxBar - 1] += init;
                            avgModelPeriodPerformance[idxBar - 1] += portfolio;
                            break;
                        }

                        if (position == POSITION_CLOSED)
                        {
                            if (tradeSignals[idxStra][idxBar - 1] == 1)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                avgDistributeTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] += share;
                                cash = 0;
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_LONG;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 2)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = -init / exitPrice;
                                avgDistributeTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] += share;
                                cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_SHORT;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                            }
                        }
                        else if (position == POSITION_LONG)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 3)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                avgDistributeTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] -= share;
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        else if (position == POSITION_SHORT)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 4)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                avgDistributeTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] -= share;
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        #endregion TradeLogic

                        avgModelPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                        totalInvest[idxBar - 1] += init;
                    }
                }
            }

            for (int period = 0; period < avgModelPeriodPerformance.Count; period++)
            {
                avgModelPeriodPerformance[period] = avgModelPeriodPerformance[period] - totalInvest[period];
            }

            recorder.AddModelDailyPerformance(tradingBars, avgModelPeriodPerformance, avgModelDailyPerformance);
        }

        public void AvgDistributeTrader_WithoutDayClose(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq, double avgModelInitMoney, Dictionary<DateTime, Dictionary<DateTime, decimal>> avgModelDailyPerformance)
        {
            Console.WriteLine("Avg distribute Trader start");

            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
            int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            Navigator DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
            DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(tradingBars);

            List<decimal> avgModelPeriodPerformance = new List<decimal>(new decimal[tradingBars.Count]);
            List<decimal> totalInvest = new List<decimal>(new decimal[tradingBars.Count]);

            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                for (int startingBar = 1; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    if (startingBar <= explorationLength)
                    {
                        continue;
                    }
                    else if (startingBar > DatabaseNavigator.RecordCount - trailLength)
                    {
                        avgModelPeriodPerformance[startingBar - 1] = avgModelPeriodPerformance[startingBar - 2];
                        totalInvest[startingBar - 1] = totalInvest[startingBar - 2];
                        continue;
                    }

                    decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(avgModelInitMoney), DatabaseNavigator, explorationLength, trailLength) * (Convert.ToDecimal(1) / simulator.strategies.Count);
                    decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(avgModelInitMoney), DatabaseNavigator, explorationLength, trailLength) * (Convert.ToDecimal(1) / simulator.strategies.Count);
                    decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(avgModelInitMoney), DatabaseNavigator, explorationLength, trailLength) * (Convert.ToDecimal(1) / simulator.strategies.Count);
                    decimal share = 0;
                    string position = POSITION_CLOSED;
                    decimal exitPrice = 0;
                    decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                    decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                    decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                    decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                    decimal takeProfit = 0;
                    decimal stopLoss = 0;

                    for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                    {
                        #region TradeLogic
                        if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 - commissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 + commissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }

                            totalInvest[idxBar - 1] += init;
                            avgModelPeriodPerformance[idxBar - 1] += portfolio;
                            break;
                        }

                        if (position == POSITION_CLOSED)
                        {
                            if (tradeSignals[idxStra][idxBar - 1] == 1)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                cash = 0;
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_LONG;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 2)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = -init / exitPrice;
                                cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_SHORT;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                            }
                        }
                        else if (position == POSITION_LONG)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 3)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        else if (position == POSITION_SHORT)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 4)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        #endregion TradeLogic

                        avgModelPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                        totalInvest[idxBar - 1] += init;
                    }
                }

                Console.WriteLine(String.Format("Strategy {0} finished", idxStra + 1));
            }

            for (int period = 0; period < avgModelPeriodPerformance.Count; period++)
            {
                avgModelPeriodPerformance[period] = avgModelPeriodPerformance[period] - totalInvest[period];
            }

            recorder.AddModelDailyPerformance(tradingBars, avgModelPeriodPerformance, avgModelDailyPerformance);
        }

        public void AvgDistributeTrader_NextDayOpenClose(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq, List<AxiomObjects.Bar> nextDayBarsList, double avgModelInitMoney, Dictionary<DateTime, Dictionary<DateTime, decimal>> avgModelDailyPerformance)
        {
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
            int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            Navigator DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
            DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(tradingBars);

            List<decimal> avgModelPeriodPerformance = new List<decimal>(new decimal[tradingBars.Count]);
            List<decimal> totalInvest = new List<decimal>(new decimal[tradingBars.Count]);

            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                for (int startingBar = 1; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    if (startingBar <= explorationLength)
                    {
                        continue;
                    }
                    else if (startingBar > DatabaseNavigator.RecordCount - trailLength)
                    {
                        avgModelPeriodPerformance[startingBar - 1] = avgModelPeriodPerformance[startingBar - 2];
                        totalInvest[startingBar - 1] = totalInvest[startingBar - 2];
                        continue;
                    }

                    decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(avgModelInitMoney), DatabaseNavigator, explorationLength, trailLength) * (Convert.ToDecimal(1) / simulator.strategies.Count);
                    decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(avgModelInitMoney), DatabaseNavigator, explorationLength, trailLength) * (Convert.ToDecimal(1) / simulator.strategies.Count);
                    decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(avgModelInitMoney), DatabaseNavigator, explorationLength, trailLength) * (Convert.ToDecimal(1) / simulator.strategies.Count);
                    decimal share = 0;
                    string position = POSITION_CLOSED;
                    decimal exitPrice = 0;
                    decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                    decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                    decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                    decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                    decimal takeProfit = 0;
                    decimal stopLoss = 0;

                    for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                    {
                        #region TradeLogic
                        if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * nextDayBarsList[1].Open * Convert.ToDecimal(1 - commissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * nextDayBarsList[1].Open * Convert.ToDecimal(1 + commissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }

                            totalInvest[idxBar - 1] += init;
                            avgModelPeriodPerformance[idxBar - 1] += portfolio;
                            break;
                        }

                        if (position == POSITION_CLOSED)
                        {
                            if (tradeSignals[idxStra][idxBar - 1] == 1)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                cash = 0;
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_LONG;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 2)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = -init / exitPrice;
                                cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_SHORT;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                            }
                        }
                        else if (position == POSITION_LONG)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 3)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        else if (position == POSITION_SHORT)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 4)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        #endregion TradeLogic

                        avgModelPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                        totalInvest[idxBar - 1] += init;
                    }
                }
            }

            for (int period = 0; period < avgModelPeriodPerformance.Count; period++)
            {
                avgModelPeriodPerformance[period] = avgModelPeriodPerformance[period] - totalInvest[period];
            }

            recorder.AddModelDailyPerformance(tradingBars, avgModelPeriodPerformance, avgModelDailyPerformance);
        }

        public void MutiStrategiesTrader(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq, List<double> strategiesInitMoney, Dictionary<DateTime, Dictionary<DateTime, List<decimal>>> strategiesDailyPerformance, Dictionary<DateTime, List<decimal>> mutiStrategiesTrader_StrategiesSignal)
        {
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
            int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            recorder.InitStrategiesSignal(tradingBars, mutiStrategiesTrader_StrategiesSignal, simulator);

            Navigator DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
            DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(tradingBars);

            List<List<decimal>> strategiesPerformanceContainer = new List<List<decimal>>();
            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                List<decimal> strategyPeriodPerformance = new List<decimal>(new decimal[tradingBars.Count]);
                List<decimal> totalInvestPerStrategy = new List<decimal>(new decimal[tradingBars.Count]);

                for (int startingBar = 1; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    if (startingBar <= explorationLength)
                    {
                        continue;
                    }
                    else if (startingBar > DatabaseNavigator.RecordCount - trailLength)
                    {
                        strategyPeriodPerformance[startingBar - 1] = strategyPeriodPerformance[startingBar - 2];
                        totalInvestPerStrategy[startingBar - 1] = totalInvestPerStrategy[startingBar - 2];
                        continue;
                    }

                    decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(strategiesInitMoney[idxStra]), DatabaseNavigator, explorationLength, trailLength);
                    decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(strategiesInitMoney[idxStra]), DatabaseNavigator, explorationLength, trailLength);
                    decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(strategiesInitMoney[idxStra]), DatabaseNavigator, explorationLength, trailLength);
                    decimal share = 0;
                    string position = POSITION_CLOSED;
                    decimal exitPrice = 0;
                    decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                    decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                    decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                    decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                    decimal takeProfit = 0;
                    decimal stopLoss = 0;

                    for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                    {
                        #region TradeLogic
                        if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 - commissionFeeNTax);
                                mutiStrategiesTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] -= share;
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 + commissionFeeNTax);
                                mutiStrategiesTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] -= share;
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }

                            totalInvestPerStrategy[idxBar - 1] += init;
                            strategyPeriodPerformance[idxBar - 1] += portfolio;
                            break;
                        }

                        if (position == POSITION_CLOSED)
                        {
                            if (tradeSignals[idxStra][idxBar - 1] == 1)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                mutiStrategiesTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] += share;
                                cash = 0;
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_LONG;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 2)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = -init / exitPrice;
                                mutiStrategiesTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] += share;
                                cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_SHORT;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                            }
                        }
                        else if (position == POSITION_LONG)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 3)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                mutiStrategiesTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] -= share;
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        else if (position == POSITION_SHORT)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 4)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                mutiStrategiesTrader_StrategiesSignal[tradingBars[idxBar - 1].Time][idxStra] -= share;
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        #endregion TradeLogic

                        strategyPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                        totalInvestPerStrategy[idxBar - 1] += init;
                    }
                }

                for (int period = 0; period < strategyPeriodPerformance.Count; period++)
                {
                    strategyPeriodPerformance[period] = strategyPeriodPerformance[period] - totalInvestPerStrategy[period];
                }

                strategiesPerformanceContainer.Add(strategyPeriodPerformance);
            }
            recorder.AddStrategiesDailyPerformance(tradingBars, strategiesPerformanceContainer, strategiesDailyPerformance);
        }

        public void MutiStrategiesTrader_WithoutDayClose(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq, List<double> strategiesInitMoney, Dictionary<DateTime, Dictionary<DateTime, List<decimal>>> strategiesDailyPerformance)
        {
            Console.WriteLine("MutiStrategies Trader Start");

            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
            int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            Navigator DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
            DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(tradingBars);

            List<List<decimal>> strategiesPerformanceContainer = new List<List<decimal>>();
            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                List<decimal> strategyPeriodPerformance = new List<decimal>(new decimal[tradingBars.Count]);
                List<decimal> totalInvestPerStrategy = new List<decimal>(new decimal[tradingBars.Count]);

                for (int startingBar = 1; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    if (startingBar <= explorationLength)
                    {
                        continue;
                    }
                    else if (startingBar > DatabaseNavigator.RecordCount - trailLength)
                    {
                        strategyPeriodPerformance[startingBar - 1] = strategyPeriodPerformance[startingBar - 2];
                        totalInvestPerStrategy[startingBar - 1] = totalInvestPerStrategy[startingBar - 2];
                        continue;
                    }

                    decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(strategiesInitMoney[idxStra]), DatabaseNavigator, explorationLength, trailLength);
                    decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(strategiesInitMoney[idxStra]), DatabaseNavigator, explorationLength, trailLength);
                    decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(strategiesInitMoney[idxStra]), DatabaseNavigator, explorationLength, trailLength);
                    decimal share = 0;
                    string position = POSITION_CLOSED;
                    decimal exitPrice = 0;
                    decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                    decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                    decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                    decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                    decimal takeProfit = 0;
                    decimal stopLoss = 0;

                    for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                    {
                        #region TradeLogic
                        if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 - commissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * Convert.ToDecimal(1 + commissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }

                            totalInvestPerStrategy[idxBar - 1] += init;
                            strategyPeriodPerformance[idxBar - 1] += portfolio;
                            break;
                        }

                        if (position == POSITION_CLOSED)
                        {
                            if (tradeSignals[idxStra][idxBar - 1] == 1)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                cash = 0;
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_LONG;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 2)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = -init / exitPrice;
                                cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_SHORT;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                            }
                        }
                        else if (position == POSITION_LONG)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 3)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        else if (position == POSITION_SHORT)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 4)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        #endregion TradeLogic

                        strategyPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                        totalInvestPerStrategy[idxBar - 1] += init;
                    }
                }

                for (int period = 0; period < strategyPeriodPerformance.Count; period++)
                {
                    strategyPeriodPerformance[period] = strategyPeriodPerformance[period] - totalInvestPerStrategy[period];
                }

                strategiesPerformanceContainer.Add(strategyPeriodPerformance);

                Console.WriteLine("Strategy {0} finished", idxStra + 1);
            }
            recorder.AddStrategiesDailyPerformance(tradingBars, strategiesPerformanceContainer, strategiesDailyPerformance);
        }

        public void MutiStrategiesTrader_NextDayOpenClose(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq, List<AxiomObjects.Bar> nextDayBarsList, List<double> strategiesInitMoney, Dictionary<DateTime, Dictionary<DateTime, List<decimal>>> strategiesDailyPerformance)
        {
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
            int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            Navigator DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
            DatabaseNavigator = TrainingDataDump.PeriodicUtils.GetDatabaseNavigator(tradingBars);

            List<List<decimal>> strategiesPerformanceContainer = new List<List<decimal>>();
            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                List<decimal> strategyPeriodPerformance = new List<decimal>(new decimal[tradingBars.Count]);
                List<decimal> totalInvestPerStrategy = new List<decimal>(new decimal[tradingBars.Count]);

                for (int startingBar = 1; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    if (startingBar <= explorationLength)
                    {
                        continue;
                    }
                    else if (startingBar > DatabaseNavigator.RecordCount - trailLength)
                    {
                        strategyPeriodPerformance[startingBar - 1] = strategyPeriodPerformance[startingBar - 2];
                        totalInvestPerStrategy[startingBar - 1] = totalInvestPerStrategy[startingBar - 2];
                        continue;
                    }

                    decimal init = moneyDistributor.EquallyDistribute(Convert.ToDecimal(strategiesInitMoney[idxStra]), DatabaseNavigator, explorationLength, trailLength);
                    decimal portfolio = moneyDistributor.EquallyDistribute(Convert.ToDecimal(strategiesInitMoney[idxStra]), DatabaseNavigator, explorationLength, trailLength);
                    decimal cash = moneyDistributor.EquallyDistribute(Convert.ToDecimal(strategiesInitMoney[idxStra]), DatabaseNavigator, explorationLength, trailLength);
                    decimal share = 0;
                    string position = POSITION_CLOSED;
                    decimal exitPrice = 0;
                    decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                    decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                    decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                    decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                    decimal takeProfit = 0;
                    decimal stopLoss = 0;

                    for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount - trailLength; idxBar++)
                    {
                        #region TradeLogic
                        if (idxBar == DatabaseNavigator.RecordCount - trailLength)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * nextDayBarsList[1].Open * Convert.ToDecimal(1 - commissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * nextDayBarsList[1].Open * Convert.ToDecimal(1 + commissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }

                            totalInvestPerStrategy[idxBar - 1] += init;
                            strategyPeriodPerformance[idxBar - 1] += portfolio;
                            break;
                        }

                        if (position == POSITION_CLOSED)
                        {
                            if (tradeSignals[idxStra][idxBar - 1] == 1)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = Convert.ToDecimal(1 - commissionFeeNTax) * init / exitPrice;
                                cash = 0;
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_LONG;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 2)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = -init / exitPrice;
                                cash += -share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                //portfolio = share * exitPrice + cash;
                                position = POSITION_SHORT;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                            }
                        }
                        else if (position == POSITION_LONG)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 3)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 - commissionFeeNTax);
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        else if (position == POSITION_SHORT)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 4)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * Convert.ToDecimal(1 + commissionFeeNTax);
                                share = 0;
                                //portfolio = cash;
                            }
                        }
                        #endregion TradeLogic

                        strategyPeriodPerformance[idxBar - 1] += (share * exitPrice + cash);
                        totalInvestPerStrategy[idxBar - 1] += init;
                    }
                }

                for (int period = 0; period < strategyPeriodPerformance.Count; period++)
                {
                    strategyPeriodPerformance[period] = strategyPeriodPerformance[period] - totalInvestPerStrategy[period];
                }

                strategiesPerformanceContainer.Add(strategyPeriodPerformance);
            }
            recorder.AddStrategiesDailyPerformance(tradingBars, strategiesPerformanceContainer, strategiesDailyPerformance);
        }
    }
}
