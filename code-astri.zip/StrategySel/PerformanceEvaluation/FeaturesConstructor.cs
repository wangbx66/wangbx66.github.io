﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PerformanceEvaluation
{
    public class FeaturesConstructor
    {
        TrainingDataDump.DataCleaner dataCleaner;

        public FeaturesConstructor()
        {
            dataCleaner = new TrainingDataDump.DataCleaner();
        }

        public List<List<double>> TimeDominFeaturesConstructor(List<Dictionary<DateTime, List<double>>> timeDominFeaturesList)
        {
            List<List<double>> rawFeatures = new List<List<double>>();
            List<List<double>> features = new List<List<double>>();

            //remove bad dictionary which contains less than minimumPeriods information
            //for minimumPeriods value, please refer to SystemSetting.ini
            string filterFile = AppDomain.CurrentDomain.BaseDirectory + @"FilterSetting.ini";
            int minimumPeriods = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(filterFile, "infoFilter", "minimumPeriods", "30"));
            for (int rawSourceIdx = 0; rawSourceIdx < timeDominFeaturesList.Count; rawSourceIdx++)
            {
                if (timeDominFeaturesList[rawSourceIdx].Count < minimumPeriods)
                {
                    timeDominFeaturesList.RemoveAt(rawSourceIdx);
                }
            }

            int numOfFeaturesSource = timeDominFeaturesList.Count;

            if (numOfFeaturesSource == 1)
            {
                foreach (var item in timeDominFeaturesList[0])
                {
                    rawFeatures.Add(item.Value);
                }

                features = dataCleaner.RemoveAbsoluteValue(rawFeatures);
            }
            else if (numOfFeaturesSource > 1)
            {
                Dictionary<DateTime, List<double>> baseTable = timeDominFeaturesList[0];
                foreach (var item in baseTable)
                {
                    for (int sourceIdx = 1; sourceIdx < numOfFeaturesSource; sourceIdx++)
                    {
                        if (!timeDominFeaturesList[sourceIdx].ContainsKey(item.Key))
                        {
                            List<DateTime> dictionaryKey = new List<DateTime>(timeDominFeaturesList[sourceIdx].Keys);
                            List<double> zeroList = new List<double>(new double[timeDominFeaturesList[sourceIdx][dictionaryKey[0]].Count]);
                            item.Value.AddRange(zeroList);
                        }
                        else
                        {
                            item.Value.AddRange(timeDominFeaturesList[sourceIdx][item.Key]);
                        }
                    }

                    rawFeatures.Add(item.Value);
                }

                features = dataCleaner.RemoveAbsoluteValue(rawFeatures);
            }

            StreamReader meanStdFile = new StreamReader(@"..\..\..\..\TrainingDataDump\bin\x64\Release\MeanStd.txt");
            int rowIndex = 0;
            string line;
            List<double> meanX = new List<double>();
            List<double> stdX = new List<double>();
            List<double> numOfX = new List<double>();
            while ((line = meanStdFile.ReadLine()) != null)
            {
                if (rowIndex == 0)
                {
                    List<string> slicingMeanX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingMeanX.Count; i++)
                    {
                        meanX.Add(Convert.ToDouble(slicingMeanX[i]));
                    }
                    rowIndex++;
                }
                else if (rowIndex == 1)
                {
                    List<string> slicingStdX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingStdX.Count; i++)
                    {
                        stdX.Add(Convert.ToDouble(slicingStdX[i]));
                    }
                    rowIndex++;
                }
                else if (rowIndex == 2)
                {
                    List<string> slicingNumOfX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingNumOfX.Count; i++)
                    {
                        numOfX.Add(Convert.ToDouble(slicingNumOfX[i]));
                    }
                    rowIndex++;
                }
                else
                {
                    break;
                }
            }

            for (int period = 0; period < features.Count; period++)
            {
                for (int elementIdx = 0; elementIdx < features[period].Count; elementIdx++)
                {
                    if (stdX[elementIdx] == 0)
                    {
                        features[period][elementIdx] = 0;
                    }
                    else
                    {
                        double tempMean = meanX[elementIdx];
                        numOfX[elementIdx] = numOfX[elementIdx] + 1;
                        meanX[elementIdx] = meanX[elementIdx] + (features[period][elementIdx] - meanX[elementIdx]) / numOfX[elementIdx];
                        stdX[elementIdx] = stdX[elementIdx] + (features[period][elementIdx] - tempMean) * (features[period][elementIdx] - meanX[elementIdx]);
                        features[period][elementIdx] = (features[period][elementIdx] - meanX[elementIdx]) / stdX[elementIdx];
                    }
                }
            }

            return features;
        }
    }
}
