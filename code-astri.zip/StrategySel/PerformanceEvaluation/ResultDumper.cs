﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PerformanceEvaluation
{
    class ResultDumper
    {
        public ResultDumper()
        {
            ;
        }

        public void PeriodTotalMoneyDump(string symbol, List<double> modelPortfolioTracker, List<double> avgModelPortfolioTracker, List<List<double>> strategiesPortfolioTracker)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\");
            StreamWriter performanceFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\" + "ModelNStrategiesPerformance.txt");
            string line = "model" + " " + "avgModel";

            for (int straIdx = 0; straIdx < strategiesPortfolioTracker.Count; straIdx++)
            {
                line = line + " " + String.Format("Strategy{0}", (straIdx + 1));
            }
            performanceFile.WriteLine(line);

            for (int periodIdx = 0; periodIdx < modelPortfolioTracker.Count; periodIdx++)
            {
                line = modelPortfolioTracker[periodIdx].ToString() + " " + avgModelPortfolioTracker[periodIdx].ToString();
                for (int straIdx = 0; straIdx < strategiesPortfolioTracker.Count; straIdx++)
                {
                    line = line + " " + strategiesPortfolioTracker[straIdx][periodIdx];
                }
                performanceFile.WriteLine(line);
            }

            performanceFile.Close();
        }

        public void SharpRatioDump(string symbol, List<double> modelPortfolioTracker, List<double> avgModelPortfolioTracker, List<List<double>> strategiesPortfolioTracker)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\");
            StreamWriter sharpRatioFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\" + "ModelNStrategiesSharpRatio.txt");
            Evaluator evaluator = new Evaluator();

            double modelSharpRatio = evaluator.ModelPerformanceSharpRatio(modelPortfolioTracker);
            double avgModelSharpRatio = evaluator.ModelPerformanceSharpRatio(avgModelPortfolioTracker);
            List<double> strategiesSharpRatio = evaluator.StrategiesPerformanceSharpRatio(strategiesPortfolioTracker);

            sharpRatioFile.WriteLine("model SharpRatio");
            sharpRatioFile.WriteLine(modelSharpRatio);
            sharpRatioFile.WriteLine("avgModel SharpRatio");
            sharpRatioFile.WriteLine(avgModelSharpRatio);

            for (int straIdx = 0; straIdx < strategiesPortfolioTracker.Count; straIdx++)
            {
                sharpRatioFile.WriteLine(String.Format("Strategy {0}", straIdx + 1));
                sharpRatioFile.WriteLine(strategiesSharpRatio[straIdx]);
            }

            sharpRatioFile.Close();
        }

        public void Detail_BuyNSellSignalsDump(string symbol, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals, TrainingDataDump.Simulator simulator)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\");
            StreamWriter signalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\" + "Detail_StrategiesBuyNSellSignals.txt");

            string line = "DateTime";
            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++ )
            {
                line = line + String.Format(",Strategy{0}", idxStra + 1);
            }
            signalFile.WriteLine(line.Trim());

            foreach(DateTime dayRecord in modelDailyTradeSignals.Keys)
            {
                foreach(DateTime barTime in modelDailyTradeSignals[dayRecord].Keys)
                {
                    line = "";
                    line = line + barTime;
                    foreach(int tradeSignal in modelDailyTradeSignals[dayRecord][barTime])
                    {
                        switch (tradeSignal)
                        {
                            case 0:
                                line = line + "," + "HOLD";
                                break;
                            case 1:
                                line = line + "," + "CLOSE";
                                break;
                            case 2:
                                line = line + "," + "LONG_ENTRY";
                                break;
                            case 3:
                                line = line + "," + "SHORT_ENTRY";
                                break;
                            case 4:
                                line = line + "," + "LONG_TAKE_PROFIT";
                                break;
                            case 5:
                                line = line + "," + "LONG_STOP_LOSS";
                                break;
                            case 6:
                                line = line + "," + "LONG_EXIT";
                                break;
                            case 7:
                                line = line + "," + "SHORT_TAKE_PROFIT";
                                break;
                            case 8:
                                line = line + "," + "SHORT_STOP_LOSS";
                                break;
                            case 9:
                                line = line + "," + "SHORT_EXIT";
                                break;
                        }
                    }
                    signalFile.WriteLine(line.Trim());
                }
            }

            signalFile.Close();
        }

        public void Detail_OneStrategyBuyNSellSignalsDunp(string symbol, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals, int idxStra)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\");
            StreamWriter signalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\" + String.Format("Detail_Strategy{0}_BuyNSellSignals.txt", idxStra + 1));

            string line = "DateTime";
            line = line + String.Format(",Strategy{0}", idxStra + 1);
            signalFile.WriteLine(line.Trim());

            foreach (DateTime dayRecord in modelDailyTradeSignals.Keys)
            {
                foreach (DateTime barTime in modelDailyTradeSignals[dayRecord].Keys)
                {
                    switch (modelDailyTradeSignals[dayRecord][barTime][idxStra])
                    {
                        case 0:
                            break;
                        case 1:
                            line = "";
                            line = line + barTime;
                            line = line + "," + "CLOSE";
                            signalFile.WriteLine(line.Trim());
                            break;
                        case 2:
                            line = "";
                            line = line + barTime;
                            line = line + "," + "LONG_ENTRY";
                            signalFile.WriteLine(line.Trim());
                            break;
                        case 3:
                            line = "";
                            line = line + barTime;
                            line = line + "," + "SHORT_ENTRY";
                            signalFile.WriteLine(line.Trim());
                            break;
                        case 4:
                            line = "";
                            line = line + barTime;
                            line = line + "," + "LONG_TAKE_PROFIT";
                            signalFile.WriteLine(line.Trim());
                            break;
                        case 5:
                            line = "";
                            line = line + barTime;
                            line = line + "," + "LONG_STOP_LOSS";
                            signalFile.WriteLine(line.Trim());
                            break;
                        case 6:
                            line = "";
                            line = line + barTime;
                            line = line + "," + "LONG_EXIT";
                            signalFile.WriteLine(line.Trim());
                            break;
                        case 7:
                            line = "";
                            line = line + barTime;
                            line = line + "," + "SHORT_TAKE_PROFIT";
                            signalFile.WriteLine(line.Trim());
                            break;
                        case 8:
                            line = "";
                            line = line + barTime;
                            line = line + "," + "SHORT_STOP_LOSS";
                            signalFile.WriteLine(line.Trim());
                            break;
                        case 9:
                            line = "";
                            line = line + barTime;
                            line = line + "," + "SHORT_EXIT";
                            signalFile.WriteLine(line.Trim());
                            break;
                    }
                }
            }

            signalFile.Close();
        }

        public void Binary_BuyNSellSignalsDump(string symbol, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals, TrainingDataDump.Simulator simulator)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\");
            StreamWriter signalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\" + "Binary_StrategiesBuyNSellSignals.txt");

            string line = "DateTime";
            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                line = line + String.Format(",Strategy{0}", idxStra + 1);
            }
            signalFile.WriteLine(line.Trim());

            foreach (DateTime dayRecord in modelDailyTradeSignals.Keys)
            {
                foreach (DateTime barTime in modelDailyTradeSignals[dayRecord].Keys)
                {
                    line = "";
                    line = line + barTime;
                    foreach (int tradeSignal in modelDailyTradeSignals[dayRecord][barTime])
                    {
                        if (tradeSignal == 0)
                        {
                            line = line + "," + "HOLD";
                        }
                        else if (tradeSignal == 1)
                        {
                            line = line + "," + "CLOSE";
                        }
                        else if (tradeSignal == 2)
                        {
                            line = line + "," + "LONG_ENTRY";
                        }
                        else if (tradeSignal == 3)
                        {
                            line = line + "," + "SHORT_ENTRY";
                        }
                        else if (tradeSignal == 4 || tradeSignal == 5 || tradeSignal == 6)
                        {
                            line = line + "," + "LONG_EXIT";
                        }
                        else
                        {
                            line = line + "," + "SHORT+EXIT";
                        }
                    }
                    signalFile.WriteLine(line.Trim());
                }
            }

            signalFile.Close();
        }

        public void Binary_OneStrategyBuyNSellSignalsDump(string symbol, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals, int idxStra)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\");
            StreamWriter signalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\" + String.Format("Binary_Strategy{0}_BuyNSellSignals.txt", idxStra + 1));

            string line = "DateTime";
            line = line + String.Format(",Strategy{0}", idxStra + 1);
            signalFile.WriteLine(line.Trim());

            foreach (DateTime dayRecord in modelDailyTradeSignals.Keys)
            {
                foreach (DateTime barTime in modelDailyTradeSignals[dayRecord].Keys)
                {
                    if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 0)
                    {
                        continue;
                    }
                    else if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 1)
                    {
                        line = "";
                        line = line + barTime + "," + "CLOSE";
                        signalFile.WriteLine(line.Trim());
                    }
                    else if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 2)
                    {
                        line = "";
                        line = line + barTime + "," + "LONG_ENTRY";
                        signalFile.WriteLine(line.Trim());
                    }
                    else if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 3)
                    {
                        line = "";
                        line = line + barTime + "," + "SHORT_ENTRY";
                        signalFile.WriteLine(line.Trim());
                    }
                    else if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 4 || modelDailyTradeSignals[dayRecord][barTime][idxStra] == 5 || modelDailyTradeSignals[dayRecord][barTime][idxStra] == 6)
                    {
                        line = "";
                        line = line + barTime + "," + "LONG_EXIT";
                        signalFile.WriteLine(line.Trim());
                    }
                    else
                    {
                        line = "";
                        line = line + barTime + "," + "SHORT_EXIT";
                        signalFile.WriteLine(line.Trim());
                    }
                }
            }

            signalFile.Close();
        }

        public void Simply_OneStrategyBuyNSellSignalsDump(string symbol, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals, int idxStra)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\Simply_StrategyBuyNSellSignal" + @"\");
            StreamWriter signalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\Simply_StrategyBuyNSellSignal" + @"\" + String.Format("Simply_Strategy{0}_BuyNSellSignals.txt", idxStra + 1));

            string line = "DateTime";
            line = line + String.Format(",Strategy{0}", idxStra + 1);
            signalFile.WriteLine(line.Trim());

            foreach (DateTime dayRecord in modelDailyTradeSignals.Keys)
            {
                foreach (DateTime barTime in modelDailyTradeSignals[dayRecord].Keys)
                {
                    if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 0)
                    {
                        continue;
                    }
                    else if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 1)
                    {
                        line = "";
                        line = line + barTime + "," + "CLOSE";
                        signalFile.WriteLine(line.Trim());
                    }
                    else if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 2)
                    {
                        line = "";
                        line = line + barTime + "," + "BUY";
                        signalFile.WriteLine(line.Trim());
                    }
                    else if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 3)
                    {
                        line = "";
                        line = line + barTime + "," + "SHORT_ENTRY";
                        signalFile.WriteLine(line.Trim());
                    }
                    else if (modelDailyTradeSignals[dayRecord][barTime][idxStra] == 4 || modelDailyTradeSignals[dayRecord][barTime][idxStra] == 5 || modelDailyTradeSignals[dayRecord][barTime][idxStra] == 6)
                    {
                        line = "";
                        line = line + barTime + "," + "SELL";
                        signalFile.WriteLine(line.Trim());
                    }
                    else
                    {
                        line = "";
                        line = line + barTime + "," + "SHORT_EXIT";
                        signalFile.WriteLine(line.Trim());
                    }
                }
            }

            signalFile.Close();
        }

        public void BuySellTimeSlotPicture(string symbol, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals, int idxStra, DataAPI.DataAPI api, DateTime start, DateTime end, int interval)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\BuySellTimeSlotPicture" + @"\");
            StreamWriter signalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\BuySellTimeSlotPicture" + @"\" + String.Format("Strategy{0}_BuyNSellPicture.txt", idxStra + 1));

            List<AxiomObjects.Bar> totalBars = api.GetHistoricalBarSync(symbol, '1', start, end, interval);

            List<decimal> closePriceList = new List<decimal>();
            foreach(AxiomObjects.Bar bar in totalBars)
            {
                closePriceList.Add(bar.Close);
            }

            string line = "DateTime";
            line = line + ",Open" + ",Close" + ",High" + ",Low" + ",Action";
            signalFile.WriteLine(line.Trim());

            foreach (AxiomObjects.Bar bar in totalBars)
            {
                line = bar.Time.ToString(@"MM\/dd\/yyyy HH:mm") + "," + bar.Open + "," + bar.Close + "," + bar.High + "," + bar.Low;
                /*
                if (modelDailyTradeSignals.Keys.Contains(bar.Time.Date))
                {
                    if (modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra] == 0)
                    {
                        line = line + "," + modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra];
                    }
                    else if (modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra] == 1)
                    {
                        line = line + "," + modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra];
                    }
                    else if (modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra] == 2)
                    {
                        line = line + "," + modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra];
                    }

                    else if (modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra] == 4 || modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra] == 5 || modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra] == 6)
                    {
                        line = line + "," + 3;
                    }
                }
                else
                {
                    line = line + ", ";
                }
                */

                if (modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra] == 4 || modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra] == 5 || modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra] == 6)
                {
                    line = line + "," + 3;
                }
                else
                {
                    line = line + "," + modelDailyTradeSignals[bar.Time.Date][bar.Time][idxStra];
                }

                signalFile.WriteLine(line);
            }

            signalFile.Close();
        }

        public void ModelTrader_StrategiesSignalDump(string symbol, Dictionary<DateTime, List<decimal>> modelTrader_StrategiesSignal, TrainingDataDump.Simulator simulator)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\");
            StreamWriter modelTrader_StrategiesSignalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\" + "ModelTrader_StrategiesSignal.txt");

            string line = "Datetime";
            for (int idxStra = 1; idxStra <= simulator.strategies.Count; idxStra++ )
            {
                line = line + "," + String.Format("Strategy{0}", idxStra);
            }
            modelTrader_StrategiesSignalFile.WriteLine(line);

            foreach(DateTime time in modelTrader_StrategiesSignal.Keys)
            {
                line = time.ToString();
                foreach(decimal signal in modelTrader_StrategiesSignal[time])
                {
                    line = line + "," + signal;
                }
                modelTrader_StrategiesSignalFile.WriteLine(line);
            }

            modelTrader_StrategiesSignalFile.Close();
        }

        public void AvgDistributeTrader_StrategiesSignalDump(string symbol, Dictionary<DateTime, List<decimal>> avgDistributeTrader_StrategiesSignal, TrainingDataDump.Simulator simulator)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\");
            StreamWriter avgDistributeTrader_StrategiesSignalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\" + "AvgDistributeTrader_StrategiesSignal.txt");

            string line = "Datetime";
            for (int idxStra = 1; idxStra <= simulator.strategies.Count; idxStra++)
            {
                line = line + "," + String.Format("Strategy{0}", idxStra);
            }
            avgDistributeTrader_StrategiesSignalFile.WriteLine(line);

            foreach (DateTime time in avgDistributeTrader_StrategiesSignal.Keys)
            {
                line = time.ToString();
                foreach (decimal signal in avgDistributeTrader_StrategiesSignal[time])
                {
                    line = line + "," + signal;
                }
                avgDistributeTrader_StrategiesSignalFile.WriteLine(line);
            }

            avgDistributeTrader_StrategiesSignalFile.Close();
        }

        public void MutiStrategiesTrader_StrategiesSignalDump(string symbol, Dictionary<DateTime, List<decimal>> mutiStrategiesTrader_StrategiesSignal, TrainingDataDump.Simulator simulator)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\");
            StreamWriter mutiStrategiesTrader_StrategiesSignalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\" + "MutiStrategiesTrader_StrategiesSignal.txt");

            string line = "Datetime";
            for (int idxStra = 1; idxStra <= simulator.strategies.Count; idxStra++)
            {
                line = line + "," + String.Format("Strategy{0}", idxStra);
            }
            mutiStrategiesTrader_StrategiesSignalFile.WriteLine(line);

            foreach (DateTime time in mutiStrategiesTrader_StrategiesSignal.Keys)
            {
                line = time.ToString();
                foreach (decimal signal in mutiStrategiesTrader_StrategiesSignal[time])
                {
                    line = line + "," + signal;
                }
                mutiStrategiesTrader_StrategiesSignalFile.WriteLine(line);
            }

            mutiStrategiesTrader_StrategiesSignalFile.Close();
        }

        public void Simply_ModelTrader_StrategiesSignalDump(string symbol, Dictionary<DateTime, List<decimal>> modelTrader_StrategiesSignal, int idxStra)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\Simply_ModelTrader_StrategiesSignal" + @"\");
            StreamWriter signalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\Simply_ModelTrader_StrategiesSignal" + @"\" + String.Format("Simply_Strategy{0}_BuyNSellSignals.txt", idxStra + 1));

            string line = "DateTime";
            line = line + String.Format(",Strategy{0}", idxStra + 1);
            signalFile.WriteLine(line.Trim());

            foreach(DateTime time in modelTrader_StrategiesSignal.Keys)
            {
                if (modelTrader_StrategiesSignal[time][idxStra] == 0)
                {
                    continue;
                }
                else
                {
                    line = time.ToString();
                    line = line + "," + modelTrader_StrategiesSignal[time][idxStra];
                    signalFile.WriteLine(line.Trim());
                }
            }

            signalFile.Close();
        }

        public void Simply_AvgDistributeTrader_StrategiesSignalDump(string symbol, Dictionary<DateTime, List<decimal>> avgDistributeTrader_StrategiesSignal, int idxStra)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\Simply_AvgDistributeTrader_StrategiesSignal" + @"\");
            StreamWriter signalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\Simply_AvgDistributeTrader_StrategiesSignal" + @"\" + String.Format("Simply_Strategy{0}_BuyNSellSignals.txt", idxStra + 1));

            string line = "DateTime";
            line = line + String.Format(",Strategy{0}", idxStra + 1);
            signalFile.WriteLine(line.Trim());

            foreach (DateTime time in avgDistributeTrader_StrategiesSignal.Keys)
            {
                if (avgDistributeTrader_StrategiesSignal[time][idxStra] == 0)
                {
                    continue;
                }
                else
                {
                    line = time.ToString();
                    line = line + "," + avgDistributeTrader_StrategiesSignal[time][idxStra];
                    signalFile.WriteLine(line.Trim());
                }
            }

            signalFile.Close();
        }

        public void Simply_MutiStrategiesTrader_StrategiesSignalDump(string symbol, Dictionary<DateTime, List<decimal>> mutiStrategiesTrader_StrategiesSignal, int idxStra)
        {
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\Simply_MutiStrategiesTrader_StrategiesSignal" + @"\");
            StreamWriter signalFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + symbol + @"\Simply_MutiStrategiesTrader_StrategiesSignal" + @"\" + String.Format("Simply_Strategy{0}_BuyNSellSignals.txt", idxStra + 1));

            string line = "DateTime";
            line = line + String.Format(",Strategy{0}", idxStra + 1);
            signalFile.WriteLine(line.Trim());

            foreach (DateTime time in mutiStrategiesTrader_StrategiesSignal.Keys)
            {
                if (mutiStrategiesTrader_StrategiesSignal[time][idxStra] == 0)
                {
                    continue;
                }
                else
                {
                    line = time.ToString();
                    line = line + "," + mutiStrategiesTrader_StrategiesSignal[time][idxStra];
                    signalFile.WriteLine(line.Trim());
                }
            }

            signalFile.Close();
        }
    }
}
