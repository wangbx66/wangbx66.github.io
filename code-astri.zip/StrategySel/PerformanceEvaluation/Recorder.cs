﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerformanceEvaluation
{
    class Recorder
    {
        public Recorder()
        {
            ;
        }

        public void InitStrategiesSignal(List<AxiomObjects.Bar> tradingBars, Dictionary<DateTime, List<decimal>> strategiesSignal, TrainingDataDump.Simulator simulator)
        {
            foreach(AxiomObjects.Bar bar in tradingBars)
            {
                strategiesSignal.Add(bar.Time, new List<decimal>(new decimal[simulator.strategies.Count]));
            }
        }

        public void AddModelSelInDayRecord(List<AxiomObjects.Bar> tradingBars, List<List<float>> modelSel, Dictionary<DateTime, Dictionary<DateTime, List<float>>> modelDailySel)
        {
            Dictionary<DateTime, List<float>> inDayRecorder = new Dictionary<DateTime, List<float>>();
            for (int periodIdx = 0; periodIdx < tradingBars.Count; periodIdx++)
            {
                inDayRecorder.Add(tradingBars[periodIdx].Time, modelSel[periodIdx]);
            }
            modelDailySel.Add(tradingBars[0].Time.Date, inDayRecorder);
        }

        public void AddModelTradeSignalInDayRecord(List<AxiomObjects.Bar> tradingBars, List<int[]> tradeSignal, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals)
        {
            Dictionary<DateTime, List<int>> inDayRecorder = new Dictionary<DateTime, List<int>>();
            for (int periodIdx = 0; periodIdx < tradingBars.Count; periodIdx++)
            {
                List<int> periodTradeSignal = new List<int>();
                for (int straIdx = 0; straIdx < tradeSignal.Count; straIdx++)
                {
                    periodTradeSignal.Add(tradeSignal[straIdx][periodIdx]);
                }
                inDayRecorder.Add(tradingBars[periodIdx].Time, periodTradeSignal);
            }
            modelDailyTradeSignals.Add(tradingBars[0].Time.Date, inDayRecorder);
        }

        public void AddModelTradeSignal_WithoutDayClose(List<AxiomObjects.Bar> tradingBars, List<int[]> tradeSignal, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals)
        {
            DateTime dateIdx = tradingBars[0].Time.Date;
            Dictionary<DateTime, List<int>> inDayRecorder = new Dictionary<DateTime, List<int>>();
            for (int periodIdx = 0; periodIdx < tradingBars.Count; periodIdx++)
            {
                if (periodIdx == tradingBars.Count - 1)
                {
                    List<int> periodTradeSignal = new List<int>();
                    for (int straIdx = 0; straIdx < tradeSignal.Count; straIdx++)
                    {
                        periodTradeSignal.Add(tradeSignal[straIdx][periodIdx]);
                    }
                    inDayRecorder.Add(tradingBars[periodIdx].Time, periodTradeSignal);

                    modelDailyTradeSignals.Add(dateIdx, inDayRecorder);
                    break;
                }

                if (dateIdx != tradingBars[periodIdx].Time.Date)
                {
                    modelDailyTradeSignals.Add(dateIdx, inDayRecorder);

                    inDayRecorder = new Dictionary<DateTime, List<int>>();
                    List<int> periodTradeSignal = new List<int>();
                    for (int straIdx = 0; straIdx < tradeSignal.Count; straIdx++)
                    {
                        periodTradeSignal.Add(tradeSignal[straIdx][periodIdx]);
                    }
                    inDayRecorder.Add(tradingBars[periodIdx].Time, periodTradeSignal);
                    dateIdx = tradingBars[periodIdx].Time.Date;
                }
                else
                {
                    List<int> periodTradeSignal = new List<int>();
                    for (int straIdx = 0; straIdx < tradeSignal.Count; straIdx++)
                    {
                        periodTradeSignal.Add(tradeSignal[straIdx][periodIdx]);
                    }
                    inDayRecorder.Add(tradingBars[periodIdx].Time, periodTradeSignal);
                }
            }
        }

        public void AddModelTradeSignalInDayRecord_NextDayOpenClose(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> nextDayBarsList, List<int[]> tradeSignal, Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals)
        {
            Dictionary<DateTime, List<int>> inDayRecorder = new Dictionary<DateTime, List<int>>();
            for (int periodIdx = 0; periodIdx < tradingBars.Count; periodIdx++)
            {
                List<int> periodTradeSignal = new List<int>();
                for (int straIdx = 0; straIdx < tradeSignal.Count; straIdx++)
                {
                    periodTradeSignal.Add(tradeSignal[straIdx][periodIdx]);
                }
                inDayRecorder.Add(tradingBars[periodIdx].Time, periodTradeSignal);
            }

            List<int> nextDayCloseSignals = new List<int>();
            for (int straIdx = 0; straIdx < tradeSignal.Count; straIdx++)
            {
                nextDayCloseSignals.Add(1);
            }
            inDayRecorder.Add(nextDayBarsList[1].Time, nextDayCloseSignals);

            modelDailyTradeSignals.Add(tradingBars[0].Time.Date, inDayRecorder);
        }

        public void AddModelDailyPerformance(List<AxiomObjects.Bar> tradingBars, List<decimal> modelPerildPerformance, Dictionary<DateTime, Dictionary<DateTime, decimal>> modelDailyPerformance)
        {
            Dictionary<DateTime, decimal> inDayRecorder = new Dictionary<DateTime, decimal>();
            for (int periodIdx = 0; periodIdx < tradingBars.Count; periodIdx++)
            {
                inDayRecorder.Add(tradingBars[periodIdx].Time, modelPerildPerformance[periodIdx]);
            }
            modelDailyPerformance.Add(tradingBars[0].Time.Date, inDayRecorder);
        }

        public void AddStrategiesDailyPerformance(List<AxiomObjects.Bar> tradingBars, List<List<decimal>> strategiesPerformanceContainer, Dictionary<DateTime, Dictionary<DateTime, List<decimal>>> strategiesDailyPerformance)
        {
            Dictionary<DateTime, List<decimal>> inDayRecorder = new Dictionary<DateTime, List<decimal>>();
            for (int periodIdx = 0; periodIdx < tradingBars.Count; periodIdx++ )
            {
                List<decimal> strategiesPerformancePerPeriod = new List<decimal>();
                for (int straIdx = 0; straIdx < strategiesPerformanceContainer.Count; straIdx++ )
                {
                    strategiesPerformancePerPeriod.Add(strategiesPerformanceContainer[straIdx][periodIdx]);
                }
                inDayRecorder.Add(tradingBars[periodIdx].Time, strategiesPerformancePerPeriod);
            }
            strategiesDailyPerformance.Add(tradingBars[0].Time.Date, inDayRecorder);
        }
    }
}
