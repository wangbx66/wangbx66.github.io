﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerformanceEvaluation
{
    class Evaluator
    {
        public Evaluator()
        {
            ;
        }

        public double ModelPerformanceSharpRatio(List<double> modelPortfolioTracker)
        {
            double sharpRatio = 0;
            List<double> returnList = new List<double>();
            for (int elementCount = 0; elementCount < modelPortfolioTracker.Count - 1; elementCount++)
            {
                returnList.Add((modelPortfolioTracker[elementCount + 1] - modelPortfolioTracker[elementCount]) / modelPortfolioTracker[elementCount]);
            }
            Tuple<double, double> t = MeanStd(returnList);
            if (t.Item2 == 0)
            {
                sharpRatio = 0;
            }
            else
            {
                sharpRatio = t.Item1 / t.Item2;
            }
            return sharpRatio;
        }

        public List<double> StrategiesPerformanceSharpRatio(List<List<double>> strategiesPortfolioTracker)
        {
            List<double> strategiesSharpRatio = new List<double>();

            for (int straIdx = 0; straIdx < strategiesPortfolioTracker.Count; straIdx++)
            {
                double sharpRatio = 0;
                List<double> singleStrategyReturnList = new List<double>();
                for (int period = 0; period < strategiesPortfolioTracker[straIdx].Count - 1; period++)
                {
                    singleStrategyReturnList.Add((strategiesPortfolioTracker[straIdx][period + 1] - strategiesPortfolioTracker[straIdx][period]) / strategiesPortfolioTracker[straIdx][period]);
                }
                Tuple<double, double> t = MeanStd(singleStrategyReturnList);
                if (t.Item2 == 0)
                {
                    sharpRatio = 0;
                }
                else
                {
                    sharpRatio = t.Item1 / t.Item2;
                }
                strategiesSharpRatio.Add(sharpRatio);
            }

            return strategiesSharpRatio;
        }

        public Tuple<double, double> MeanStd(List<double> valueList)
        {
            double M = 0.0;
            double S = 0.0;
            int k = 1;
            foreach (double value in valueList)
            {
                double tmpM = M;
                M += (value - tmpM) / k;
                S += (value - tmpM) * (value - M);
                k++;
            }
            return Tuple.Create<double, double>(M, Math.Sqrt(S / (k - 2)));
        }
    }
}
