﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ModulusFE.TASDK;

namespace PerformanceEvaluation
{
    public class MoneyDistributor
    {
        public MoneyDistributor()
        {
            ;
        }

        public decimal EquallyDistribute(decimal initMoney, Navigator databaseNavigator, int explorationLength, int trailLength)
        {
            return initMoney / (databaseNavigator.RecordCount - explorationLength - trailLength);
        }

        public double Realtime_EquallyDistribute(double moneyRemained, List<AxiomObjects.Bar> tradingBars, int explorationLength, int trailLength, int seqLength)
        {
            if (tradingBars.Count > explorationLength && tradingBars.Count < seqLength - trailLength)
            {
                return moneyRemained / (seqLength - trailLength - tradingBars.Count);
            }
            else
            {
                return 0;
            }
        }
    }
}
