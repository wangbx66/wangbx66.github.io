﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Text.RegularExpressions;

namespace PerformanceEvaluation
{
    class Program
    {
        static void Main(string[] args)
        {
            //SingleSymbolTrade("601988-SSE");
            //MutiSymbolsTrade("600135-SSE");
            MutiSymbolsTrade_WithoutDayClose("600135-SSE");
            //MutiSymbolsTrade_NextDayOpenClose("600135-SSE");
        }

        static void SingleSymbolTrade(string symbol = "")
        {
            #region initial
            string mqServer = ConfigurationManager.AppSettings["MqServer"];
            ushort mqPort = Convert.ToUInt16(ConfigurationManager.AppSettings["MqPort"]);
            string mqUser = ConfigurationManager.AppSettings["MqUser"];
            string mqPassword = ConfigurationManager.AppSettings["MqPassword"];
            string requestQueue = ConfigurationManager.AppSettings["RequestQueue"];
            string httpServer = ConfigurationManager.AppSettings["DataStoreManagerIp"];
            ushort httpPort = Convert.ToUInt16(ConfigurationManager.AppSettings["DataStoreManagerPort"]);

            int maxStrategiesNum = 8;
            DateTime start = new DateTime(2016, 1, 1, 8, 0, 0);
            DateTime end = new DateTime(2016, 6, 1, 8, 0, 0);
            string model = "Trained_StrategySel_Model.dnn";
            string name = "minute";
            int interval = 1;
            TimeSpan seqSpan = TimeSpan.FromDays(1);
            double commissionFeeNTax = 0.0008;
            double initMoney = 9000;
            DataAPI.DataAPI api = new DataAPI.DataAPI(mqServer, mqPort, mqUser, mqPassword, requestQueue, httpServer, httpPort, null);
            TrainingDataDump.DataCleaner dataCleaner = new TrainingDataDump.DataCleaner();
            TrainingDataDump.BarsQualityChecker checker = new TrainingDataDump.BarsQualityChecker();
            TrainingDataDump.Simulator simulator = new TrainingDataDump.Simulator();
            //TrainingDataDump.StrategiesReader strategiesReader = new TrainingDataDump.StrategiesReader();
            //strategiesReader.csvStrategiesLoader(simulator, maxStrategiesNum);
            simulator.LoadDefault();

            Dictionary<DateTime, Dictionary<DateTime, decimal>> modelDailyPerformance = new Dictionary<DateTime,Dictionary<DateTime,decimal>>();
            Dictionary<DateTime, Dictionary<DateTime, decimal>> avgModelDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, decimal>>();
            Dictionary<DateTime, Dictionary<DateTime, List<float>>> modelDailySel = new Dictionary<DateTime,Dictionary<DateTime,List<float>>>();
            Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals = new Dictionary<DateTime,Dictionary<DateTime,List<int>>>();
            Dictionary<DateTime, Dictionary<DateTime, List<decimal>>> strategiesDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, List<decimal>>>();

            List<double> modelPortfolioTracker = new List<double>();
            modelPortfolioTracker.Add(initMoney);

            List<double> avgModelPortfolioTracker = new List<double>();
            avgModelPortfolioTracker.Add(initMoney);

            Dictionary<DateTime, List<decimal>> modelTrader_StrategiesSignal = new Dictionary<DateTime, List<decimal>>();
            Dictionary<DateTime, List<decimal>> avgDistributeTrader_StrategiesSignal = new Dictionary<DateTime, List<decimal>>();
            Dictionary<DateTime, List<decimal>> mutiStrategiesTrader_StrategiesSignal = new Dictionary<DateTime, List<decimal>>();

            List<List<double>> strategiesPortfolioTracker = new List<List<double>>();
            for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
            {
                List<double> singleStrategyPortfolioTracker = new List<double>();
                singleStrategyPortfolioTracker.Add(initMoney);
                strategiesPortfolioTracker.Add(singleStrategyPortfolioTracker);
            }
            #endregion initial

            int dayCount = 0;
            Trader trader = new Trader(model, simulator, commissionFeeNTax, name);
            for (DateTime seqStart = start; seqStart < end; seqStart += seqSpan)
            {
                string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
                int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
                int minimumPeriods = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "minimumPeriods", "30"));

                double modelStartingMoney = modelPortfolioTracker[dayCount];
                double avgModelStartingMoney = avgModelPortfolioTracker[dayCount];
                List<double> strategiesStartingMoney = new List<double>();
                for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                {
                    strategiesStartingMoney.Add(strategiesPortfolioTracker[straIdx][dayCount]);
                }

                List<AxiomObjects.Bar> tradingBars = api.GetHistoricalBarSync(symbol, '1', seqStart, seqStart + seqSpan, interval);
                if (tradingBars == null || checker.minimumBarsRecord(tradingBars, minimumPeriods) || checker.minimumVolumn(tradingBars))
                {
                    continue;
                }

                DateTime historicalStart = seqStart - seqSpan;
                DateTime historicalEnd = seqStart;
                do
                {
                    historicalStart = historicalStart - seqSpan;
                    historicalEnd = historicalEnd - seqSpan;
                } while (api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval).Count <= minimumPeriods);
                List<AxiomObjects.Bar> historicalTradingSymbolBars = api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval);

                List<AxiomObjects.Bar> twoDaySeq = dataCleaner.BarsListCombiner(tradingBars, historicalTradingSymbolBars);

                //data smothing
                //currently, method SmothData_test do nothing at all, should be developed in the future if keep position to next day
                dataCleaner.SmothData_test(twoDaySeq);

                trader.ModelTrader(tradingBars, historicalTradingSymbolBars, twoDaySeq, modelStartingMoney, modelDailyPerformance, modelDailySel, modelDailyTradeSignals, modelTrader_StrategiesSignal);
                trader.AvgDistributeTrader(tradingBars, historicalTradingSymbolBars, twoDaySeq, avgModelStartingMoney, avgModelDailyPerformance, avgDistributeTrader_StrategiesSignal);
                trader.MutiStrategiesTrader(tradingBars, historicalTradingSymbolBars, twoDaySeq, strategiesStartingMoney, strategiesDailyPerformance, mutiStrategiesTrader_StrategiesSignal);

                modelPortfolioTracker.Add(Convert.ToDouble(modelDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time]) + modelStartingMoney);
                avgModelPortfolioTracker.Add(Convert.ToDouble(avgModelDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time]) + avgModelStartingMoney);
                for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                {
                    strategiesPortfolioTracker[straIdx].Add(Convert.ToDouble(strategiesDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time][straIdx]) + strategiesStartingMoney[straIdx]);
                }

                dayCount++;
                Console.WriteLine(String.Format("{0} to {1} has been finished", seqStart, seqStart + seqSpan));
            }

            ResultDumper dumper = new ResultDumper();
            dumper.PeriodTotalMoneyDump(symbol, modelPortfolioTracker, avgModelPortfolioTracker, strategiesPortfolioTracker);
            dumper.SharpRatioDump(symbol, modelPortfolioTracker, avgModelPortfolioTracker, strategiesPortfolioTracker);
            dumper.Detail_BuyNSellSignalsDump(symbol, modelDailyTradeSignals, simulator);
            dumper.Detail_OneStrategyBuyNSellSignalsDunp(symbol, modelDailyTradeSignals, 7);
            dumper.Binary_BuyNSellSignalsDump(symbol, modelDailyTradeSignals, simulator);
            dumper.Binary_OneStrategyBuyNSellSignalsDump(symbol, modelDailyTradeSignals, 7);
            dumper.Simply_OneStrategyBuyNSellSignalsDump(symbol, modelDailyTradeSignals, 7);
        }

        static void MutiSymbolsTrade(string stockSymbol = "")
        {
            DateTime start = new DateTime(2016, 6, 1, 8, 0, 0);
            DateTime end = new DateTime(2016, 7, 1, 8, 0, 0);
            int interval = 1;

            string mqServer = ConfigurationManager.AppSettings["MqServer"];
            ushort mqPort = Convert.ToUInt16(ConfigurationManager.AppSettings["MqPort"]);
            string mqUser = ConfigurationManager.AppSettings["MqUser"];
            string mqPassword = ConfigurationManager.AppSettings["MqPassword"];
            string requestQueue = ConfigurationManager.AppSettings["RequestQueue"];
            string httpServer = ConfigurationManager.AppSettings["DataStoreManagerIp"];
            ushort httpPort = Convert.ToUInt16(ConfigurationManager.AppSettings["DataStoreManagerPort"]);
            DataAPI.DataAPI api = new DataAPI.DataAPI(mqServer, mqPort, mqUser, mqPassword, requestQueue, httpServer, httpPort, null);

            List<string> symbolList = new List<string>();
            StreamReader symbolFile = new System.IO.StreamReader(@"..\..\..\..\SymbolsFile\" + stockSymbol + "_RelatedSymbols");
            string line;
            while ((line = symbolFile.ReadLine()) != null)
            {
                line = line.Trim();
                symbolList.Add(Regex.Split(line, " ")[0]);
            }
            symbolFile.Close();

            foreach (string symbol in symbolList)
            {
                Console.WriteLine(String.Format("{0} start", symbol));

                #region initial
                int maxStrategiesNum = 15;

                string model = "Trained_StrategySel_Model.dnn";
                string name = "minute";
                TimeSpan seqSpan = TimeSpan.FromDays(1);
                double commissionFeeNTax = 0.003;
                double initMoney = 9000;
                TrainingDataDump.DataCleaner dataCleaner = new TrainingDataDump.DataCleaner();
                TrainingDataDump.BarsQualityChecker checker = new TrainingDataDump.BarsQualityChecker();
                TrainingDataDump.Simulator simulator = new TrainingDataDump.Simulator();
                TrainingDataDump.StrategiesReader strategiesReader = new TrainingDataDump.StrategiesReader();
                strategiesReader.csvStrategiesLoader(simulator, maxStrategiesNum);
                //simulator.LoadDefault();

                Dictionary<DateTime, Dictionary<DateTime, decimal>> modelDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, decimal>>();
                Dictionary<DateTime, Dictionary<DateTime, decimal>> avgModelDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, decimal>>();
                Dictionary<DateTime, Dictionary<DateTime, List<float>>> modelDailySel = new Dictionary<DateTime, Dictionary<DateTime, List<float>>>();
                Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals = new Dictionary<DateTime, Dictionary<DateTime, List<int>>>();
                Dictionary<DateTime, Dictionary<DateTime, List<decimal>>> strategiesDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, List<decimal>>>();

                List<double> modelPortfolioTracker = new List<double>();
                modelPortfolioTracker.Add(initMoney);

                List<double> avgModelPortfolioTracker = new List<double>();
                avgModelPortfolioTracker.Add(initMoney);

                Dictionary<DateTime, List<decimal>> modelTrader_StrategiesSignal = new Dictionary<DateTime, List<decimal>>();
                Dictionary<DateTime, List<decimal>> avgDistributeTrader_StrategiesSignal = new Dictionary<DateTime,List<decimal>>();
                Dictionary<DateTime, List<decimal>> mutiStrategiesTrader_StrategiesSignal = new Dictionary<DateTime,List<decimal>>();

                List<List<double>> strategiesPortfolioTracker = new List<List<double>>();
                for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                {
                    List<double> singleStrategyPortfolioTracker = new List<double>();
                    singleStrategyPortfolioTracker.Add(initMoney);
                    strategiesPortfolioTracker.Add(singleStrategyPortfolioTracker);
                }
                #endregion initial

                int dayCount = 0;
                for (DateTime seqStart = start; seqStart < end; seqStart += seqSpan)
                {
                    string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
                    int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
                    int minimumPeriods = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "minimumPeriods", "30"));

                    double modelStartingMoney = modelPortfolioTracker[dayCount];
                    double avgModelStartingMoney = avgModelPortfolioTracker[dayCount];
                    List<double> strategiesStartingMoney = new List<double>();
                    for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                    {
                        strategiesStartingMoney.Add(strategiesPortfolioTracker[straIdx][dayCount]);
                    }
                    Trader trader = new Trader(model, simulator, commissionFeeNTax, name);

                    List<AxiomObjects.Bar> tradingBars = api.GetHistoricalBarSync(symbol, '1', seqStart, seqStart + seqSpan, interval);
                    if (tradingBars == null || checker.minimumBarsRecord(tradingBars, minimumPeriods) || checker.minimumVolumn(tradingBars))
                    {
                        continue;
                    }

                    DateTime historicalStart = seqStart - seqSpan;
                    DateTime historicalEnd = seqStart;
                    do
                    {
                        historicalStart = historicalStart - seqSpan;
                        historicalEnd = historicalEnd - seqSpan;
                    } while (api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval).Count <= minimumPeriods);
                    List<AxiomObjects.Bar> historicalTradingSymbolBars = api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval);

                    List<AxiomObjects.Bar> twoDaySeq = dataCleaner.BarsListCombiner(tradingBars, historicalTradingSymbolBars);

                    dataCleaner.SmothData_test(twoDaySeq);

                    trader.ModelTrader(tradingBars, historicalTradingSymbolBars, twoDaySeq, modelStartingMoney, modelDailyPerformance, modelDailySel, modelDailyTradeSignals, modelTrader_StrategiesSignal);
                    trader.AvgDistributeTrader(tradingBars, historicalTradingSymbolBars, twoDaySeq, avgModelStartingMoney, avgModelDailyPerformance, avgDistributeTrader_StrategiesSignal);
                    trader.MutiStrategiesTrader(tradingBars, historicalTradingSymbolBars, twoDaySeq, strategiesStartingMoney, strategiesDailyPerformance, mutiStrategiesTrader_StrategiesSignal);

                    modelPortfolioTracker.Add(Convert.ToDouble(modelDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time]) + modelStartingMoney);
                    avgModelPortfolioTracker.Add(Convert.ToDouble(avgModelDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time]) + avgModelStartingMoney);
                    for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                    {
                        strategiesPortfolioTracker[straIdx].Add(Convert.ToDouble(strategiesDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time][straIdx]) + strategiesStartingMoney[straIdx]);
                    }

                    dayCount++;
                    Console.WriteLine(String.Format("{0} to {1} has been finished", seqStart, seqStart + seqSpan));
                }

                ResultDumper dumper = new ResultDumper();
                dumper.PeriodTotalMoneyDump(symbol, modelPortfolioTracker, avgModelPortfolioTracker, strategiesPortfolioTracker);
                dumper.SharpRatioDump(symbol, modelPortfolioTracker, avgModelPortfolioTracker, strategiesPortfolioTracker);
                dumper.Detail_BuyNSellSignalsDump(symbol, modelDailyTradeSignals, simulator);
                dumper.Binary_BuyNSellSignalsDump(symbol, modelDailyTradeSignals, simulator);
                for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
                {
                    dumper.Simply_OneStrategyBuyNSellSignalsDump(symbol, modelDailyTradeSignals, idxStra);
                    dumper.BuySellTimeSlotPicture(symbol, modelDailyTradeSignals, idxStra, api, start, end, interval);
                    dumper.Simply_ModelTrader_StrategiesSignalDump(symbol, modelTrader_StrategiesSignal, idxStra);
                    dumper.Simply_AvgDistributeTrader_StrategiesSignalDump(symbol, avgDistributeTrader_StrategiesSignal, idxStra);
                    dumper.Simply_MutiStrategiesTrader_StrategiesSignalDump(symbol, mutiStrategiesTrader_StrategiesSignal, idxStra);
                }
                dumper.ModelTrader_StrategiesSignalDump(symbol, modelTrader_StrategiesSignal, simulator);
                dumper.AvgDistributeTrader_StrategiesSignalDump(symbol, avgDistributeTrader_StrategiesSignal, simulator);
                dumper.MutiStrategiesTrader_StrategiesSignalDump(symbol, mutiStrategiesTrader_StrategiesSignal, simulator);
            }
        }

        static void MutiSymbolsTrade_WithoutDayClose(string stockSymbol = "")
        {
            string mqServer = ConfigurationManager.AppSettings["MqServer"];
            ushort mqPort = Convert.ToUInt16(ConfigurationManager.AppSettings["MqPort"]);
            string mqUser = ConfigurationManager.AppSettings["MqUser"];
            string mqPassword = ConfigurationManager.AppSettings["MqPassword"];
            string requestQueue = ConfigurationManager.AppSettings["RequestQueue"];
            string httpServer = ConfigurationManager.AppSettings["DataStoreManagerIp"];
            ushort httpPort = Convert.ToUInt16(ConfigurationManager.AppSettings["DataStoreManagerPort"]);
            DataAPI.DataAPI api = new DataAPI.DataAPI(mqServer, mqPort, mqUser, mqPassword, requestQueue, httpServer, httpPort, null);

            List<string> symbolList = new List<string>();
            StreamReader symbolFile = new System.IO.StreamReader(@"..\..\..\..\SymbolsFile\" + stockSymbol + "_RelatedSymbols");
            string line;
            while ((line = symbolFile.ReadLine()) != null)
            {
                line = line.Trim();
                symbolList.Add(Regex.Split(line, " ")[0]);
            }
            symbolFile.Close();

            foreach (string symbol in symbolList)
            {
                Console.WriteLine(String.Format("{0} start", symbol));

                #region initial
                int maxStrategiesNum = 15;

                DateTime start = new DateTime(2016, 6, 1, 8, 0, 0);
                DateTime end = new DateTime(2016, 7, 1, 8, 0, 0);
                string model = "Trained_StrategySel_Model.dnn";
                string name = "minute";
                int interval = 1;
                TimeSpan seqSpan = TimeSpan.FromDays(1);
                double commissionFeeNTax = 0.003;
                double initMoney = 9000;
                TrainingDataDump.DataCleaner dataCleaner = new TrainingDataDump.DataCleaner();
                TrainingDataDump.BarsQualityChecker checker = new TrainingDataDump.BarsQualityChecker();
                TrainingDataDump.Simulator simulator = new TrainingDataDump.Simulator();
                TrainingDataDump.StrategiesReader strategiesReader = new TrainingDataDump.StrategiesReader();
                strategiesReader.csvStrategiesLoader(simulator, maxStrategiesNum);
                //simulator.LoadDefault();

                Dictionary<DateTime, Dictionary<DateTime, decimal>> modelDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, decimal>>();
                Dictionary<DateTime, Dictionary<DateTime, decimal>> avgModelDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, decimal>>();
                Dictionary<DateTime, Dictionary<DateTime, List<float>>> modelDailySel = new Dictionary<DateTime, Dictionary<DateTime, List<float>>>();
                Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals = new Dictionary<DateTime, Dictionary<DateTime, List<int>>>();
                Dictionary<DateTime, Dictionary<DateTime, List<decimal>>> strategiesDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, List<decimal>>>();

                List<double> modelPortfolioTracker = new List<double>();
                modelPortfolioTracker.Add(initMoney);

                List<double> avgModelPortfolioTracker = new List<double>();
                avgModelPortfolioTracker.Add(initMoney);

                List<List<double>> strategiesPortfolioTracker = new List<List<double>>();
                for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                {
                    List<double> singleStrategyPortfolioTracker = new List<double>();
                    singleStrategyPortfolioTracker.Add(initMoney);
                    strategiesPortfolioTracker.Add(singleStrategyPortfolioTracker);
                }
                #endregion initial

                string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
                int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
                int minimumPeriods = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "minimumPeriods", "30"));

                double modelStartingMoney = initMoney;
                double avgModelStartingMoney = initMoney;
                List<double> strategiesStartingMoney = new List<double>();
                for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                {
                    strategiesStartingMoney.Add(initMoney);
                }
                Trader trader = new Trader(model, simulator, commissionFeeNTax, name);

                List<AxiomObjects.Bar> tradingBars = api.GetHistoricalBarSync(symbol, '1', start, end, interval);
                if (tradingBars == null || checker.minimumBarsRecord(tradingBars, minimumPeriods) || checker.minimumVolumn(tradingBars))
                {
                    Console.WriteLine(String.Format("Unusual on {0}, exit", symbol));
                    continue;
                }

                DateTime historicalStart = start - seqSpan;
                DateTime historicalEnd = start;
                do
                {
                    historicalStart = historicalStart - seqSpan;
                    historicalEnd = historicalEnd - seqSpan;
                } while (api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval).Count <= minimumPeriods);
                List<AxiomObjects.Bar> historicalTradingSymbolBars = api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval);

                List<AxiomObjects.Bar> totalSeq = dataCleaner.BarsListCombiner(tradingBars, historicalTradingSymbolBars);

                dataCleaner.SmothData_test(totalSeq);

                trader.ModelTrader_WithoutDayClose(tradingBars, historicalTradingSymbolBars, totalSeq, modelStartingMoney, modelDailyPerformance, modelDailySel, modelDailyTradeSignals);
                trader.AvgDistributeTrader_WithoutDayClose(tradingBars, historicalTradingSymbolBars, totalSeq, avgModelStartingMoney, avgModelDailyPerformance);
                trader.MutiStrategiesTrader_WithoutDayClose(tradingBars, historicalTradingSymbolBars, totalSeq, strategiesStartingMoney, strategiesDailyPerformance);

                modelPortfolioTracker.Add(Convert.ToDouble(modelDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time]) + modelStartingMoney);
                avgModelPortfolioTracker.Add(Convert.ToDouble(avgModelDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time]) + avgModelStartingMoney);
                for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                {
                    strategiesPortfolioTracker[straIdx].Add(Convert.ToDouble(strategiesDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time][straIdx]) + strategiesStartingMoney[straIdx]);
                }

                Console.WriteLine(String.Format("{0} finished", symbol));

                ResultDumper dumper = new ResultDumper();
                dumper.PeriodTotalMoneyDump(symbol, modelPortfolioTracker, avgModelPortfolioTracker, strategiesPortfolioTracker);
                dumper.SharpRatioDump(symbol, modelPortfolioTracker, avgModelPortfolioTracker, strategiesPortfolioTracker);
                dumper.Detail_BuyNSellSignalsDump(symbol, modelDailyTradeSignals, simulator);
                dumper.Binary_BuyNSellSignalsDump(symbol, modelDailyTradeSignals, simulator);
                for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
                {
                    dumper.Simply_OneStrategyBuyNSellSignalsDump(symbol, modelDailyTradeSignals, idxStra);
                    dumper.BuySellTimeSlotPicture(symbol, modelDailyTradeSignals, idxStra, api, start, end, interval);
                }
            }
        }

        static void MutiSymbolsTrade_NextDayOpenClose(string stockSymbol = "")
        {
            string mqServer = ConfigurationManager.AppSettings["MqServer"];
            ushort mqPort = Convert.ToUInt16(ConfigurationManager.AppSettings["MqPort"]);
            string mqUser = ConfigurationManager.AppSettings["MqUser"];
            string mqPassword = ConfigurationManager.AppSettings["MqPassword"];
            string requestQueue = ConfigurationManager.AppSettings["RequestQueue"];
            string httpServer = ConfigurationManager.AppSettings["DataStoreManagerIp"];
            ushort httpPort = Convert.ToUInt16(ConfigurationManager.AppSettings["DataStoreManagerPort"]);
            DataAPI.DataAPI api = new DataAPI.DataAPI(mqServer, mqPort, mqUser, mqPassword, requestQueue, httpServer, httpPort, null);

            List<string> symbolList = new List<string>();
            StreamReader symbolFile = new System.IO.StreamReader(@"..\..\..\..\SymbolsFile\" + stockSymbol + "_RelatedSymbols");
            string line;
            while ((line = symbolFile.ReadLine()) != null)
            {
                line = line.Trim();
                symbolList.Add(Regex.Split(line, " ")[0]);
            }
            symbolFile.Close();

            foreach (string symbol in symbolList)
            {
                Console.WriteLine(String.Format("{0} start", symbol));

                #region initial
                int maxStrategiesNum = 15;

                DateTime start = new DateTime(2016, 6, 1, 8, 0, 0);
                DateTime end = new DateTime(2016, 6, 24, 8, 0, 0);
                string model = "Trained_StrategySel_Model.dnn";
                string name = "minute";
                int interval = 1;
                TimeSpan seqSpan = TimeSpan.FromDays(1);
                double commissionFeeNTax = 0.003;
                double initMoney = 9000;
                TrainingDataDump.DataCleaner dataCleaner = new TrainingDataDump.DataCleaner();
                TrainingDataDump.BarsQualityChecker checker = new TrainingDataDump.BarsQualityChecker();
                TrainingDataDump.Simulator simulator = new TrainingDataDump.Simulator();
                TrainingDataDump.StrategiesReader strategiesReader = new TrainingDataDump.StrategiesReader();
                strategiesReader.csvStrategiesLoader(simulator, maxStrategiesNum);
                //simulator.LoadDefault();

                Dictionary<DateTime, Dictionary<DateTime, decimal>> modelDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, decimal>>();
                Dictionary<DateTime, Dictionary<DateTime, decimal>> avgModelDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, decimal>>();
                Dictionary<DateTime, Dictionary<DateTime, List<float>>> modelDailySel = new Dictionary<DateTime, Dictionary<DateTime, List<float>>>();
                Dictionary<DateTime, Dictionary<DateTime, List<int>>> modelDailyTradeSignals = new Dictionary<DateTime, Dictionary<DateTime, List<int>>>();
                Dictionary<DateTime, Dictionary<DateTime, List<decimal>>> strategiesDailyPerformance = new Dictionary<DateTime, Dictionary<DateTime, List<decimal>>>();

                List<double> modelPortfolioTracker = new List<double>();
                modelPortfolioTracker.Add(initMoney);

                List<double> avgModelPortfolioTracker = new List<double>();
                avgModelPortfolioTracker.Add(initMoney);

                List<List<double>> strategiesPortfolioTracker = new List<List<double>>();
                for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                {
                    List<double> singleStrategyPortfolioTracker = new List<double>();
                    singleStrategyPortfolioTracker.Add(initMoney);
                    strategiesPortfolioTracker.Add(singleStrategyPortfolioTracker);
                }
                #endregion initial

                int dayCount = 0;
                for (DateTime seqStart = start; seqStart < end; seqStart += seqSpan)
                {
                    string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Trading.ini";
                    int explorationLength = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
                    int minimumPeriods = Convert.ToInt32(TrainingDataDump.INIOperationClass.INIGetStringValue(iniFile, name, "minimumPeriods", "30"));

                    double modelStartingMoney = modelPortfolioTracker[dayCount];
                    double avgModelStartingMoney = avgModelPortfolioTracker[dayCount];
                    List<double> strategiesStartingMoney = new List<double>();
                    for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                    {
                        strategiesStartingMoney.Add(strategiesPortfolioTracker[straIdx][dayCount]);
                    }
                    Trader trader = new Trader(model, simulator, commissionFeeNTax, name);

                    List<AxiomObjects.Bar> tradingBars = api.GetHistoricalBarSync(symbol, '1', seqStart, seqStart + seqSpan, interval);
                    if (tradingBars == null || checker.minimumBarsRecord(tradingBars, minimumPeriods) || checker.minimumVolumn(tradingBars))
                    {
                        continue;
                    }

                    DateTime historicalStart = seqStart - seqSpan;
                    DateTime historicalEnd = seqStart;
                    do
                    {
                        historicalStart = historicalStart - seqSpan;
                        historicalEnd = historicalEnd - seqSpan;
                    } while (api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval).Count <= minimumPeriods);
                    List<AxiomObjects.Bar> historicalTradingSymbolBars = api.GetHistoricalBarSync(symbol, '1', historicalStart, historicalEnd, interval);

                    List<AxiomObjects.Bar> twoDaySeq = dataCleaner.BarsListCombiner(tradingBars, historicalTradingSymbolBars);

                    dataCleaner.SmothData_test(twoDaySeq);

                    DateTime nextDayStart = seqStart + seqSpan;
                    DateTime nextDayEnd = nextDayStart + seqSpan;
                    do
                    {
                        nextDayStart = nextDayStart + seqSpan;
                        nextDayEnd = nextDayEnd + seqSpan;
                    } while (api.GetHistoricalBarSync(symbol, '1', nextDayStart, nextDayEnd, interval).Count <= minimumPeriods);
                    List<AxiomObjects.Bar> nextDayBarsList = api.GetHistoricalBarSync(symbol, '1', nextDayStart, nextDayEnd, interval);

                    trader.ModelTrader_NextDayOpenClose(tradingBars, historicalTradingSymbolBars, twoDaySeq, nextDayBarsList, modelStartingMoney, modelDailyPerformance, modelDailySel, modelDailyTradeSignals);
                    trader.AvgDistributeTrader_NextDayOpenClose(tradingBars, historicalTradingSymbolBars, twoDaySeq, nextDayBarsList, avgModelStartingMoney, avgModelDailyPerformance);
                    trader.MutiStrategiesTrader_NextDayOpenClose(tradingBars, historicalTradingSymbolBars, twoDaySeq, nextDayBarsList, strategiesStartingMoney, strategiesDailyPerformance);

                    modelPortfolioTracker.Add(Convert.ToDouble(modelDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time]) + modelStartingMoney);
                    avgModelPortfolioTracker.Add(Convert.ToDouble(avgModelDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time]) + avgModelStartingMoney);
                    for (int straIdx = 0; straIdx < simulator.strategies.Count; straIdx++)
                    {
                        strategiesPortfolioTracker[straIdx].Add(Convert.ToDouble(strategiesDailyPerformance[tradingBars[0].Time.Date][tradingBars[tradingBars.Count - 1].Time][straIdx]) + strategiesStartingMoney[straIdx]);
                    }

                    dayCount++;
                    Console.WriteLine(String.Format("{0} to {1} has been finished", seqStart, seqStart + seqSpan));
                }

                ResultDumper dumper = new ResultDumper();
                dumper.PeriodTotalMoneyDump(symbol, modelPortfolioTracker, avgModelPortfolioTracker, strategiesPortfolioTracker);
                dumper.SharpRatioDump(symbol, modelPortfolioTracker, avgModelPortfolioTracker, strategiesPortfolioTracker);
                dumper.Detail_BuyNSellSignalsDump(symbol, modelDailyTradeSignals, simulator);
                dumper.Binary_BuyNSellSignalsDump(symbol, modelDailyTradeSignals, simulator);
                for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
                {
                    dumper.Simply_OneStrategyBuyNSellSignalsDump(symbol, modelDailyTradeSignals, idxStra);
                    dumper.BuySellTimeSlotPicture(symbol, modelDailyTradeSignals, idxStra, api, start, end, interval);
                }
            }
        }
    }
}
