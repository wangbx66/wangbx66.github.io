﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Diagnostics;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;
using MathNet.Numerics;

namespace StrategySel
{
    public class StockRNN
    {
        // To install numerics package
        // "TOOLS" -> "NuGet Package Manager" -> "Package Manager Console" -> 
        // PM> Install-Package MathNet.Numerics
        // http://numerics.mathdotnet.com/

        public List<double> networkParameters = new List<double>();
        private int position = 0;
        public int numOfParameters;
        public int[] networkArchitecture;
        public List<LSTM> middleLayers = new List<LSTM>();
        public FullyC outputLayer;
        public Vector<double> currentOutput;

        public StockRNN(int[] networkArchitecture, string modelFileName){
            this.networkArchitecture = networkArchitecture;
            System.IO.StreamReader modelFile = new System.IO.StreamReader(System.AppDomain.CurrentDomain.BaseDirectory + modelFileName);
            networkParameters = Regex.Split(modelFile.ReadLine().Trim(), " ").Select(x => double.Parse(x)).ToList();

            int sizeOutput;
            int sizeInput;
            for (int idxLayer = 0; idxLayer < networkArchitecture.Count() - 2; idxLayer++)
            {
                sizeInput = networkArchitecture[idxLayer];
                sizeOutput = networkArchitecture[idxLayer + 1];
                Matrix<double> W_xi = getMatrix(sizeOutput, sizeInput);
                Matrix<double> W_hi = getMatrix(sizeOutput, sizeOutput);
                Vector<double> W_ci = getVector(sizeOutput);
                Vector<double> b_i = getVector(sizeOutput);
                Matrix<double> W_xf = getMatrix(sizeOutput, sizeInput);
                Matrix<double> W_hf = getMatrix(sizeOutput, sizeOutput);
                Vector<double> W_cf = getVector(sizeOutput);
                Vector<double> b_f = getVector(sizeOutput);
                Matrix<double> W_xo = getMatrix(sizeOutput, sizeInput);
                Matrix<double> W_ho = getMatrix(sizeOutput, sizeOutput);
                Vector<double> W_co = getVector(sizeOutput);
                Vector<double> b_o = getVector(sizeOutput);
                Matrix<double> W_xc = getMatrix(sizeOutput, sizeInput);
                Matrix<double> W_hc = getMatrix(sizeOutput, sizeOutput);
                Vector<double> b_c = getVector(sizeOutput);
                Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>> Ti = new Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>(W_xi, W_hi, W_ci, b_i);
                Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>> Tf = new Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>(W_xf, W_hf, W_cf, b_f);
                Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>> To = new Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>(W_xo, W_ho, W_co, b_o);
                Tuple<Matrix<double>, Matrix<double>, Vector<double>> Tc = new Tuple<Matrix<double>, Matrix<double>, Vector<double>>(W_xc, W_hc, b_c);
                Tuple<
                Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>,
                Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>,
                Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>,
                Tuple<Matrix<double>, Matrix<double>, Vector<double>>
                > T = new
                Tuple<
                Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>,
                Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>,
                Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>,
                Tuple<Matrix<double>, Matrix<double>, Vector<double>>
                >(Ti, Tf, To, Tc);

                middleLayers.Add(new LSTM(T));
            }
            sizeOutput = networkArchitecture[networkArchitecture.Length - 1];
            sizeInput = networkArchitecture[networkArchitecture.Length - 2];
            Matrix<double> W = getMatrix(sizeOutput, sizeInput);
            Vector<double> b = getVector(sizeOutput);
            outputLayer = new FullyC(new Tuple<Matrix<double>, Vector<double>>(W, b));

            
        }

        public Vector<double> StepFProp(Vector<double> input)
        {
            currentOutput = input;
            foreach (LSTM layer in middleLayers){
                currentOutput = layer.StepFProp(currentOutput);
            }
            // Here we manually add a softmax fully-connect layer.
            currentOutput = outputLayer.StepFProp(currentOutput);
            return currentOutput;
        }

        public void Reset(){
            foreach (LSTM layer in middleLayers)
            {
                layer.h = Vector<double>.Build.Dense(layer.h_length);
                layer.c = Vector<double>.Build.Dense(layer.h_length);
            }
        }

        private Matrix<double> getMatrix(int numOfRow, int numOfCol)
        {
            double[,] W = new double[numOfRow, numOfCol];
            for (int idxElement = 0; idxElement < numOfRow * numOfCol; idxElement++)
            {
                W[idxElement / numOfCol, idxElement % numOfCol] = networkParameters[position + idxElement];
            }
            position += numOfRow * numOfCol;
            Console.WriteLine(position);
            return Matrix<double>.Build.DenseOfArray(W);
        }

        private Vector<double> getVector(int length)
        {
            double[] b = new double[length];
            for (int idxElement = 0; idxElement < length; idxElement++)
            {
                b[idxElement] = networkParameters[position + idxElement];
            }
            position += length;
            Console.WriteLine(position);
            return Vector<double>.Build.DenseOfArray(b);
        }

        

    }

    public class LSTM
    {
        public Matrix<double> W_xi;
        public Matrix<double> W_hi;
        public Vector<double> W_ci;
        public Vector<double> b_i;
        public Vector<double> i;

        public Matrix<double> W_xf;
        public Matrix<double> W_hf;
        public Vector<double> W_cf;
        public Vector<double> b_f;
        public Vector<double> f;

        public Matrix<double> W_xo;
        public Matrix<double> W_ho;
        public Vector<double> W_co;
        public Vector<double> b_o;
        public Vector<double> o;

        public Matrix<double> W_xc;
        public Matrix<double> W_hc;
        public Vector<double> b_c;
        public Vector<double> c;

        public Vector<double> h;

        public int x_length;
        public int h_length;

        public LSTM(
            Tuple<
            Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>,
            Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>,
            Tuple<Matrix<double>, Matrix<double>, Vector<double>, Vector<double>>, 
            Tuple<Matrix<double>, Matrix<double>, Vector<double>>
            > LSTMParameters)
        {
            W_xi = LSTMParameters.Item1.Item1;
            W_hi = LSTMParameters.Item1.Item2;
            W_ci = LSTMParameters.Item1.Item3;
            b_i = LSTMParameters.Item1.Item4;

            W_xf = LSTMParameters.Item2.Item1;
            W_hf = LSTMParameters.Item2.Item2;
            W_cf = LSTMParameters.Item2.Item3;
            b_f = LSTMParameters.Item2.Item4;

            W_xo = LSTMParameters.Item3.Item1;
            W_ho = LSTMParameters.Item3.Item2;
            W_co = LSTMParameters.Item3.Item3;
            b_o = LSTMParameters.Item3.Item4;

            W_xc = LSTMParameters.Item4.Item1;
            W_hc = LSTMParameters.Item4.Item2;
            b_c = LSTMParameters.Item4.Item3;

            h_length = W_xc.RowCount;
            x_length = W_xc.ColumnCount;

            h = Vector<double>.Build.Dense(h_length); //this build returns zero-vector
            c = Vector<double>.Build.Dense(h_length);
        }

        public Vector<double> StepFProp(Vector<double> x)
        {
            i = Logistic(W_xi * x + W_hi * h + W_ci * c + b_i);
            f = Logistic(W_xf * x + W_hf * h + W_cf * c + b_f);
            o = Logistic(W_xo * x + W_ho * h + W_co * c + b_o);
            c = f.PointwiseMultiply(c) + i.PointwiseMultiply(Tanh(W_xc * x + W_hc * h + b_c));
            h = o.PointwiseMultiply(Tanh(c));
            double[] test = h.ToArray<double>();
            double test0 = test[0];
            Debug.Assert(!Double.IsNaN(test0));
            
            return h;
        }

        public static Vector<double> Logistic(Vector<double> x)
        {
            x = clip(x);
            return 1 / (1 + (-x).PointwiseExp());
        }

        public static Vector<double> Tanh(Vector<double> x)
        {
            x = clip(x);
            Vector<double> ep = x.PointwiseExp();
            Vector<double> en = (-x).PointwiseExp();
            return (ep - en).PointwiseDivide(ep + en);
        }

        public static Vector<double> clip(Vector<double> x)
        {
            double[] s = x.ToArray<double>();
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] > 0){
                    s[i] = Math.Min(s[i], 7);
                }
                else if (s[i] < 0)
                {
                    s[i] = Math.Max(s[i], -7);
                }
            }
            return Vector<double>.Build.DenseOfArray(s);
        }

    }

    public class FullyC
    {
        public Matrix<double> W;
        public Vector<double> b;

        public FullyC(Tuple<Matrix<double>, Vector<double>> FullyCParameters)
        {
            W = FullyCParameters.Item1;
            b = FullyCParameters.Item2;
        }

        public Vector<double> StepFProp(Vector<double> x){
            Vector<double> net = W * x + b;
            return Softmax(net);
        }

        public static Vector<double> Softmax(Vector<double> x)
        {
            return x.PointwiseExp() / x.PointwiseExp().Sum();
        }
    }
}
