﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

using CommonObjects;
using GTADatabase;

using ModulusFE.TASDK;

namespace StrategySel
{
    public class Dumper
    {
        public Simulator simulator;
        public List<string> exec;
        public TimeSpan seqSpan;
        public Periodicity period;
        
        public string name;
        public int TotalSequences = -1;
        public double CommissionFeeNTax = -1;
        public DateTime Start = new DateTime(2012, 2, 1, 8, 0, 0);
        public DateTime End = new DateTime(2012, 12, 31, 8, 0, 0);
        public string CurrentMarket = null;
        public PeriodicDBLoader.OnPercentChangeCall onPercentChangeCall = PeriodicDBLoader.pass;

        void loadIni()
        {
            string iniFile = System.AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            CurrentMarket = GTADatabaseStock.SHANGHAI_STOCK_EXCHANGE;
            if (CurrentMarket == null)
            {
                CurrentMarket = GTADatabaseStock.SHANGHAI_STOCK_EXCHANGE;
                //CurrentMarket = INIOperationClass.INIGetStringValue(iniFile, name, "Market", GTADatabaseStock.SHANGHAI_STOCK_EXCHANGE);
            }
            if (CommissionFeeNTax < 0)
            {
                CommissionFeeNTax = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "CommissionFeeNTax", "0.0021"));
            }
            if (TotalSequences < 0)
            {
                TotalSequences = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "TotalSequences", "600"));
            }
        }

        public void TrainingDatasetDump(string style="cntk")
        {
            Dictionary<string, List<double>> globalStatistics = new Dictionary<string, List<double>>();
            StreamWriter networkOutputFileRaw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}-raw.pdat", style));
            StreamWriter statisticOutputFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + name + @"-data-statistic.txt");

            loadIni();
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            double minimumPriceGap = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "MinimumGap", "0.15"));
            double minimumVolume = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "MinimumVolume", "2e6"));

            int precision = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "Precision", "7"));
            double decay = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "Decay", "0.95"));
            int windowLength = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "WindowLength", "45"));
            int explorationLength = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "20"));

            simulator.executors.Add(Simulator.Larry_AlterPos(CommissionFeeNTax, decay, windowLength, explorationLength, trailLength));
            //simulator.executors.Add(Simulator.AlterPos(CommissionFeeNTax, decay, windowLength, explorationLength, trailLength));
            //simulator.executors.Add(Simulator.AlterChn(CommissionFeeNTax, decay, windowLength, explorationLength, trailLength));
            //simulator.executors.Add(Simulator.NoLimit(CommissionFeeNTax, decay, windowLength, explorationLength, trailLength));

            // Time: both ends inclusive

            List<string> symbols = new List<string>();
            List<string> markets = new List<string>();
            System.IO.StreamReader symbolFile = new System.IO.StreamReader(System.AppDomain.CurrentDomain.BaseDirectory + "symbols");
            string line;
            while ((line = symbolFile.ReadLine()) != null)
            {
                // line is like "symbol-market name\s" (w/ 1 space)
                line = line.Trim();
                string tmp = Regex.Split(line, " ")[0];
                string symbol = Regex.Split(tmp, "-")[0];
                string market = Regex.Split(tmp, "-")[1];
                if (market == CurrentMarket || "ANY" == CurrentMarket)
                {
                    symbols.Add(symbol);
                    markets.Add(market);
                }
            }
            symbolFile.Close();

            // write iterble "RealtimeLoader"
            PeriodicDBLoader dataLoader = new PeriodicDBLoader(Start, End, symbols, markets, period, seqSpan, onPercentChangeCall);
            int idxSeq = 0;
            foreach (List<CommonObjects.Bar> bars in dataLoader)
            {
                String outputString = PeriodicUtils.DumpOutputString(bars, precision, minimumVolume, minimumPriceGap, PeriodicUtils.PreprocessBar5, new List<double>());

                if (outputString == "")
                {
                    continue;
                }
                if (style == "spa")
                {
                    networkOutputFileRaw.WriteLine(outputString);
                }
                if (style == "cntk" | style == "cntk-incre")
                {
                    networkOutputFileRaw.Write(idxSeq);
                }
                Navigator DatabaseNavigator = PeriodicUtils.GetDatabaseNavigator(bars);
                //simulator.LogAttributes(DatabaseNavigator); // If the simulator get some buggy outputs, try logging the details here
                List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
                //List<List<double>> slidingWindowProfits = simulator.TrackPortfolioAlt(DatabaseNavigator, tradeSignals, globalStatistics, CommissionFeeNTax, decay, windowLength, explorationLength, trailLength);
                List<List<List<double>>> slidingWindowProfitsList = new List<List<List<double>>>();
                foreach (Simulator.Tracker executor in simulator.executors)
                {
                    slidingWindowProfitsList.Add(executor(DatabaseNavigator, tradeSignals, globalStatistics));
                }
                StrategyEvaluator.CorrelationAnalyse(tradeSignals, globalStatistics);

                foreach (List<List<double>> slidingWindowProfits in slidingWindowProfitsList)
                {
                    List<string> slicingOutput = outputString.Split(' ').ToList<string>();
                    int numberOfFeatures = slicingOutput.Count / slidingWindowProfits.Count;
                    foreach (List<double> profits in slidingWindowProfits)
                    {
                        double bestProfit = profits.Max();
                        for (int i = 0; i < profits.Count; i++)
                        {
                            profits[i] = Math.Round(bestProfit - profits[i], precision);//realloss
                        }
                        if (style == "spa")
                        {
                            networkOutputFileRaw.WriteLine(String.Join(" ", profits));
                        }
                        else if (style == "cntk")
                        {
                            List<string> currentOutput = slicingOutput.Take(numberOfFeatures).ToList<string>();
                            string X = String.Join(" ", currentOutput);
                            slicingOutput = slicingOutput.Skip(numberOfFeatures).ToList<string>();
                            string Y = String.Join(" ", profits);
                            networkOutputFileRaw.WriteLine(String.Format(" |X {0} |Y {1}", X, Y));
                        }
                        else if (style == "cntk-incre")
                        {
                            List<string> currentOutput = slicingOutput.Take(slicingOutput.Count / slidingWindowProfits.Count).ToList<string>();
                            string X = String.Join(" ", currentOutput);
                            slicingOutput = slicingOutput.Skip(slicingOutput.Count / slidingWindowProfits.Count).ToList<string>();
                            string Y = String.Join(" ", profits);
                            networkOutputFileRaw.WriteLine(String.Format(" |X {0} |Y {1}", X, Y));
                        }
                    }
                }

                idxSeq++;
                //Console.WriteLine("Processed {0} sequences", idxSeq);

                if (idxSeq == TotalSequences)
                {
                    break;
                }
            }
            Console.WriteLine("Total {0} Sequences", idxSeq);

            statisticOutputFile.WriteLine("marketReturn = {0}", globalStatistics["totalMarketReturn"][0] / idxSeq);
            statisticOutputFile.WriteLine("PerfectPlay = {0}", globalStatistics["totalPerfectPlayReturn"][0] / idxSeq);
            for (int idxStra = 0; idxStra < globalStatistics["totalTrades"].Count; idxStra++)
            {
                statisticOutputFile.WriteLine("Strategy {0}", idxStra);
                statisticOutputFile.WriteLine("averageTrades = {0}", globalStatistics["totalTrades"][idxStra] / idxSeq);
                statisticOutputFile.WriteLine("averageStrategyReturn = {0}", globalStatistics["totalStrategyReturn"][idxStra] / idxSeq);
            }
            for (int idxStra1 = 0; idxStra1 < simulator.strategies.Count; idxStra1++)
            {
                statisticOutputFile.WriteLine("strategy {0} correlation", idxStra1);
                for (int idxStra2 = 0; idxStra2 < simulator.strategies.Count; idxStra2++)
                {
                    globalStatistics[String.Format("correlation {0}", idxStra1)][idxStra2] = Math.Abs(globalStatistics[String.Format("correlation {0}", idxStra1)][idxStra2]) / Convert.ToDouble(idxSeq);
                    statisticOutputFile.WriteLine("correlation w/ {0} = {1}", idxStra2, globalStatistics[String.Format("correlation {0}", idxStra1)][idxStra2]);
                }
                globalStatistics[String.Format("correlation {0}", idxStra1)].RemoveAt(idxStra1);
                statisticOutputFile.WriteLine("strategy {0} correlation total {1}", idxStra1, globalStatistics[String.Format("correlation {0}", idxStra1)].Average());
            }

            networkOutputFileRaw.Close();
            statisticOutputFile.Close();

            return;
        }

        public static Tuple<double, double> MeanStd(List<double> valueList)
        {
            double M = 0.0;
            double S = 0.0;
            int k = 1;
            foreach (double value in valueList)
            {
                double tmpM = M;
                M += (value - tmpM) / k;
                S += (value - tmpM) * (value - M);
                k++;
            }
            return Tuple.Create<double, double>(M, Math.Sqrt(S / (k - 2)));
        }

        public void TrainingDatasetNormalize(string style="cntk", int sampleCap=30000)
        {
            Console.WriteLine("Normalizing dataset for {0}", style);
            StreamReader networkOutputFileRaw = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}-raw.pdat", style));

            int NFeatures = 0;
            int NStrategies = 0;
            string line;
            bool once = true;
            int cnt = 0;
            List<List<double>> features = new List<List<double>>();
            List<List<double>> strategies = new List<List<double>>();
            string[] c;
            //while ((line = networkOutputFileRaw.ReadLine()) != null && cnt < sampleCap)
            while ((line = networkOutputFileRaw.ReadLine()) != null)
            {
                if (line.Trim() == "")
                {
                    continue;
                }
                cnt++;
                if (once)
                {
                    c = line.Split('|');
                    foreach (string s in c)
                    {
                        string z = s.Trim();
                        string[] p = z.Split(' ');
                        if (z.StartsWith("X")) {
                            NFeatures = p.Length - 1;//identifier X itself
                        }
                        else if (z.StartsWith("Y")) {
                            NStrategies = p.Length - 1;//identifier Y itself
                        }
                    }
                    once = false;
                }

                c = line.Split('|');
                string[] x = c[1].Trim().Split(' ');
                string[] y = c[2].Trim().Split(' ');

                for (int i = 1; i < x.Length; i++)
                {
                    if (i > features.Count)
                    {
                        features.Add(new List<double>());
                    }
                    features[i - 1].Add(Convert.ToDouble(x[i]));
                }

                for (int i = 1; i < y.Length; i++)
                { 
                    //if (i >= strategies.Count)
                    if (i > strategies.Count)
                    {
                        strategies.Add(new List<double>());
                    }
                    strategies[i - 1].Add(Convert.ToDouble(y[i]));
                } 
                
            }

            StreamWriter meanStdFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "MeanStd.txt");
            List<double> meanx = new List<double>(new double[features.Count]);
            List<double> stdx = new List<double>(new double[features.Count]);
            List<double> meany = new List<double>(new double[strategies.Count]);
            List<double> stdy = new List<double>(new double[strategies.Count]);
            for (int i=0; i < features.Count; i++)
            {
                Tuple<double, double> t = MeanStd(features[i]);
                meanx[i] = t.Item1;
                stdx[i] = t.Item2;
            }
            for (int i = 0; i < strategies.Count; i++)
            {
                Tuple<double, double> t = MeanStd(strategies[i]);
                meany[i] = t.Item1;
                stdy[i] = t.Item2;
            }
            meanStdFile.WriteLine(String.Join(" ", meanx));
            meanStdFile.WriteLine(String.Join(" ", stdx));
            meanStdFile.Close();

            double[] xprime = new double[features.Count];
            double[] yprime = new double[strategies.Count];
            string lineprime;
            networkOutputFileRaw = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}-raw.pdat", style));
            StreamWriter networkOutputFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}.pdat", style));
            int my_flag = 0;
            while ((line = networkOutputFileRaw.ReadLine()) != null)
            {
                my_flag++;
                if (line.Trim() == "")
                {
                    continue;
                }
                c = line.Split('|');
                string[] x = c[1].Trim().Split(' ');
                string[] y = c[2].Trim().Split(' ');

                for (int i = 1; i < x.Length; i++)
                {
                    xprime[i - 1] = (Convert.ToDouble(x[i]) - meanx[i - 1]) / stdx[i - 1];
                    //yprime[i - 1] = (Convert.ToDouble(y[i]) - meany[i - 1]) / stdy[i - 1];
                }

                for (int i = 1; i < y.Length; i++)
                {
                    yprime[i - 1] = (Convert.ToDouble(y[i]) - meany[i - 1]) / stdy[i - 1];
                }

                lineprime = c[0] + "|X " + String.Join<double>(" ", xprime) + " |" + c[2];
                networkOutputFile.WriteLine(lineprime);
            }

            networkOutputFile.Close();
        }

        public void structurer(string style = "cntk")
        {
            Console.WriteLine("Restructuring the dataset, please wait ...");
            StreamReader dataset = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}.pdat", style));
            StreamWriter networkOutputFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}-larry.pdat", style));

            string output;
            string[] lines = File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}.pdat", style));
            for (int i = 0; i < lines.Length; i++)
            {
                if (!lines[i].StartsWith(" |X"))
                {
                    string[] c0 = lines[i].Split('|');
                    int[] zero = new int[20];
                    output = c0[0] + "|" + c0[1].Trim() + " " + String.Join<int>(" ", zero) + " |" + c0[2].Trim();
                }
                else if (i >= 1 && !lines[i - 1].StartsWith(" |X"))
                {
                    string[] c0 = lines[i - 1].Split('|');
                    string[] c1 = lines[i].Split('|');
                    string[] x1 = c1[1].Split(' ');
                    int[] zero = new int[15];
                    double[] x1prime = new double[5];

                    for (int k = 0; k < 5; k++)
                    {
                        x1prime[k] = Convert.ToDouble(x1[k + 1]);
                    }

                    output = " |" + c0[1].Trim() + " " + String.Join<Double>(" ", x1prime) + " " + String.Join<int>(" ", zero) + " |" + c1[2].Trim();
                }
                else if ( i >= 2 && !lines[i - 2].StartsWith(" |X"))
                {
                    string[] c0 = lines[i - 2].Split('|');
                    string[] c1 = lines[i - 1].Split('|');
                    string[] c2 = lines[i].Split('|');
                    string[] x1 = c1[1].Split(' ');
                    string[] x2 = c2[1].Split(' ');
                    int[] zero = new int[10];
                    double[] x1prime = new double[5];
                    double[] x2prime = new double[5];

                    for (int k = 0; k < 5; k++)
                    {
                        x1prime[k] = Convert.ToDouble(x1[k + 1]);
                        x2prime[k] = Convert.ToDouble(x2[k + 1]);
                    }

                    output = " |" + c0[1].Trim() + " " + String.Join<Double>(" ", x1prime) + " " + String.Join<Double>(" ", x2prime) + " " + String.Join<int>(" ", zero) + " |" + c2[2].Trim();
                }
                else if (i >= 3 && !lines[i - 3].StartsWith(" |X"))
                {
                    string[] c0 = lines[i - 3].Split('|');
                    string[] c1 = lines[i - 2].Split('|');
                    string[] c2 = lines[i - 1].Split('|');
                    string[] c3 = lines[i].Split('|');
                    string[] x1 = c1[1].Split(' ');
                    string[] x2 = c2[1].Split(' ');
                    string[] x3 = c3[1].Split(' ');
                    int[] zero = new int[5];
                    double[] x1prime = new double[5];
                    double[] x2prime = new double[5];
                    double[] x3prime = new double[5];

                    for (int k = 0; k < 5; k++)
                    {
                        x1prime[k] = Convert.ToDouble(x1[k + 1]);
                        x2prime[k] = Convert.ToDouble(x2[k + 1]);
                        x3prime[k] = Convert.ToDouble(x3[k + 1]);
                    }

                    output = " |" + c0[1].Trim() + " " + String.Join<Double>(" ", x1prime) + " " + String.Join<Double>(" ", x2prime) + " " + String.Join<Double>(" ", x3prime) + " " + String.Join<int>(" ", zero) + " |" + c3[2].Trim();
                }
                else
                {
                    string[] c0 = lines[i - 4].Split('|');
                    string[] c1 = lines[i - 3].Split('|');
                    string[] c2 = lines[i - 2].Split('|');
                    string[] c3 = lines[i - 1].Split('|');
                    string[] c4 = lines[i].Split('|');
                    string[] x1 = c1[1].Split(' ');
                    string[] x2 = c2[1].Split(' ');
                    string[] x3 = c3[1].Split(' ');
                    string[] x4 = c4[1].Split(' ');
                    double[] x1prime = new double[5];
                    double[] x2prime = new double[5];
                    double[] x3prime = new double[5];
                    double[] x4prime = new double[5];

                    for (int k = 0; k < 5; k++)
                    {
                        x1prime[k] = Convert.ToDouble(x1[k + 1]);
                        x2prime[k] = Convert.ToDouble(x2[k + 1]);
                        x3prime[k] = Convert.ToDouble(x3[k + 1]);
                        x4prime[k] = Convert.ToDouble(x4[k + 1]);
                    }

                    output = " |" + c0[1].Trim() + " " + String.Join<Double>(" ", x1prime) + " " + String.Join<Double>(" ", x2prime) + " " + String.Join<Double>(" ", x3prime) + " " + String.Join<Double>(" ", x4prime) + " |" + c4[2].Trim();
                }
                networkOutputFile.WriteLine(output);
            }
            networkOutputFile.Close();
        }

    }
}