﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

using CommonObjects;

using ModulusFE.TASDK;
using ModulusFE;

namespace StrategySel
{
    public class PeriodicUtils
    {

        // Period utils are mainly used for periodic e.g. minute-interval and day-interval, trading. It handles objects "Bar" exist in CommonObjects w/o order book information.

        /*
         * DumpOutputString: Get a string in human-understandable vector representation of the input list of bars
         * GetDatabaseNavigator: Convert list of bars into a TASDK compatible object
         * PreprocessBar: Embed a bar into vector space
        */

        public delegate List<double> BarPreProcessor(double Open, double High, double Low, double Close, double Volume, double previousClose, int precision);

        public static String DumpOutputString(List<CommonObjects.Bar> bars, int precision, double minimumVolume, double minimumPriceGap, BarPreProcessor barPreprocessor, List<double> additionalInfo)
        {
            // Will return empty string if this being a bad bar
            StringBuilder outputString = new StringBuilder("");
            List<double> volumes = new List<double>(new double[bars.Count]);
            List<double> closes = new List<double>(new double[bars.Count]);
            
            double previousClose = 0;
            foreach (CommonObjects.Bar bar in bars)
            {
                volumes.Add(bar.Volume);
                closes.Add(bar.Close);
                if (previousClose == 0)
                {
                    previousClose = bar.Close;
                }
                List <double> barInfo = barPreprocessor(bar.Open, bar.High, bar.Low, bar.Close, bar.Volume, previousClose, precision);

                outputString.Append(String.Join<double>(" ", barInfo) + " ");
                if (additionalInfo.Count > 0)
                {
                    outputString.Append(String.Join<double>(" ", additionalInfo) + " ");
                }
                previousClose = bar.Close;
            }

            // We should filter out inactive stocks. It's now judged by thresholding the total volume and the largest price gap. This filter is specified for minute-interval trading w/ classic bars
            if (volumes.Sum() < minimumVolume || Math.Abs(closes.Max() - closes.Min()) < minimumPriceGap)
            {
                outputString = new StringBuilder("");
            }
            if (!(outputString.ToString() == ""))
            {
                outputString.Remove(outputString.Length - 1, 1);
                //outputString.Remove(outputString.Length - 1);
            }
            return outputString.ToString();
        }

        public static Navigator GetDatabaseNavigator(List<CommonObjects.Bar> bars)
        {
            Navigator DBNavigator;
            Recordset DBRecordSet = new Recordset();
            
            Field Open = new Field(bars.Count, "Open");
            Field High = new Field(bars.Count, "High");
            Field Low = new Field(bars.Count, "Low");
            Field Close = new Field(bars.Count, "Close");
            Field Volume = new Field(bars.Count, "Volume");
            // The field DateTime is only to feed ZScript 
            Field DateTime = new Field(bars.Count, "DateTime");

            // When using minute-inerval data, we have 240 bars/day (Originally 241 bars/day from GTADatabaseStock, but the 240-th bar was always with a zero volume and was hence removed by PeriodicDBLoader). The first bar usually starts at 9:30am. High and Low etc. of each bar is the high or low within the minute and are usually very close to the close price.
            // For volume information which scales unbounded, to normalize it to mostly in (-1,1) region, I take the logarithmic value of it here. When there's no volume, other dimensions should be forced to be zeros, if not already zeros (see PreprocessBar).
            int idxBar = 0;
            foreach (CommonObjects.Bar bar in bars)
            {
                // IMPORTANT: For fields construction, index should be from 1.
                idxBar++;

                Open.Value(idxBar, bar.Open);
                High.Value(idxBar, bar.High);
                Low.Value(idxBar, bar.Low);
                Close.Value(idxBar, bar.Close);
                Volume.Value(idxBar, bar.Volume);
                DateTime.Value(idxBar, bar.Date.Ticks);
            }
            
            DBRecordSet.AddField(Open);
            DBRecordSet.AddField(High);
            DBRecordSet.AddField(Low);
            DBRecordSet.AddField(Close);
            DBRecordSet.AddField(Volume);
            DBRecordSet.AddField(DateTime);
            
            DBNavigator = new Navigator();
            DBNavigator.Recordset_ = DBRecordSet;
            return DBNavigator;
        }

        public static double RelativePrice(double number, double standard, int precision)
        {
            return Math.Round((number - standard) / standard, precision);
        }

        // The function PreprocessBar are used both when the training dataset is being dumped and when testing data is fed into the prediction model. The back-end system should use exact output of outputString.

        public static BarPreProcessor PreprocessBar = delegate(double open, double high, double low, double close, double volume, double previousClose, int precision)
        {
            List<double> networkInput = new List<double>(new double[3]);

            if (!(close > 0) || !(previousClose > 0))
            {
                return networkInput;
            }

            if (volume == 0)
            {
                if (!(close == previousClose) || !(close == high) || !(close == open) || !(close == low))
                {
                    return networkInput;
                }
            }

            networkInput[0] = Math.Round((high - low) / close, precision) * 250;
            networkInput[1] = RelativePrice(close, previousClose, precision) * 750;
            networkInput[2] = (Math.Log(volume + 1)) / 3.5;
            return networkInput;
        };

        public static BarPreProcessor PreprocessBar5 = delegate (double open, double high, double low, double close, double volume, double previousClose, int precision)
        {
            List<double> networkInput = new List<double>(new double[5]);

            if (!(close > 0) || !(previousClose > 0))
            {
                return networkInput;
            }

            networkInput[0] = Math.Round((high - close) / close, precision) * 250;
            networkInput[1] = Math.Round((close - low) / close, precision) * 250;
            networkInput[2] = Math.Round((close - open) / close, precision) * 250;
            networkInput[3] = RelativePrice(close, previousClose, precision) * 750;
            networkInput[4] = (Math.Log(volume + 1)) / 3.5;
            return networkInput;
        };
    }
}
