﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

using GTADatabase;
using CommonObjects;

namespace StrategySel
{
    public class TickDBLoader : IEnumerator, IEnumerable
    {
        private List<Tuple<string, DateTime, DateTime>> queries = new List<Tuple<string, DateTime, DateTime>>();
        private TickDatabaseStock tickDatabase;
        private object currentBars;
        int position = -1;
        string market;
        Periodicity wavelet = Periodicity.Minutely;

        public TickDBLoader(string market, DateTime start, DateTime end, List<string> symbols, Periodicity wavelet, TimeSpan seqSpan)
        {
            this.market = market;
            this.wavelet = wavelet;
            List<Tuple<DateTime, DateTime>> dates = new List<Tuple<DateTime, DateTime>>();
            for (DateTime dt = start; dt <= end; dt = dt.Add(seqSpan))
            {
                dates.Add(new Tuple<DateTime, DateTime>(dt, dt.AddHours(8)));
            }
            foreach (Tuple<DateTime, DateTime> datePair in dates)
            {
                DateTime prevDate = datePair.Item1;
                DateTime lastDate = datePair.Item2;
                foreach (string symbol in symbols)
                {
                    queries.Add(new Tuple<string, DateTime, DateTime>(symbol, prevDate, lastDate));
                }
            }
            string user = "sa";
            string psk = "ts-test12345";
            string server = "10.6.72.18";
            this.tickDatabase = new TickDatabaseStock(user, psk, server);
        }

        public IEnumerator GetEnumerator()
        {
            return (IEnumerator)this;
        }

        //Super(IEnumerator)
        public bool MoveNext()
        {
            position++;
            currentBars = getCurrentBars();
            return (position < queries.Count);
        }

        //Super(IEnumerable)
        public void Reset()
        {
            position = 0;
        }

        //Super(IEnumerable)
        public object Current
        {
            get { return currentBars; }
        }

        private object getCurrentBars()
        {
            //Console.WriteLine("loading");
            List<Tick> ticks = this.tickDatabase.getTick(this.queries[position].Item1, this.market, this.queries[position].Item2, this.queries[position].Item3);
            while (ticks.Count == 0 && position < queries.Count)
            {
                //Console.WriteLine("empty bar");
                ticks = this.tickDatabase.getTick(this.queries[position].Item1, this.market, this.queries[position].Item2, this.queries[position].Item3);
                position++;
            }
            return ticks;
        }
    }   
}
