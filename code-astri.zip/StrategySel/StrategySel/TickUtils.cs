﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Diagnostics;

//using MathNet.Numerics;
//using MathNet.Numerics.LinearRegression;

//using CommonObjects;
//using Newtonsoft.Json;


//namespace StrategySel
//{
//    public class TickUtils
//    {
//        public static double Grain = 0.01;
//        public static double Threshold = 10 * Grain;
//        public static double Cap = 3.5;

//        public static List<StrategySel.Bar> TickToPeriodic(List<Tick> ticks, TimeSpan period){
//            List<Bar> bars = new List<Bar>();
            
//            TimeSpan halfPeriod = TimeSpan.FromTicks(period.Ticks / 2);
//            // this bar should never be accessed, it is expected be overwritten.

//            StrategySel.Bar bar = new StrategySel.Bar();
//            DateTime currentTime = ticks[0].Date;
//            DateTime middle = currentTime.Add(halfPeriod);
//            DateTime cutOff = currentTime.Add(period);
//            List<double> prices = new List<double>();
//            List<double> volumes = new List<double>();
//            List<double> times = new List<double>();
//            List<double> straddles = new List<double>();
//            List<double> shallowBiases = new List<double>();
//            List<double> deepBiases = new List<double>();
            
//            foreach (Tick tick in ticks)
//            {
//                if (tick.Price == 0 || tick.Volume == 0 || tick.Ask1 <= tick.Bid1)
//                {
//                    continue;
//                }
//                if (tick.Date > cutOff)
//                {
//                    if (bar.NumOfTicks > 9)
//                    {
//                        bar.EndOfDuration = cutOff;
//                        Tuple<double, double> tmp = GetVolatility(prices, volumes);
//                        bar.Price = tmp.Item1;
//                        bar.Volatility = tmp.Item2;
//                        bar.Trend = GetTrend(prices, volumes, times);
//                        bar.Volume = volumes.Sum();

//                        bar.Close = prices[prices.Count - 1];
//                        bar.Open = prices[0];
//                        bar.High = prices.Max();
//                        bar.Low = prices.Min();

//                        bar.Liquidity = bar.Price * bar.Volume;
//                        bar.Straddle = straddles.Average();
//                        bar.ShallowBias = shallowBiases.Average();
//                        bar.DeepBias = deepBiases.Average();
//                        bars.Add(bar);
//                    }
//                    bar = new StrategySel.Bar(); 
//                    currentTime = cutOff;
//                    middle = currentTime.Add(halfPeriod);
//                    cutOff = currentTime.Add(period);
//                    prices = new List<double>();
//                    volumes = new List<double>();
//                    times = new List<double>();
//                    straddles = new List<double>();
//                    shallowBiases = new List<double>();
//                    deepBiases = new List<double>();
//                }
//                bar.NumOfTicks++;
//                prices.Add(tick.Price);
//                volumes.Add(tick.Volume);
//                times.Add(Convert.ToDouble(tick.Date.Subtract(currentTime).Ticks));
//                straddles.Add(Math.Round((tick.Ask1 - tick.Bid1 - Grain), 2) / tick.Price);
//                shallowBiases.Add(getShallowBiasTick(tick));
//                deepBiases.Add(getDeepBiasTick(tick));
//            }
            
//            return bars;
//        }

//        public static double GetTrend(List<double> prices, List<double> volumes, List<double> times)
//        {
            
//            if (prices.Count < 4)
//            {
//                return 0;
//            }

//            /*
//            double[][] X = new double[prices.Count][];
//            for (int i = 0; i < prices.Count; i++)
//            {
//                // virtually the same result as time[i]
//                X[i] = new double[1] { i };
//            }
//             * */

//            double[] X = times.ToArray<double>();
//            double[] Y = prices.ToArray<double>();
//            double[] W = volumes.ToArray<double>();

//            //double[] S = WeightedRegression.Weighted<double>(X, Y, W, true);
//            double[] S = Fit.PolynomialWeighted(X, Y, W, 1);
//            return S[1];
//            ;

//        }

//        public static Tuple<double, double> GetVolatility(List<double> prices, List<double> volumes)
//        {
//            if (prices.Count == 0){
//                return Tuple.Create<double, double>(0, 0);
//            }

//            double totalVolume = volumes.Sum();
//            double averagePrice = 0;
//            for (int i = 0; i < prices.Count; i++)
//            {
//                averagePrice += volumes[i] / totalVolume * prices[i];
//            }
//            double variance = 0;
//            for (int i = 0; i < prices.Count; i++)
//            {
//                variance += volumes[i] / totalVolume * Math.Pow(averagePrice - prices[i], 2);
//            }
//            return Tuple.Create<double, double>(averagePrice, variance);
//        }

//        public static double getDeepBiasTick(Tick tick)
//        {
//            double bidTotal = 0;
//            double askTotal = 0;
//            double[] bid = new double[10] { tick.Bid1, tick.Bid2, tick.Bid3, tick.Bid4, tick.Bid5, tick.Bid6, tick.Bid7, tick.Bid8, tick.Bid9, tick.Bid10 };
//            double[] bidSize = new double[10] { tick.BidSize1, tick.BidSize2, tick.BidSize3, tick.BidSize4, tick.BidSize5, tick.BidSize6, tick.BidSize7, tick.BidSize8, tick.BidSize9, tick.BidSize10 };
//            double[] ask = new double[10] { tick.Ask1, tick.Ask2, tick.Ask3, tick.Ask4, tick.Ask5, tick.Ask6, tick.Ask7, tick.Ask8, tick.Ask9, tick.Ask10 };
//            double[] askSize = new double[10] { tick.AskSize1, tick.AskSize2, tick.AskSize3, tick.AskSize4, tick.AskSize5, tick.AskSize6, tick.AskSize7, tick.AskSize8, tick.AskSize9, tick.AskSize10 };
            
//            for (int i = 0; i < 10; i++)
//            {
//                if (bid[i] >= bid[0] - Threshold)
//                {
//                    bidTotal += bidSize[i];
//                }
//                if (ask[i] <= ask[0] + Threshold)
//                {
//                    askTotal += askSize[i];
//                }
//            }
//            double bias = (askTotal - bidTotal) / Math.Min(askTotal, bidTotal);
//            if (Math.Abs(bias) > Cap)
//            {
//                bias = Cap * Math.Sign(bias);
//            }
//            return bias;
//        }

//        public static double getShallowBiasTick(Tick tick)
//        {
//            double bias = (tick.AskSize1 - tick.BidSize1) / Math.Min(tick.AskSize1, tick.BidSize1);
//            if (Math.Abs(bias) > Cap)
//            {
//                bias = Cap * Math.Sign(bias);
//            }
//            return bias;
//        }

//        public static double StandardDeviation(IEnumerable<double> values)
//        {
//            double avg = values.Average();
//            return Math.Sqrt(values.Average(v => Math.Pow(v - avg, 2)));
//        }
//    }

//    public class Bar
//    {
//        public DateTime EndOfDuration { get; set; }
//        public int NumOfTicks { get; set; }

//        public double Price { get; set; }
//        public double Trend { get; set; }
//        public double Volatility { get; set; }
//        public double Volume { get; set; }
//        public double Liquidity { get; set; }

//        public double High { get; set; }
//        public double Close { get; set; }
//        public double Open { get; set; }
//        public double Low { get; set; }


//        public double Straddle { get; set; }
//        public double ShallowBias { get; set; }
//        public double DeepBias { get; set; }

//        public string ToJson()
//        {
//            return JsonConvert.SerializeObject(this, new DatabaseUtility.JsonDateTimeConvertor());
//        }

//        public static Bar FromJson(string json)
//        {
//            return JsonConvert.DeserializeObject<Bar>(json);
//        }
//    }
//}
