﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Diagnostics;

using GTADatabase;
using CommonObjects;

using ModulusFE.TASDK;
using ModulusFE;

using MathNet.Numerics.LinearAlgebra;
using AxiomObjects;
using System.Reflection;

namespace StrategySel
{
    public class Program
    {
        public const string MODE_TRAIN = "_train";
        public const string MODE_TEST = "_test";
        public const string MODE_PREDICT = "_predict";

        public static string startDateStr = System.Configuration.ConfigurationManager.AppSettings["START_DATE"];
        public static string endDateStr = System.Configuration.ConfigurationManager.AppSettings["END_DATE"];

        public static DateTime globalStartDate;
        public static DateTime globalEndDate;

        //public static PeriodicDBLoader.OnPercentChangeCall printPercent = delegate(int percent)
        //{
        //    Console.WriteLine(String.Format("{0} percent completed", percent));
        //};

        public static void printPercent(int percent)
        {
            Console.WriteLine(String.Format("{0} percent completed", percent));
        }

        static void Main(string[] args)
        {
            try
            {
                globalStartDate = DateTime.Parse(startDateStr);
                globalEndDate = DateTime.Parse(endDateStr);

                //DayInterval();
                MinuteInterval();
                //DataAPIMinuteInterval();
            }
            catch (Exception ex)
            {
                Log.debug(MethodBase.GetCurrentMethod() + " Exception: " + ex);
                //throw;
            }
            //MinuteInterval();
            //DayWavelet();
            //TickTest();
            //var x = Test(1);
            //var y = Test(2);
            //Console.WriteLine(x[0]);
            //Console.WriteLine(y[0][0]);
            //Console.Read();
        }

        static dynamic Test(int i)
        {
            if (i == 1)
            {
                var x = new List<int>(new int[5]);
                x[0] = 1;
                return x;
            }
            else
            {
                return new List<List<int>>() { new List<int>(new int[5])};
            }
        }

        /*static void TickTest()
        {
            StreamWriter logger = new System.IO.StreamWriter(@"tick-logging.txt");
            string currentMarket = TickDatabaseStock.SHENZHEN_STOCK_EXCHANGE;
            DateTime start = new DateTime(2014, 11, 3, 8, 0, 0);
            DateTime end = new DateTime(2014, 12, 1, 8, 0, 0);
            TimeSpan seqSpan = TimeSpan.FromDays(1);
            TimeSpan period = TimeSpan.FromMinutes(1);

            List<string> symbols = new List<string>();
            System.IO.StreamReader symbolFile = new System.IO.StreamReader(System.AppDomain.CurrentDomain.BaseDirectory + "symbols");
            string line;
            while ((line = symbolFile.ReadLine()) != null)
            {
                // line is like "symbol-market name" (w/ 1 spaces)
                line = line.Trim();
                string tmp = Regex.Split(line, " ")[0];
                string symbol = Regex.Split(tmp, "-")[0];
                string market = Regex.Split(tmp, "-")[1];
                if (market == currentMarket)
                {
                    symbols.Add(symbol);
                }
            }
            symbolFile.Close();
            TickDBLoader dataLoader = new TickDBLoader(currentMarket, start, end, symbols, Periodicity.Minutely, seqSpan);
            List<double> trend = new List<double>();
            List<double> volatility = new List<double>();
            List<double> volume = new List<double>();
            List<double> straddle = new List<double>();
            List<double> shallowbias = new List<double>();
            List<double> deepbias = new List<double>();

            int idxSeq = 0;
            int totalSequences = 10000;
            foreach (List<CommonObjects.Tick> ticks in dataLoader)
            {
                List<StrategySel.Bar> bars = TickUtils.TickToPeriodic(ticks, period);
                foreach (StrategySel.Bar bar in bars){
                    //logger.WriteLine(bar.ToJson());
                    trend.Add(bar.Trend);
                    volatility.Add(bar.Volatility);
                    volume.Add(bar.Volume);
                    straddle.Add(bar.Straddle);
                    shallowbias.Add(bar.ShallowBias);
                    deepbias.Add(bar.DeepBias);
                }
                //logger.WriteLine("");
                idxSeq++;
                Console.WriteLine("Processing {0} {1} Day-{2}", idxSeq, ticks[0].Symbol.Symbol, ticks[0].Date.DayOfYear);
                if (idxSeq == totalSequences)
                {
                    break;
                }
            }
            logger.WriteLine("Trend {0} {1} {2} {3}", trend.Average(), trend.Max(), trend.Min(), TickUtils.StandardDeviation(trend));
            logger.WriteLine("Volatility {0} {1} {2} {3}", volatility.Average(), volatility.Max(), volatility.Min(), TickUtils.StandardDeviation(volatility));
            logger.WriteLine("Volume {0} {1} {2} {3}", volume.Average(), volume.Max(), volume.Min(), TickUtils.StandardDeviation(volume));
            logger.WriteLine("Straddle {0} {1} {2} {3}", straddle.Average(), straddle.Max(), straddle.Min(), TickUtils.StandardDeviation(straddle));
            logger.WriteLine("Shallowbias {0} {1} {2} {3}", shallowbias.Average(), shallowbias.Max(), shallowbias.Min(), TickUtils.StandardDeviation(shallowbias));
            logger.WriteLine("Deepbias {0} {1} {2} {3}", deepbias.Average(), deepbias.Max(), deepbias.Min(), TickUtils.StandardDeviation(deepbias));

            logger.Close();
            Console.Read();
        }*/

        static void MinuteInterval()
        {
            Simulator simulator = new Simulator();
            simulator.LoadDefault();

            Dumper dumper = new Dumper
            {
                CommissionFeeNTax = 0,
                CurrentMarket = "ANY",
                TotalSequences = 6000,
                name = "minute",
                seqSpan = TimeSpan.FromDays(1),
                period = Periodicity.Minutely,
                simulator = simulator,
                ////Train Data
                //Start = new DateTime(2012, 2, 1, 8, 0, 0),
                //End = new DateTime(2012, 12, 31, 8, 0, 0),

                ////Test Data
                //Start = new DateTime(2013, 2, 1, 8, 0, 0),
                //End = new DateTime(2013, 12, 31, 8, 0, 0),

                Start = globalStartDate,
                End = globalEndDate, 

                onPercentChangeCall = printPercent,
            };
            dumper.TrainingDatasetDump("cntk");
            dumper.TrainingDatasetNormalize("cntk");
            dumper.structurer("cntk");
        }

        static void DayInterval()
        {
            Simulator simulator = new Simulator();
            simulator.LoadDefault();

            Dumper dumper = new Dumper { 
                CommissionFeeNTax = 0, 
                CurrentMarket = "ANY", 
                TotalSequences = 1000, 
                name = "minute",
                seqSpan = TimeSpan.FromDays(365), 
                period = Periodicity.Daily,
                simulator = simulator, 
                //Start = new DateTime(2012, 2, 1, 8, 0, 0), 
                //End = new DateTime(2012, 12, 31, 8, 0, 0), 

                Start = globalStartDate,
                End = globalEndDate, 

                onPercentChangeCall = printPercent,
            };
            dumper.TrainingDatasetDump("cntk");
            dumper.TrainingDatasetNormalize("cntk");
            dumper.structurer("cntk");
        }

        static void DayWavelet()
        {
            Simulator simulator = new Simulator();
            simulator.strategies.Add(BuildinStrategies.MACrossover(1, 3, 1.05, 1.05));
            simulator.strategies.Add(BuildinStrategies.MACrossover(1, 5, 1.05, 1.05));
            simulator.strategies.Add(BuildinStrategies.MACrossover(3, 7, 1.05, 1.05));
            simulator.strategies.Add(BuildinStrategies.MACrossover(3, 9, 1.05, 1.05));
            simulator.strategies.Add(BuildinStrategies.MACrossover(5, 9, 1.05, 1.05));
            simulator.strategies.Add(BuildinStrategies.MACrossover(5, 11, 1.05, 1.05));
            simulator.strategies.Add(BuildinStrategies.MACrossover(7, 13, 1.05, 1.05));
            simulator.strategies.Add(BuildinStrategies.MACrossover(7, 17, 1.05, 1.05));
            simulator.strategies.Add(BuildinStrategies.MACrossover(9, 19, 1.05, 1.05));

            Dumper dumper = new Dumper
            {
                CommissionFeeNTax = 0.0021,
                CurrentMarket = "ANY",
                TotalSequences = 3000,
                name = "wavelet",
                seqSpan = TimeSpan.FromDays(365),
                period = Periodicity.Daily,
                simulator = simulator,
                //Start = new DateTime(2012, 2, 1, 8, 0, 0),
                //End = new DateTime(2012, 12, 31, 8, 0, 0),

                Start = globalStartDate,
                End = globalEndDate, 

                onPercentChangeCall = printPercent,
            };
            dumper.TrainingDatasetDump();
        }

        static void RNNFlowtest()
        {
            Vector<double> a = Vector<double>.Build.Dense(5, i => i);
            double[] x = new double[8] { 1, 2, 3, 4, 5, 6, 7, 8 };
            Matrix<double> m = Matrix<double>.Build.DenseOfColumnMajor(2, 4, x);
            Vector<double> z = Vector<double>.Build.DenseOfArray(x);
            Console.WriteLine(m);
            Vector<double> t1 = Vector<double>.Build.Dense(4, 1);
            Vector<double> t2 = Vector<double>.Build.Dense(4, 2);
            Vector<double> t3 = Vector<double>.Build.Dense(4, 3);
            Vector<double> t4 = Vector<double>.Build.Dense(5, 10000000);
            Console.WriteLine(t1 + t2 * t3);
            Console.WriteLine(FullyC.Softmax(z));
            Console.WriteLine(m);

            int[] networkArchitecture = new int[] { 5, 32, 64, 8 };
            string modelFileName = "model_flatten.pdat";
            StockRNN model = new StockRNN(networkArchitecture, modelFileName);
            Stopwatch stopwatch = Stopwatch.StartNew();
            Vector<double> output1 = model.StepFProp(t4);
            Console.WriteLine(output1);
            Vector<double> output2 = model.StepFProp(t4);
            Console.WriteLine(output2);
            Vector<double> output3 = model.StepFProp(t4);
            Console.WriteLine(output3);
            Vector<double> output4 = model.StepFProp(t4);
            Console.WriteLine(output4);
            stopwatch.Stop();
            Console.WriteLine(stopwatch.ElapsedMilliseconds);
            Console.WriteLine("RNN Flowtest Ends");
        }

    }
}
