﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using CommonObjects;

using ModulusFE.TASDK;
using ModulusFE;

namespace StrategySel
{
    public class DataPuller
    {
        private DateTime start;
        private DateTime end;
        private List<string> symbols;
        private List<string> market;
        private Periodicity wavelet;
        private TimeSpan seqSpan;
        private static StreamWriter localDBFile = new System.IO.StreamWriter(@"localdb.pdat");

        public DataPuller(DateTime start, DateTime end, List<string> symbols, List<string> market, Periodicity wavelet, TimeSpan seqSpan)
        {
            this.market = market;
            this.start = start;
            this.end = end;
            this.symbols = symbols;
            this.wavelet = wavelet;
            this.seqSpan = seqSpan;
        }

        public void Pull(int totalSequences)
        {
            PeriodicDBLoader dataLoader = new PeriodicDBLoader(start, end, symbols, market, wavelet, seqSpan, PeriodicDBLoader.pass);
            int idxSeq = 0;
            foreach (List<CommonObjects.Bar> bars in dataLoader)
            {
                string outputString = "";
                int idxBar = 0;
                List<int> volumes = new List<int>(new int[bars.Count]);
                List<double> closes = new List<double>(new double[bars.Count]);
                foreach (CommonObjects.Bar bar in bars)
                {
                    volumes[idxBar] = Convert.ToInt32(bar.Volume);
                    closes[idxBar] = bar.Close;
                    outputString += String.Format("{0} {1} {2} {3} {4} {5} \n", bar.Open, bar.Close, bar.High, bar.Low, bar.Volume, bar.Date);
                    idxBar++;
                }
                
                localDBFile.WriteLine(outputString);
                idxSeq += 1;
                Console.WriteLine("pulled {0} sequences, length {1}", idxSeq, bars.Count);
                if (idxSeq == totalSequences)
                {
                    break;
                }
            }
        }
    }
}
