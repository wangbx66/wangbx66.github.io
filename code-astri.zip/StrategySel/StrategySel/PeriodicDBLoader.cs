﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

using GTADatabase;
using CommonObjects;

namespace StrategySel
{
    public class Query
    {
        public string Symbol;
        public string Market;
        public DateTime PrevDate;
        public DateTime LastDate;
    }

    public class PeriodicDBLoader : IEnumerator, IEnumerable
    {
        
        /*
         * The constructor returns a enumerator over a specific timespan, looping a list of CommonObjective.Bar each time. It covers the symbols listed in "symbols" (with their corresponding markets), over the time between "start" and "end". Each bar covers a period specified by "wavelet", and each list of bar by "seqspan"
        */

        private List<CommonObjects.Bar> currentBars;
        private int position = -1;
        private int percent = -1;

        private List<Query> queries = new List<Query>();
        private GTADatabaseStock periodicDatabase;
        private Periodicity wavelet;
        private OnPercentChangeCall onPercentChangeCall;

        public delegate void OnPercentChangeCall(int percent);

        public static OnPercentChangeCall pass = delegate(int percent)
        {
            return;
        };
        
        public PeriodicDBLoader(DateTime start, DateTime end, List<string> symbols, List<string> markets, Periodicity wavelet, TimeSpan seqSpan, OnPercentChangeCall onPercentChangeCall)
        {
            this.wavelet = wavelet;
            this.onPercentChangeCall = onPercentChangeCall;

            for (DateTime dt = start; dt < end; dt += seqSpan)
            {
                DateTime prevDate = dt;
                DateTime lastDate = dt + seqSpan;
                for (int i = 0; i < symbols.Count(); i++)
                {
                    queries.Add(new Query { Symbol = symbols[i], Market = markets[i], PrevDate = prevDate, LastDate = lastDate });
                }
            }

            string user = "sa";
            string psw = "ts-test12345";
            string server = "10.6.88.28";
            periodicDatabase = new GTADatabaseStock(user, psw, server);
        }

        public IEnumerator GetEnumerator()
        {
            return (IEnumerator)this;
        }

        //Super(IEnumerator)
        public bool MoveNext()
        {
            currentBars = getCurrentBars();
            return (position < queries.Count);
        }

        //Super(IEnumerable)
        public void Reset()
        {
            position = 0;
        }

        //Super(IEnumerable)
        public object Current
        {
            get { return currentBars; }
        }

        private List<CommonObjects.Bar> getCurrentBars()
        {
            position++;
            if (position * 100 / queries.Count > percent)
            {
                percent = position * 100 / queries.Count;
                onPercentChangeCall(percent);
            }
            if (position == queries.Count)
            {
                return new List<CommonObjects.Bar>();
            }
            List<CommonObjects.Bar> bars = periodicDatabase.getBar(queries[position].Symbol, queries[position].Market, wavelet, 1, queries[position].PrevDate, queries[position].LastDate);
            while (bars.Count == 0 && position < queries.Count)
            {
                position++;
                if (position == queries.Count)
                {
                    return new List<CommonObjects.Bar>();
                }
                //Console.WriteLine("{0} {1} {2} {3}", this.queries[position].Symbol, this.queries[position].Market, this.queries[position].PrevDate, this.queries[position].LastDate);
                bars = periodicDatabase.getBar(queries[position].Symbol, queries[position].Market, wavelet, 1, queries[position].PrevDate, this.queries[position].LastDate);
            }
            // The second to lasr bar always has zero volume in miniute-interval. It'll be autoremoved.
            //if (wavelet == Periodicity.Minutely)
            //{
            //    bars.RemoveAt(bars.Count - 2);
            //}
            if (queries[position].Market == "SZSE")
            {
                bars.Where(_ => { return !(_.Date.Hour == 14 && _.Date.Minute == 59); });
            }
            //Console.WriteLine("{0} {1} {2} {3}", this.queries[position].Symbol, this.queries[position].Market, this.queries[position].PrevDate, this.queries[position].LastDate);
            
            return bars;
        }
    }   
}