﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

using ModulusFE.TASDK;
using ModulusFE;

using Modulus.TradeScript;

namespace StrategySel
{
    public class BuildinStrategies
    {
        public const double StartingPointGeneral = 45;

        public static Simulator.TradeStrategy WiselySleeping()
        {
            Simulator.TradeStrategy Anonymity= delegate(Navigator barsNavigator)
            {
                int[] tradeSignal = new int[barsNavigator.RecordCount];
                return tradeSignal;
            };
            return Anonymity;
        }
        

        public static Simulator.TradeStrategy MovingMomentum(int MAShortPeriods, int MALongPeriods, int STOKPeriods, int STOKSlowingPeriods, int STODPeriods, IndicatorType STOMAType, int MACDSignalPeriods, int MACDLongCycle, int MACDShortCycle)
        {
            MovingAverage ma = new MovingAverage();
            Oscillator oscillator = new Oscillator();

            Simulator.TradeStrategy Anonymity = delegate(Navigator barsNavigator)
            {
                //var time = DateTime.Now;
                int[] tradeSignal = new int[barsNavigator.RecordCount];
                Recordset barsRecordset = barsNavigator.Recordset_;
                Field Close = barsRecordset.GetField("Close");
                barsRecordset.AddField(ma.SimpleMovingAverage(barsNavigator, barsRecordset.GetField("Close"), MALongPeriods, "MALong").GetField("MALong"));
                barsRecordset.AddField(ma.SimpleMovingAverage(barsNavigator, barsRecordset.GetField("Close"), MAShortPeriods, "MAShort").GetField("MAShort"));
                barsRecordset.AddField(oscillator.StochasticOscillator(barsNavigator, barsRecordset, STOKPeriods, STOKSlowingPeriods, STODPeriods, STOMAType).GetField("%K"));
                barsRecordset.AddField(oscillator.StochasticOscillator(barsNavigator, barsRecordset, STOKPeriods, STOKSlowingPeriods, STODPeriods, STOMAType).GetField("%D"));
                barsRecordset.AddField(oscillator.MACDHistogram(barsNavigator, barsRecordset, MACDSignalPeriods, MACDLongCycle, MACDShortCycle, "MACDHistogram").GetField("MACDHistogram"));

                List<string> activeVars = new List<string>() { "MALong", "MAShort", "%K", "%D", "MACDHistogram" };
                int startingBar = StartingPoint(barsRecordset, activeVars);

                int upturnPatience = 0;
                int downturnPatience = 0;
                for (int idxBar = 1; idxBar < barsNavigator.RecordCount; idxBar++)
                {
                    if (idxBar < Math.Min(StartingPointGeneral, startingBar))
                    {
                        continue;
                    }

                    upturnPatience = Math.Max(upturnPatience - 1, 0);
                    downturnPatience = Math.Max(downturnPatience - 1, 0);

                    double MALong = Convert.ToDouble(barsRecordset.Value("MALong", idxBar));
                    double MAShort = Convert.ToDouble(barsRecordset.Value("MAShort", idxBar));
                    double STOK = Convert.ToDouble(barsRecordset.Value("%K", idxBar));
                    if (Double.IsNaN(STOK))
                    {
                        STOK = 50;
                    }
                    double STOD = Convert.ToDouble(barsRecordset.Value("%D", idxBar));
                    if (Double.IsNaN(STOD))
                    {
                        STOD = 50;
                    }
                    double MACDHistogram = Convert.ToDouble(barsRecordset.Value("MACDHistogram", idxBar));

                    if (MALong < MAShort && STOK < 20 || STOD < 20)
                    {
                        upturnPatience = 20;
                    }
                    if (MALong < MAShort && MACDHistogram > 0 && upturnPatience > 0)
                    {
                        tradeSignal[idxBar] = 1;
                    }
                    if (MALong > MAShort && STOK > 80 || STOK > 80)
                    {
                        downturnPatience = 20;
                    }
                    if (MALong > MAShort && MACDHistogram < 0)
                    {
                        tradeSignal[idxBar] = -1;
                    }
                }
                //var time1 = DateTime.Now;
                //Console.WriteLine(time1 - time);
                return tradeSignal;

            };
            return Anonymity;
        }

        public static Simulator.TradeStrategy MACrossover(int MAShortPeriods, int MALongPeriods, double upGap, double downGap)
        {
            MovingAverage ma = new MovingAverage();

            Simulator.TradeStrategy Anonymity = delegate(Navigator barsNavigator)
            {
                int[] tradeSignal = new int[barsNavigator.RecordCount];
                Recordset barsRecordset = barsNavigator.Recordset_;
                Field Close = barsRecordset.GetField("Close");
                barsRecordset.AddField(ma.SimpleMovingAverage(barsNavigator, barsRecordset.GetField("Close"), MALongPeriods, "MALong").GetField("MALong"));
                barsRecordset.AddField(ma.SimpleMovingAverage(barsNavigator, barsRecordset.GetField("Close"), MAShortPeriods, "MAShort").GetField("MAShort"));
                
                List<string> activeVars = new List<string>() { "MALong", "MAShort" };
                int startingBar = StartingPoint(barsRecordset, activeVars);

                for (int idxBar = 1; idxBar < barsNavigator.RecordCount; idxBar++)
                {
                    if (idxBar < Math.Min(StartingPointGeneral, startingBar))
                    {
                        continue;
                    }

                    double MALong = Convert.ToDouble(barsRecordset.Value("MALong", idxBar));
                    double MAShort = Convert.ToDouble(barsRecordset.Value("MAShort", idxBar));

                    if (MALong * upGap< MAShort)
                    {
                        tradeSignal[idxBar] = 1;
                    }
                    if (MALong > MAShort * downGap)
                    {
                        tradeSignal[idxBar] = -1;
                    }
                }
                return tradeSignal;

            };
            return Anonymity;
        }

        public static Simulator.TradeStrategy RSIJudgement(int RSIPeriod, double ASILMV, double ASIThreshold, int MAPeriod, int SlopeLongPeriod, int SlopeShortPeriod)
        {
            MovingAverage ma = new MovingAverage();
            Index index = new Index();
            LinearRegression lr = new LinearRegression();

            ASIThreshold = Math.Abs(ASIThreshold);

            Simulator.TradeStrategy Anonymity = delegate(Navigator barsNavigator)
            {
                int[] tradeSignal = new int[barsNavigator.RecordCount];
                Recordset barsRecordset = barsNavigator.Recordset_;

                Field Close = barsRecordset.GetField("Close");
                barsRecordset.AddField(index.RelativeStrengthIndex(barsNavigator, Close, RSIPeriod, "RSI").GetField("RSI"));
                barsRecordset.AddField(index.AccumulativeSwingIndex(barsNavigator, barsRecordset, ASILMV, "ASI").GetField("ASI"));
                barsRecordset.AddField(ma.ExponentialMovingAverage(barsNavigator, Close, MAPeriod, "MA").GetField("MA"));
                barsRecordset.AddField(lr.Regression(barsNavigator, Close, SlopeLongPeriod).GetField("Slope"));
                barsRecordset.RenameField("Slope", "SlopeLong");
                barsRecordset.AddField(lr.Regression(barsNavigator, Close, SlopeShortPeriod).GetField("Slope"));
                barsRecordset.RenameField("Slope", "SlopeShort");

                List<string> activeVars = new List<string>() { "ASI", "RSI", "SlopeShort", "SlopeLong", "MA" };
                int startingBar = StartingPoint(barsRecordset, activeVars);

                for (int idxBar = 1; idxBar < barsNavigator.RecordCount; idxBar++)
                {
                    if (idxBar < Math.Min(StartingPointGeneral, startingBar))
                    {
                        continue;
                    }

                    double SlopeLong = Convert.ToDouble(barsRecordset.Value("SlopeLong", idxBar));
                    double SlopeShort = Convert.ToDouble(barsRecordset.Value("SlopeShort", idxBar));
                    double RSI = Convert.ToDouble(barsRecordset.Value("RSI", idxBar));
                    if (Double.IsNaN(RSI)){
                        RSI = 100;
                    }
                    double ASI = Convert.ToDouble(barsRecordset.Value("ASI", idxBar));
                    double CLOSE = Convert.ToDouble(barsRecordset.Value("Close", idxBar));
                    double MA = Convert.ToDouble(barsRecordset.Value("MA", idxBar));

                    if (SlopeLong > 0 && ASI > ASIThreshold || RSI > 85)
                    {
                        tradeSignal[idxBar] = 1;
                    }
                    if (SlopeLong < 0 && ASI < -ASIThreshold || RSI < 15)
                    {
                        tradeSignal[idxBar] = -1;
                    }
                }
                return tradeSignal;

            };
            return Anonymity;
        }

        public static Simulator.TradeStrategy MACDDivergence(int MACDSignalPeriods, int MACDLongCycle, int MACDShortCycle, double GapUp, double GapDown, int recallPeriod)
        {
            Oscillator oscillator = new Oscillator();

            Simulator.TradeStrategy Anonymity = delegate(Navigator barsNavigator)
            {
                int[] tradeSignal = new int[barsNavigator.RecordCount];
                Recordset barsRecordset = barsNavigator.Recordset_;

                barsRecordset.AddField(oscillator.MACDHistogram(barsNavigator, barsRecordset, MACDSignalPeriods, MACDLongCycle, MACDShortCycle, "MACDHistogram").GetField("MACDHistogram"));

                List<string> activeVars = new List<string>() { "MACDHistogram" };
                int startingBar = StartingPoint(barsRecordset, activeVars);

                for (int idxBar = 1; idxBar < barsNavigator.RecordCount; idxBar++)
                {
                    if (idxBar < Math.Min(StartingPointGeneral, startingBar))
                    {
                        continue;
                    }

                    double MACDHistogram = Convert.ToDouble(barsRecordset.Value("MACDHistogram", idxBar));
                    
                    List<double> MACDHistory = new List<double>();
                    for (int offset = 1; offset <= recallPeriod; offset++)
                    {
                        MACDHistory.Add(Convert.ToDouble(barsRecordset.Value("MACDHistogram", Math.Max(1, idxBar - offset))));
                    }

                    if (MACDHistogram < 0 || MACDHistogram > GapUp * MACDHistory.Max())
                    {
                        tradeSignal[idxBar] = 1;
                    }
                    if (MACDHistogram > 0 || MACDHistogram < GapDown * MACDHistory.Min())
                    {
                        tradeSignal[idxBar] = -1;
                    }
                }
                return tradeSignal;

            };
            return Anonymity;
        }

        public static Simulator.TradeStrategy CCICorrelation(int CCIPeriod, double trendThreshold, double overThreshold)
        {
            Index index = new Index();

            trendThreshold = Math.Abs(trendThreshold);
            overThreshold = Math.Abs(overThreshold);

            Simulator.TradeStrategy Anonymity = delegate(Navigator barsNavigator)
            {
                int[] tradeSignal = new int[barsNavigator.RecordCount];
                Recordset barsRecordset = barsNavigator.Recordset_;

                barsRecordset.AddField(index.CommodityChannelIndex(barsNavigator, barsRecordset, CCIPeriod).GetField("CCI"));

                List<string> activeVars = new List<string>() { "CCI" };
                int startingBar = StartingPoint(barsRecordset, activeVars);

                for (int idxBar = 1; idxBar < barsNavigator.RecordCount; idxBar++)
                {
                    if (idxBar < Math.Min(StartingPointGeneral, startingBar))
                    {
                        continue;
                    }

                    double CCI = Convert.ToDouble(barsRecordset.Value("CCI", idxBar));
                    if (Double.IsNaN(CCI))
                    {
                        CCI = 0;
                    }

                    if (CCI > trendThreshold || CCI < -overThreshold)
                    {
                        tradeSignal[idxBar] = 1;
                    }
                    if (CCI < -trendThreshold || CCI > overThreshold)
                    {
                        tradeSignal[idxBar] = -1;
                    }

                }
                return tradeSignal;

            };
            return Anonymity;
        }

        public static Simulator.TradeStrategy ReturnReversion(int Period, double threshold)
        {
            threshold = Math.Abs(threshold);

            Simulator.TradeStrategy Anonymity = delegate(Navigator barsNavigator)
            {
                int[] tradeSignal = new int[barsNavigator.RecordCount];
                Recordset barsRecordset = barsNavigator.Recordset_;

                double[] historicalReturn = new double[barsNavigator.RecordCount];
                double previousPrice = Convert.ToDouble(barsRecordset.Value("Close", 1));

                for (int idxBar = 1; idxBar < barsNavigator.RecordCount; idxBar++){
                    double price = Convert.ToDouble(barsRecordset.Value("Close", idxBar));
                    historicalReturn[idxBar] = (price - previousPrice) / previousPrice;
                }

                for (int idxBar = Period; idxBar < barsNavigator.RecordCount; idxBar++)
                {
                    double averageReturn = 0;
                    for (int offset = 1; offset <= Period; offset++)
                    {
                        averageReturn += historicalReturn[idxBar - offset];
                    }
                    averageReturn /= Period;

                    if (averageReturn > threshold)
                    {
                        tradeSignal[idxBar] = 1;
                    }
                    if (averageReturn < -threshold)
                    {
                        tradeSignal[idxBar] = -1;
                    }
                }
                return tradeSignal;

            };
            return Anonymity;
        }

        public static Simulator.TradeStrategy ZScript(string buyScript, string sellScript, string exitLongScript="", string exitShortScript="")
        {
            Console.WriteLine("Init ZScript strategy. Currently, the exitLong and exitShort signals will be ignored.");

            //Script s = new Script();

            Simulator.TradeStrategy Anonymity = delegate(Navigator barsNavigator)
            {
                //s.m_trades.Clear();
                //s.m_records.Clear();
                Backtest backTest = new Backtest();
                Recordset barsRecordset = barsNavigator.Recordset_;

                Dictionary<long, int> calendar = new Dictionary<long, int>();

                for (int idxBar = 1; idxBar < barsNavigator.RecordCount; idxBar++)
                {
                    long ticks = Convert.ToInt64(barsRecordset.Value("DateTime", idxBar));
                    DateTime date = new DateTime(ticks);
                    // Something crazy starts from 1; We don't.
                    calendar.Add(ticks, idxBar - 1);
                    /*s.m_records.Add(new DataRecord
                    {
                        DateTime = date,
                        Open = Convert.ToDouble(barsRecordset.Value("Open", idxBar)),
                        High = Convert.ToDouble(barsRecordset.Value("High", idxBar)),
                        Low = Convert.ToDouble(barsRecordset.Value("Low", idxBar)),
                        Close = Convert.ToDouble(barsRecordset.Value("Close", idxBar)),
                        Volume = Convert.ToInt64(barsRecordset.Value("Volume", idxBar)),
                    });*/
                    backTest.AppendRecord(new DataRecord
                    {
                        DateTime = date,
                        Open = Convert.ToDouble(barsRecordset.Value("Open", idxBar)),
                        High = Convert.ToDouble(barsRecordset.Value("High", idxBar)),
                        Low = Convert.ToDouble(barsRecordset.Value("Low", idxBar)),
                        Close = Convert.ToDouble(barsRecordset.Value("Close", idxBar)),
                        Volume = Convert.ToInt64(barsRecordset.Value("Volume", idxBar)),
                    });
                }

                Modulus.Backtester.BacktestResults result = backTest.RunBacktest(buyScript, sellScript, exitLongScript, exitShortScript, 0);
                //s.RunBackTest(buyScript, Modulus.TradeScript.Constants.BUY);
                //s.RunBackTest(sellScript, Modulus.TradeScript.Constants.SELL);

                int[] tradeSignal = new int[barsNavigator.RecordCount];
                //foreach (Trade trade in s.m_trades)
                foreach (Modulus.Backtester.Trade trade in result.Trades)
                {
                    if (trade.Signal == Modulus.Backtester.SignalType.Buy)
                    {
                        tradeSignal[calendar[trade.Date.Ticks]] = 1;
                    }
                    else if (trade.Signal == Modulus.Backtester.SignalType.Sell)
                    {
                        tradeSignal[calendar[trade.Date.Ticks]] = -1;
                    }
                }

                return tradeSignal;

            };
            return Anonymity;
        }

        public static int StartingPoint(Recordset recordset, List<string> fields)
        {
            // Note: index starting from 1
            int index = 1;
            HashSet<string> allZeros = new HashSet<string>();
            foreach (string field in fields)
            {
                allZeros.Add(field);
                Debug.Assert(recordset.IsFieldValid(field));
            }
            while (allZeros.Any() && index < 200)
            {
                foreach (string field in new List<string>(allZeros))
                {
                    double value = Convert.ToDouble(recordset.Value(field, index));
                    if (!(value == 0)) // == is legel for comparing w/ 0 and 0 only
                    {
                        allZeros.Remove(field);
                    }
                }
                index++;
            }
            return index - 1;
        }
    }
}
