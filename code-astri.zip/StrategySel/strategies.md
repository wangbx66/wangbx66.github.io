# Strategy Structure

Every trading strategy is an instance of *Simulator.TradeStrategy*. The definition of the structure is in a one-line fasion, using *ModulusFE.TASDK.Navigator*, 

```cs
public delegate int[] TradeStrategy(Navigator barsNavigator);
```

# Use default ones

In the class *BuildinStrategies*, we have already defined several strategies. To get an instance *rr* of a strategy, e.g. *the mean reversion*, simply use 

```cs
TradeStrategy rr = BuildinStrategies.ReturnReversion(5, 0.02);
```

Note the 5 and 0.02 in the code indicate that the strategy considers the returns of latest 5 periods, while takes the action when the expected return of current period is more than 1.02.

# Build new strategies

## Structure

A strategy is a function takes an navigator as input, and output the trade signals represented by an array of integers. The input is an instance of *TASDK.Navigator*, which contains the market information of one symbol, during multiple latest periods (but not the current period, see *input* section). The output should have the same length as *barsNavigator.RecordCount* in the navigator. Currently, a "1" indicate a long action, also "0" for hold and "-1" for short.

## Input

The new strategy should take an instance of *navigator* (e.g. call it *barsNavigator*) as input. For the detailed document, please refer to the official one issued by Modulus. Here we have a list of commonly used attributes

* *barsNavigator.RecordCount;* the length of recorded period
* *barsNavigator.Recordset_.Value("Close", n);* the closing price of the n-th period, starting from 1. also "Open", "High", "low", and "Volume"
* To calculate moving average, first initiate an ma instance
```cs
MovingAverage ma = new MovingAverage();
```
Then, the following codes add a field called "MALong" to barsRecordset.
```cs
barsRecordset.AddField(ma.SimpleMovingAverage(barsNavigator, barsRecordset.GetField("Close"), MALongPeriods, "MALong").GetField("MALong"));
```
From then on, the moving average over the past *MALongPeriods* days can be accessed by
```cs
barsNavigator.Recordset_.Value("MALong", n);
```
Note that the above value is the moving average from the *n-MALongPeriods+1*-th period to the *n*-th period, inclusive

## Output

Each strategy should output an array of *barsNavigator.RecordCount* integers. the *n*-th integer, or *output_array[n-1]*, should indicates the buy/sell/hold action on the *n+1*-th period. Note the first element of the output should reasonably be always zero.
