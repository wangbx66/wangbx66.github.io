import sys
import os

import tensorflow as tf
import tflearn
from estimator import regression

def generate(tensor_shape, lstm1_output_dim, lstm2_output_dim, strategies_num, activation_name, optimizer_name):

    net = tflearn.input_data(tensor_shape)
    net = tflearn.lstm(net, lstm1_output_dim, return_seq=True)
    net = tflearn.lstm(net, lstm2_output_dim)
    net = tflearn.fully_connected(net, strategies_num, activation=activation_name)
    net = regression(net, optimizer=optimizer_name, loss="expected_loss")
    model = tflearn.DNN(net, clip_gradients=0., tensorboard_verbose=0)

    sess = tf.Session()
    sess.run(tf.initialize_all_variables())

    for grad in model.train_ops[0].grad:
        s = grad[0].name + " |partial " + grad[1].name
        tf.add_to_collection(tf.GraphKeys.VARIABLES, tf.identity(grad[0], name=s))

    file_name = ("_".join(("model", 
                        str(tensor_shape[0]),
                        str(tensor_shape[1]),
                        str(tensor_shape[2]), 
                        str(lstm1_output_dim), 
                        str(lstm2_output_dim), 
                        str(strategies_num),
                        activation_name,
                        optimizer_name,
                        )) + ".pb")

    os.makedirs("../models", exist_ok=True)
    print(file_name)
    tf.train.write_graph(sess.graph_def, "../models", file_name, as_text=False)

def generate_sample():

    tensor_shape = [None, 270, 5]
    lstm1_output_dim = 32
    lstm2_output_dim = 64
    strategies_num = 7
    activation_name = "Softmax"
    optimizer_name = "Adam"

    generate(tensor_shape, lstm1_output_dim, lstm2_output_dim, strategies_num, activation_name, optimizer_name)

if __name__ == '__main__':
    '''
    This function should NOT be called in a loop, unless with respect subprocess for each loopstep.
    This is to prevent memory abuse
    See generate_multi_models.py for a correct usage
    '''

    if sys.argv[1] == "sample":
        generate_sample()
    else:
        tensor_shape = [None, int(sys.argv[1]), int(sys.argv[2])]
        lstm1_output_dim = int(sys.argv[3])
        lstm2_output_dim = int(sys.argv[4])
        strategies_num = int(sys.argv[5])
        activation_name = sys.argv[6]
        optimizer_name = sys.argv[7]

        generate(tensor_shape, lstm1_output_dim, lstm2_output_dim, strategies_num, activation_name, optimizer_name)
