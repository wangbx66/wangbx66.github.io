from subprocess import call
from itertools import product

e = list(product(
         range(3,11),
         (8, 16, 32),
         (8, 16, 32, 64),
         range(2,15),
         ("Softmax", ),
         ("SGD", "RMSProp", "Adam", "Momentum", "AdaGrad", "Ftrl"),
         ))
print("{0} models total".format(len(e)))

for idx, p in enumerate(e):
    print(idx)
    call(("python3", "model_generator.py", "270") + tuple(str(x) for x in p))
