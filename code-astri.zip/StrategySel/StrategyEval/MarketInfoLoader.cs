﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

using AxiomObjects;
using GTADatabase;

using Modulus.TradeScript;

namespace StrategyEval
{
    class MarketInfoLoader
    {
        public StrategySel.PeriodicDBLoader.OnPercentChangeCall onPercentChangeCall = StrategySel.PeriodicDBLoader.pass;

        /*public List<List<double>> GTAMinuteDataDump(DateTime start, DateTime end)
        {
            string name = "minute";
            //Periodicity period = Periodicity.Minutely;
            string CurrentMarket = "ANY";
            TimeSpan seqSpan = TimeSpan.FromDays(1);
            List<List<double>> marketInfo = new List<List<double>>();

            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            double minimumPriceGap = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumGap", "0.15"));
            double minimumVolume = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumVolume", "2e6"));
            int precision = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "Precision", "7"));

            List<string> symbols = new List<string>();
            List<string> markets = new List<string>();
            System.IO.StreamReader symbolFile = new System.IO.StreamReader(System.AppDomain.CurrentDomain.BaseDirectory + "symbols");
            string line;
            while ((line = symbolFile.ReadLine()) != null)
            {
                // line is like "symbol-market name\s" (w/ 1 space)
                line = line.Trim();
                string tmp = Regex.Split(line, " ")[0];
                string symbol = Regex.Split(tmp, "-")[0];
                string market = Regex.Split(tmp, "-")[1];
                if (market == CurrentMarket || "ANY" == CurrentMarket)
                {
                    symbols.Add(symbol);
                    markets.Add(market);
                }
            }
            symbolFile.Close();

            StrategySel.PeriodicDBLoader dataLoader = new StrategySel.PeriodicDBLoader(start, end, symbols, markets, period, seqSpan, onPercentChangeCall);

            foreach (List<CommonObjects.Bar> bars in dataLoader)
            {
                String outputString = StrategySel.PeriodicUtils.DumpOutputString(bars, precision, minimumVolume, minimumPriceGap, StrategySel.PeriodicUtils.PreprocessBar5, new List<double>());
                List<string> slicingOutput = outputString.Trim().Split(' ').ToList<string>();

                StreamReader meanStdFile = new StreamReader(@"..\..\..\..\StrategySelByLarry\bin\Release\MeanStd.txt");
                int rowIndex = 0;
                List<double> meanX = new List<double>();
                List<double> stdX = new List<double>();
                while ((line = meanStdFile.ReadLine()) != null)
                {
                    if (rowIndex == 0)
                    {
                        List<string> slicingMeanX = line.Trim().Split(' ').ToList<string>();
                        for (int i = 0; i < slicingMeanX.Count; i++)
                        {
                            meanX.Add(Convert.ToDouble(slicingMeanX[i]));
                        }
                        rowIndex++;
                    }
                    else if (rowIndex == 1)
                    {
                        List<string> slicingStdX = line.Trim().Split(' ').ToList<string>();
                        for (int i = 0; i < slicingStdX.Count; i++)
                        {
                            stdX.Add(Convert.ToDouble(slicingStdX[i]));
                        }
                        rowIndex++;
                    }
                    else
                    {
                        break;
                    }
                }

                for (int i = 0; i < slicingOutput.Count; i+=meanX.Count)
                {
                    List<double> periodMarketInfo = new List<double>();
                    int idxCount = 0;
                    for (int j = i; j < i + meanX.Count; j++)
                    {
                        periodMarketInfo.Add(((Convert.ToDouble(slicingOutput[j])) - meanX[idxCount]) / stdX[idxCount]);
                        idxCount++;
                    }
                    marketInfo.Add(periodMarketInfo);
                }
            }

            return marketInfo;
        }*/

        public List<List<double>> DataAPIMinuteDataDump(string symbol, DateTime start, DateTime end, int interval)
        {
            List<List<double>> marketInfo = new List<List<double>>();
            string name = "minute";
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            double minimumPriceGap = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumGap", "0.15"));
            double minimumVolume = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumVolume", "2e6"));
            int precision = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "Precision", "7"));

            DataAPI.DataAPI api = new DataAPI.DataAPI("10.6.88.154", 5672, "rollen", "root", "DATA_STORE_MANAGER", "10.6.88.154", 60, null);
            //api.Start();

            List<AxiomObjects.Bar> bars = api.GetHistoricalBarSync(symbol, '1', start, end, interval);
            String outputString = StrategySelByLarry.PeriodicUtils.DumpOutputString(bars, precision, minimumVolume, minimumPriceGap, StrategySelByLarry.PeriodicUtils.PreprocessBar5, new List<double>());
            List<string> slicingOutput = outputString.Trim().Split(' ').ToList<string>();

            StreamReader meanStdFile = new StreamReader(@"..\..\..\..\StrategySel\bin\Debug\MeanStd.txt");
            int rowIndex = 0;
            List<double> meanX = new List<double>();
            List<double> stdX = new List<double>();
            string line;
            while ((line = meanStdFile.ReadLine()) != null)
            {
                if (rowIndex == 0)
                {
                    List<string> slicingMeanX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingMeanX.Count; i++)
                    {
                        meanX.Add(Convert.ToDouble(slicingMeanX[i]));
                    }
                    rowIndex++;
                }
                else if (rowIndex == 1)
                {
                    List<string> slicingStdX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingStdX.Count; i++)
                    {
                        stdX.Add(Convert.ToDouble(slicingStdX[i]));
                    }
                    rowIndex++;
                }
                else
                {
                    break;
                }
            }

            for (int i = 0; i < slicingOutput.Count; i += meanX.Count)
            {
                List<double> periodMarketInfo = new List<double>();
                int idxCount = 0;
                for (int j = i; j < i + meanX.Count; j++)
                {
                    periodMarketInfo.Add(((Convert.ToDouble(slicingOutput[j])) - meanX[idxCount]) / stdX[idxCount]);
                    idxCount++;
                }
                marketInfo.Add(periodMarketInfo);
            }

            return marketInfo;
        }

        public List<List<double>> DataAPIMinuteDataDump_MultiData(string tradingSymbol, DateTime start, DateTime end, int interval)
        {
            string name = "minute";
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            double minimumPriceGap = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumGap", "0.15"));
            double minimumVolume = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumVolume", "2e6"));
            int precision = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "Precision", "7"));
            List<List<AxiomObjects.Bar>> allSymbolBarsList = new List<List<AxiomObjects.Bar>>();

            List<string> symbols = new List<string>();
            System.IO.StreamReader additionSymbolFile = new System.IO.StreamReader(@"..\..\..\..\StrategySelByLarry\AdditionSymbols");
            string line;
            while ((line = additionSymbolFile.ReadLine()) != null)
            {
                // line is like "symbol-market name\s" (w/ 1 space)
                line = line.Trim();
                string additionSymbol = Regex.Split(line, " ")[0];
                symbols.Add(additionSymbol);
            }
            additionSymbolFile.Close();

            StreamReader meanStdFile = new StreamReader(@"..\..\..\..\StrategySelByLarry\bin\x64\Release\MeanStd.txt");
            int rowIndex = 0;
            List<double> meanX = new List<double>();
            List<double> stdX = new List<double>();
            List<double> numOfX = new List<double>();
            while ((line = meanStdFile.ReadLine()) != null)
            {
                if (rowIndex == 0)
                {
                    List<string> slicingMeanX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingMeanX.Count; i++)
                    {
                        meanX.Add(Convert.ToDouble(slicingMeanX[i]));
                    }
                    rowIndex++;
                }
                else if (rowIndex == 1)
                {
                    List<string> slicingStdX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingStdX.Count; i++)
                    {
                        stdX.Add(Convert.ToDouble(slicingStdX[i]));
                    }
                    rowIndex++;
                }
                else if (rowIndex == 2)
                {
                    List<string> slicingNumOfX = line.Trim().Split(' ').ToList<string>();
                    for (int i = 0; i < slicingNumOfX.Count; i++)
                    {
                        numOfX.Add(Convert.ToDouble(slicingNumOfX[i]));
                    }
                    rowIndex++;
                }
                else
                {
                    break;
                }
            }

            DataAPI.DataAPI api = new DataAPI.DataAPI("10.6.88.154", 5672, "rollen", "root", "DATA_STORE_MANAGER", "10.6.88.154", 60, null);

            allSymbolBarsList.Add(api.GetHistoricalBarSync(tradingSymbol, '1', start, end, 1));
            /*foreach (string symbol in symbols)
            {
                allSymbolBarsList.Add(api.GetHistoricalBarSync(symbol, '1', start, end, 1));
            }*/

            List<List<double>> features = FeaturesConstructerOnTestingData(allSymbolBarsList);
            for (int period = 0; period < features.Count; period++)
            {
                for (int elementIdx = 0; elementIdx < features[period].Count; elementIdx++)
                {
                    if (stdX[elementIdx] == 0)
                    {
                        features[period][elementIdx] = 0;
                    }
                    else
                    {
                        double tempMean = meanX[elementIdx];
                        numOfX[elementIdx] = numOfX[elementIdx] + 1;
                        meanX[elementIdx] = meanX[elementIdx] + (features[period][elementIdx] - meanX[elementIdx]) / numOfX[elementIdx];
                        stdX[elementIdx] = stdX[elementIdx] + (features[period][elementIdx] - tempMean) * (features[period][elementIdx] - meanX[elementIdx]);
                        features[period][elementIdx] = (features[period][elementIdx] - meanX[elementIdx]) / stdX[elementIdx];
                    }
                }
            }

            return features;
        }

        public List<List<double>> FeaturesConstructerOnTestingData(List<List<AxiomObjects.Bar>> allSymbolBarsList)
        {
            List<List<double>> featuresList = new List<List<double>>();
            string feature;
            string featureString = " ";
            int featureIdx = 0;
            StreamReader featuresReader = new StreamReader(@"..\..\..\..\features");
            while ((feature = featuresReader.ReadLine()) != null)
            {
                if (featureIdx == 0)
                {
                    featureString = feature.Trim();
                    featureIdx++;
                }
                else
                {
                    featureString = featureString + " + " + feature.Trim();
                }
            }

            try
            {
                foreach (List<AxiomObjects.Bar> barList in allSymbolBarsList)
                {
                    ScriptOutput o = new ScriptOutput();
                    o.License = "XRT93NQR79ABTW788XR48";

                    foreach (Bar bar in barList)
                    {
                        o.AppendRecord(bar.Time,
                            Convert.ToDouble(bar.Open), Convert.ToDouble(bar.High), Convert.ToDouble(bar.Low), Convert.ToDouble(bar.Close),
                            Convert.ToInt64(bar.Volume));
                    }

                    List<TaSdkField> fields = new List<TaSdkField>(o.GetScriptOutput(featureString));
                    for (int i = 0; i < fields.First().Data.Count; i++)
                    {
                        List<double> line = new List<double>();
                        for (int j = 1; j < fields.Count(); j++)
                        {
                            if (Double.IsNaN(fields[j][i]))
                            {
                                line.Add(0);
                            }
                            else
                            {
                                line.Add(fields[j][i]);
                            }
                        }

                        featuresList.Add(line);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            /*double tradingSymbolPreviousClose = 0;
            for (int period = 0; period < allSymbolBarsList[0].Count; period++)
            {
                List<double> line = new List<double>(new double[allSymbolBarsList.Count * 6]);
                DateTime time = allSymbolBarsList[0][period].Time;
                if (tradingSymbolPreviousClose == 0)
                {
                    tradingSymbolPreviousClose = Convert.ToDouble(allSymbolBarsList[0][period].Close);
                }
                line[0] = Math.Round((Convert.ToDouble(allSymbolBarsList[0][period].High) - Convert.ToDouble(allSymbolBarsList[0][period].Close)) / Convert.ToDouble(allSymbolBarsList[0][period].Close), 7) * 250;
                line[1] = Math.Round((Convert.ToDouble(allSymbolBarsList[0][period].Close) - Convert.ToDouble(allSymbolBarsList[0][period].Low)) / Convert.ToDouble(allSymbolBarsList[0][period].Close), 7) * 250;
                line[2] = Math.Round((Convert.ToDouble(allSymbolBarsList[0][period].Close) - Convert.ToDouble(allSymbolBarsList[0][period].Open)) / Convert.ToDouble(allSymbolBarsList[0][period].Close), 7) * 250;
                line[3] = Convert.ToDouble(StrategySelByLarry.PeriodicUtils.RelativePrice(allSymbolBarsList[0][period].Close, Convert.ToDecimal(tradingSymbolPreviousClose), 7) * 750);
                line[4] = Math.Log(Convert.ToDouble(allSymbolBarsList[0][period].Volume + 1)) / 3.5;
                line[5] = allSymbolBarsList[0][period].OpenInterest;
                tradingSymbolPreviousClose = Convert.ToDouble(allSymbolBarsList[0][period].Close);

                for (int symbolIdx = 1; symbolIdx < allSymbolBarsList.Count; symbolIdx++)
                {
                    if (allSymbolBarsList[symbolIdx].Count == 0)
                    {
                        continue;
                    }
                    else
                    {
                        double additionalSymbolPreviousClose = 0;
                        for (int lineIdx = 0; lineIdx < allSymbolBarsList[symbolIdx].Count; lineIdx++)
                        {
                            if (allSymbolBarsList[symbolIdx][lineIdx].Time > time)
                            {
                                break;
                            }
                            else if (allSymbolBarsList[symbolIdx][lineIdx].Time < time)
                            {
                                allSymbolBarsList[symbolIdx].RemoveAt(lineIdx);
                                continue;
                            }
                            else if (allSymbolBarsList[symbolIdx][lineIdx].Time == time)
                            {
                                int startingIdx = symbolIdx * 6;
                                if (additionalSymbolPreviousClose ==0)
                                {
                                    additionalSymbolPreviousClose = Convert.ToDouble(allSymbolBarsList[symbolIdx][lineIdx].Close);
                                }
                                line[startingIdx] = Math.Round(Convert.ToDouble((allSymbolBarsList[symbolIdx][lineIdx].High - allSymbolBarsList[symbolIdx][lineIdx].Close) / allSymbolBarsList[symbolIdx][lineIdx].Close), 7) * 250;
                                line[startingIdx + 1] = Math.Round(Convert.ToDouble((allSymbolBarsList[symbolIdx][lineIdx].Close - allSymbolBarsList[symbolIdx][lineIdx].Low) / allSymbolBarsList[symbolIdx][lineIdx].Close), 7) * 250;
                                line[startingIdx + 2] = Math.Round(Convert.ToDouble((allSymbolBarsList[symbolIdx][lineIdx].Close - allSymbolBarsList[symbolIdx][lineIdx].Open) / allSymbolBarsList[symbolIdx][lineIdx].Close), 7) * 250;
                                line[startingIdx + 3] = Convert.ToDouble(StrategySelByLarry.PeriodicUtils.RelativePrice(allSymbolBarsList[symbolIdx][lineIdx].Close, Convert.ToDecimal(additionalSymbolPreviousClose), 7) * 750);
                                line[startingIdx + 4] = Math.Log(Convert.ToDouble(allSymbolBarsList[symbolIdx][lineIdx].Volume +1)) / 3.5;
                                line[startingIdx + 5] = allSymbolBarsList[symbolIdx][lineIdx].OpenInterest;
                                additionalSymbolPreviousClose = Convert.ToDouble(allSymbolBarsList[symbolIdx][lineIdx].Close);

                                if (symbolIdx == 0)
                                {
                                    break;
                                }
                                else
                                {
                                    allSymbolBarsList[symbolIdx].RemoveAt(lineIdx);
                                    break;
                                }
                            }
                        }
                    }
                }

                featuresList.Add(line);
            }*/

            return featuresList;
        }
    }
}
