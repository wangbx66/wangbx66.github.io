﻿using CommonObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

using ModulusFE.TASDK;

namespace StrategyEval
{
    class Trader
    {
        public const string POSITION_CLOSED = "_close";
        public const string POSITION_LONG = "_long";
        public const string POSITION_SHORT = "_short";

        public StrategySelByLarry.Simulator simulator;
        public TimeSpan seqSpan;
        public Periodicity period;

        public string name;
        public int TotalSequences = -1;
        public decimal CommissionFeeNTax = -1;
        public DateTime Start = new DateTime(2011, 1, 1, 8, 0, 0);
        public DateTime End = new DateTime(2011, 1, 5, 8, 0, 0);
        public string CurrentMarket = null;
        //public double initMoney = 9000;

        public StrategySel.PeriodicDBLoader.OnPercentChangeCall onPercentChangeCall = StrategySel.PeriodicDBLoader.pass;

        public decimal ModelMinutelyDayTrade(List<List<double>> modelPrediction, decimal initMoney, List<AxiomObjects.Bar> bars)
        {
            decimal modelPerformance = 0;

            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            double minimumPriceGap = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumGap", "0.15"));
            double minimumVolume = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumVolume", "2e6"));

            int precision = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "Precision", "7"));
            double decay = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "Decay", "0.95"));
            int windowLength = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "WindowLength", "45"));
            int explorationLength = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "20"));

            Navigator DatabaseNavigator = StrategySelByLarry.PeriodicUtils.GetDatabaseNavigator(bars);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            int numOfStrategies = tradeSignals.Count;

            for (int idxStra = 0; idxStra < simulator.strategies.Count; idxStra++)
            {
                List<decimal> strategyPeriodPortfolio = new List<decimal>();
                decimal strategyTotalPortfolio = 0;

                for (int startingBar = 31; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    decimal init = (initMoney / Convert.ToDecimal(DatabaseNavigator.RecordCount - 30)) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                    decimal portfolio = (initMoney / Convert.ToDecimal(DatabaseNavigator.RecordCount - 30)) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                    decimal cash = (initMoney / Convert.ToDecimal(DatabaseNavigator.RecordCount - 30)) * Convert.ToDecimal(modelPrediction[startingBar - 2][idxStra]);
                    decimal share = 0;
                    string position = POSITION_CLOSED;
                    decimal exitPrice = 0;
                    decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                    decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                    decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                    decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                    decimal takeProfit = 0;
                    decimal stopLoss = 0;

                    for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount; idxBar++)
                    {
                        #region tradeLogicByLarry
                        if (idxBar == DatabaseNavigator.RecordCount)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * (1 - CommissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                                //Console.WriteLine("day end: exit long");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("");
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * (1 + CommissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                                //Console.WriteLine("day end: exit short");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("");
                            }
                            break;
                        }

                        if (position == POSITION_CLOSED)
                        {
                            if (tradeSignals[idxStra][idxBar - 1] == 1)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = (1 - CommissionFeeNTax) * init / exitPrice;
                                cash = 0;
                                position = POSITION_LONG;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                                //Console.WriteLine("long entry");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("");
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 2)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = -init / exitPrice;
                                cash += -share * exitPrice * (1 - CommissionFeeNTax);
                                position = POSITION_SHORT;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                                //Console.WriteLine("short entry");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("");
                            }
                        }
                        else if (position == POSITION_LONG)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                    //Console.WriteLine("longTP TP exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    //Console.WriteLine("longTP OPEN exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                    //Console.WriteLine("longSL SL exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    //Console.WriteLine("longSL OPEN exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 3)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("exitLong rule exit");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(exitPrice);
                                //Console.WriteLine("");
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * (1 - CommissionFeeNTax);
                                share = 0;
                            }
                        }
                        else if (position == POSITION_SHORT)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                    //Console.WriteLine("shortTP TP exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    //Console.WriteLine("shortTP OPEN exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                    //Console.WriteLine("shortSL SL exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    //Console.WriteLine("shortSL OPEN exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 4)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("exitshort rule exit");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(exitPrice);
                                //Console.WriteLine("");
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * (1 + CommissionFeeNTax);
                                share = 0;
                            }
                        }
                        #endregion tradeLogicByLarry

                        #region originTradeLogic
                        /*
                        price = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                        if (idxBar == startingBar)
                        {
                            seqOpen = price;
                        }

                        if (idxBar == DatabaseNavigator.RecordCount)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * price * (1 - CommissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * price * (1 + CommissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            break;
                        }

                        if (tradeSignals[idxStra][idxBar - 1] == 1)
                        {
                            if (position == POSITION_CLOSED)
                            {
                                share = (1 - CommissionFeeNTax) * init / price;
                                cash = 0;
                                position = POSITION_LONG;
                            }
                            else if (position == POSITION_LONG)
                            {
                                ;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += 2 * share * price;
                                share += -2 * share * (1 - CommissionFeeNTax);
                                position = POSITION_LONG;
                            }
                        }

                        else if (tradeSignals[idxStra][idxBar - 1] == -1)
                        {
                            if (position == POSITION_CLOSED)
                            {
                                share = -init / price;
                                cash = 1 + (1 - CommissionFeeNTax);
                                position = POSITION_SHORT;
                            }
                            else if (position == POSITION_LONG)
                            {
                                cash += 2 * share * price * (1 - CommissionFeeNTax);
                                share += -2 * share;
                                position = POSITION_SHORT;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                ;
                            }
                        }
                        */
                        #endregion originTradeLogic
                    }

                    strategyPeriodPortfolio.Add(portfolio);
                }

                for (int i = 0; i < strategyPeriodPortfolio.Count; i++)
                {
                    strategyTotalPortfolio += strategyPeriodPortfolio[i];
                }
                modelPerformance += strategyTotalPortfolio;
            }

            return modelPerformance;
        }

        public List<decimal> StrategiesMinutelyDayTrade(List<decimal> strategiesInitMoney, List<AxiomObjects.Bar> bars)
        {
            List<decimal> strategiesPerformance = new List<decimal>();

            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            double minimumPriceGap = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumGap", "0.15"));
            double minimumVolume = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumVolume", "2e6"));

            int precision = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "Precision", "7"));
            double decay = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "Decay", "0.95"));
            int windowLength = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "WindowLength", "45"));
            int explorationLength = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "20"));

            Navigator DatabaseNavigator = StrategySelByLarry.PeriodicUtils.GetDatabaseNavigator(bars);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            int numOfStrategies = tradeSignals.Count;

            for (int idxStra = 0; idxStra < numOfStrategies; idxStra++)
            {
                decimal init = strategiesInitMoney[idxStra];
                decimal portfolio = strategiesInitMoney[idxStra];
                decimal cash = strategiesInitMoney[idxStra];
                decimal share = 0;
                decimal margin = 0;
                string position = POSITION_CLOSED;
                decimal seqOpen = 0;
                decimal price = 0;

                for (int idxBar = 31; idxBar <= DatabaseNavigator.RecordCount; idxBar++)
                {
                    #region tradeLogic
                    price = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                    if (idxBar == 31)
                    {
                        seqOpen = price;
                    }

                    if (idxBar == DatabaseNavigator.RecordCount)
                    {
                        if (position == POSITION_LONG)
                        {
                            cash += share * price * (1 - CommissionFeeNTax);
                            portfolio = cash;
                            share = 0;
                            position = POSITION_CLOSED;
                        }
                        else if (position == POSITION_SHORT)
                        {
                            cash += margin * (1 - CommissionFeeNTax) + share * price * (1 + CommissionFeeNTax);
                            portfolio = cash;
                            share = 0;
                            margin = 0;
                            position = POSITION_CLOSED;
                        }
                        break;
                    }

                    if (tradeSignals[idxStra][idxBar - 1] == 1)
                    {
                        if (position == POSITION_CLOSED)
                        {
                            share = (1 - CommissionFeeNTax) * init / price;
                            cash = 0;
                            position = POSITION_LONG;
                        }
                        else if (position == POSITION_LONG)
                        {
                            ;
                        }
                        else if (position == POSITION_SHORT)
                        {
                            //cash += 2 * share * price;
                            //share += -2 * share * (1 - CommissionFeeNTax);
                            //position = POSITION_LONG;

                            //Step1 close out position
                            cash += margin * (1 - CommissionFeeNTax) + share * price * (1 + CommissionFeeNTax);
                            share = 0;
                            margin = 0;
                            //Step2 enter long position
                            share = (1 - CommissionFeeNTax) * cash / price;
                            cash = 0;
                            position = POSITION_LONG;
                        }
                    }

                    else if (tradeSignals[idxStra][idxBar - 1] == -1)
                    {
                        if (position == POSITION_CLOSED)
                        {
                            //share = - (1 - CommissionFeeNTax) * init / price;
                            //cash = 1 + (1 - commissionFeeNTax);
                            //position = POSITION_SHORT;
                            margin = init * (1 - CommissionFeeNTax);
                            share = -init / price;
                            cash = -share * price * (1 - CommissionFeeNTax);
                            position = POSITION_SHORT;
                        }
                        else if (position == POSITION_LONG)
                        {
                            //cash += 2 * share * price * (1 - CommissionFeeNTax);
                            //share += -2 * share;
                            //position = POSITION_SHORT;

                            //Step1 close out position
                            cash += share * price * (1 - CommissionFeeNTax);
                            share = 0;
                            //Step2 enter short position
                            margin = cash * (1 - CommissionFeeNTax);
                            share = -cash / price;
                            cash = -share * price * (1 - CommissionFeeNTax);
                            position = POSITION_SHORT;
                        }
                        else if (position == POSITION_SHORT)
                        {
                            ;
                        }
                    }
                    #endregion tradeLogic
                }
                strategiesPerformance.Add(portfolio);
            }

            return strategiesPerformance;
        }

        public List<decimal> StrategiesMinutelyDayPeriodTrade(List<decimal> strategiesInitMoney, List<AxiomObjects.Bar> bars)
        {
            List<decimal> strategiesPerformance = new List<decimal>();

            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            double minimumPriceGap = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumGap", "0.15"));
            double minimumVolume = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "MinimumVolume", "2e6"));

            int precision = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "Precision", "7"));
            double decay = Convert.ToDouble(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "Decay", "0.95"));
            int windowLength = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "WindowLength", "45"));
            int explorationLength = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(StrategySel.INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "20"));

            Navigator DatabaseNavigator = StrategySelByLarry.PeriodicUtils.GetDatabaseNavigator(bars);
            List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
            int numOfStrategies = tradeSignals.Count;

            for (int idxStra = 0; idxStra < numOfStrategies; idxStra++)
            {
                List<decimal> strategyPeriodPortfolio = new List<decimal>();
                decimal strategyTotalPortfolio = 0;

                for (int startingBar = 31; startingBar <= DatabaseNavigator.RecordCount; startingBar++)
                {
                    decimal init = (strategiesInitMoney[idxStra] / Convert.ToDecimal(DatabaseNavigator.RecordCount - 30));
                    decimal portfolio = (strategiesInitMoney[idxStra] / Convert.ToDecimal(DatabaseNavigator.RecordCount - 30));
                    decimal cash = (strategiesInitMoney[idxStra] / Convert.ToDecimal(DatabaseNavigator.RecordCount - 30));
                    decimal share = 0;
                    string position = POSITION_CLOSED;
                    //decimal seqOpen = 0;
                    decimal exitPrice = 0;
                    decimal longTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][0]);
                    decimal longStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][1]);
                    decimal shortTakeProfit = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][2]);
                    decimal shortStopLoss = Convert.ToDecimal(simulator.takeProfitNStopLoss[idxStra][3]);
                    decimal takeProfit = 0;
                    decimal stopLoss = 0;

                    for (int idxBar = startingBar; idxBar <= DatabaseNavigator.RecordCount; idxBar++)
                    {
                        #region tradeLogicByLarry
                        if (idxBar == DatabaseNavigator.RecordCount)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * (1 - CommissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                                //Console.WriteLine("day end: exit long");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("");
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) * (1 + CommissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                                //Console.WriteLine("day end: exit short");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("");
                            }
                            break;
                        }

                        if (position == POSITION_CLOSED)
                        {
                            if (tradeSignals[idxStra][idxBar - 1] == 1)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = (1 - CommissionFeeNTax) * init / exitPrice;
                                cash = 0;
                                position = POSITION_LONG;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + longTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - longStopLoss;
                                //Console.WriteLine("long entry");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("");
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 2)
                            {
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                share = -init / exitPrice;
                                cash += -share * exitPrice * (1 - CommissionFeeNTax);
                                position = POSITION_SHORT;
                                takeProfit = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) - shortTakeProfit;
                                stopLoss = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar)) + shortStopLoss;
                                //Console.WriteLine("short entry");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("");
                            }
                        }
                        else if (position == POSITION_LONG)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                    //Console.WriteLine("longTP TP exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    //Console.WriteLine("longTP OPEN exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                    //Console.WriteLine("longSL SL exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    //Console.WriteLine("longSL OPEN exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 3)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("exitLong rule exit");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(exitPrice);
                                //Console.WriteLine("");
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * (1 - CommissionFeeNTax);
                                share = 0;
                            }
                        }
                        else if (position == POSITION_SHORT)
                        {
                            if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Low", idxBar)) <= takeProfit)
                            {
                                position = POSITION_CLOSED;
                                if (takeProfit < Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = takeProfit;
                                    //Console.WriteLine("shortTP TP exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    //Console.WriteLine("shortTP OPEN exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                            }
                            else if (Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("High", idxBar)) >= stopLoss)
                            {
                                position = POSITION_CLOSED;
                                if (stopLoss > Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar)))
                                {
                                    exitPrice = stopLoss;
                                    //Console.WriteLine("shortSL SL exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                                else
                                {
                                    exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Open", idxBar));
                                    //Console.WriteLine("shortSL OPEN exit");
                                    //Console.WriteLine(bars[idxBar - 1].Time);
                                    //Console.WriteLine(exitPrice);
                                    //Console.WriteLine("");
                                }
                            }
                            else if (tradeSignals[idxStra][idxBar - 1] == 4)
                            {
                                position = POSITION_CLOSED;
                                exitPrice = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                                //Console.WriteLine("exitshort rule exit");
                                //Console.WriteLine(bars[idxBar - 1].Time);
                                //Console.WriteLine(exitPrice);
                                //Console.WriteLine("");
                            }

                            if (position == POSITION_CLOSED)
                            {
                                cash += share * exitPrice * (1 + CommissionFeeNTax);
                                share = 0;
                            }
                        }
                        #endregion tradeLogicByLarry
                        
                        #region originTradeLogic
                        /*
                        price = Convert.ToDecimal(DatabaseNavigator.Recordset_.Value("Close", idxBar));
                        if (idxBar == startingBar)
                        {
                            seqOpen = price;
                        }

                        if (idxBar == DatabaseNavigator.RecordCount)
                        {
                            if (position == POSITION_LONG)
                            {
                                cash += share * price * (1 - CommissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += share * price * (1 + CommissionFeeNTax);
                                portfolio = cash;
                                share = 0;
                                position = POSITION_CLOSED;
                            }
                            break;
                        }

                        if (tradeSignals[idxStra][idxBar - 1] == 1)
                        {
                            if (position == POSITION_CLOSED)
                            {
                                share = (1 - CommissionFeeNTax) * init / price;
                                cash = 0;
                                position = POSITION_LONG;
                            }
                            else if (position == POSITION_LONG)
                            {
                                ;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                cash += 2 * share * price;
                                share += -2 * share * (1 - CommissionFeeNTax);
                                position = POSITION_LONG;
                            }
                        }

                        else if (tradeSignals[idxStra][idxBar - 1] == -1)
                        {
                            if (position == POSITION_CLOSED)
                            {
                                share = -init / price;
                                cash = 1 + (1 - CommissionFeeNTax);
                                position = POSITION_SHORT;
                            }
                            else if (position == POSITION_LONG)
                            {
                                cash += 2 * share * price * (1 - CommissionFeeNTax);
                                share += -2 * share;
                                position = POSITION_SHORT;
                            }
                            else if (position == POSITION_SHORT)
                            {
                                ;
                            }
                        }
                        */
                        #endregion originTradeLogic
                    }

                    strategyPeriodPortfolio.Add(portfolio);
                }

                for (int i = 0; i < strategyPeriodPortfolio.Count; i++)
                {
                    strategyTotalPortfolio += strategyPeriodPortfolio[i];
                }
                strategiesPerformance.Add(strategyTotalPortfolio);
            }

            return strategiesPerformance;
        }
    }
}
