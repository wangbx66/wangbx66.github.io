﻿using CommonObjects;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using ModulusFE.TASDK;

namespace StrategyEval
{
    class Program
    {
        public static void printPercent(int percent)
        {
            Console.WriteLine(String.Format("{0} percent completed", percent));
        }

        static void Main(string[] args)
        {
            WorkFlowControler();
            //StrategyTracker();
        }

        public static void WorkFlowControler()
        {
            #region init
            MarketInfoLoader marketInfoLoader = new MarketInfoLoader { onPercentChangeCall = printPercent };
            //string modelFilePath = @"..\..\..\..\CNTK_StrategySel\Models\Trained_StrategySel_Model_double.dnn";
            string modelFilePath = @"..\..\..\..\CNTK_StrategySel\Models\Trained_StrategySel_Model.dnn";
            StrategySelByLarry.Simulator simulator = new StrategySelByLarry.Simulator();
            StrategySelByLarry.StrategiesReader strategyReader = new StrategySelByLarry.StrategiesReader();
            strategyReader.LongOnly(simulator);
            decimal initMoney = 9000;
            string symbol = "601988-SSE";
            int interval = 1;
            int numOfStrategies = simulator.strategies.Count;

            DateTime start = new DateTime(2015, 1, 1, 8, 0, 0);
            DateTime end = new DateTime(2016, 1, 1, 8, 0, 0);

            List<decimal> modelPortfolioTracker = new List<decimal>();
            modelPortfolioTracker.Add(initMoney);

            List<List<decimal>> strategiesPortfolioTracker = new List<List<decimal>>();
            List<decimal> strategiesInitMoney = new List<decimal>();
            for (int i = 0; i < numOfStrategies; i++)
            {
                strategiesInitMoney.Add(initMoney);
            }
            strategiesPortfolioTracker.Add(strategiesInitMoney);
            #endregion init

            DataAPI.DataAPI api = new DataAPI.DataAPI("10.6.88.154", 5672, "rollen", "root", "DATA_STORE_MANAGER", "10.6.88.154", 60, null);
            //api.Start();

            int dayCount = 0;
            for (DateTime startDate = start; startDate < end; startDate = startDate.AddDays(1))
            {
                #region dailyTrade
                List<AxiomObjects.Bar> bars = api.GetHistoricalBarSync(symbol, '1', startDate, startDate.AddDays(1), interval);
                if (bars.Count <= 10)
                {
                    continue;
                }

                Trader Trader = new Trader
                {
                    CommissionFeeNTax = Convert.ToDecimal(0.0002),
                    CurrentMarket = "ANY",
                    TotalSequences = 6000,
                    name = "minute",
                    simulator = simulator,
                    seqSpan = TimeSpan.FromDays(1),
                    period = Periodicity.Minutely,
                    Start = startDate,
                    End = startDate.AddDays(1),
                };

                List<List<double>> marketInfo = marketInfoLoader.DataAPIMinuteDataDump_MultiData(symbol, startDate, startDate.AddDays(1), interval);

                List<List<double>> modelPrediction = ModelExecutor.DoublePrecision(modelFilePath, marketInfo);

                modelPortfolioTracker.Add(Trader.ModelMinutelyDayTrade(modelPrediction, modelPortfolioTracker[dayCount], bars));
                strategiesPortfolioTracker.Add(Trader.StrategiesMinutelyDayPeriodTrade(strategiesPortfolioTracker[dayCount], bars));

                dayCount++;
                #endregion dailyTrade
            }

            decimal modelSharpRatio = Evaluator.ModelPerformanceSharpRatio(modelPortfolioTracker);
            List<decimal> strategiesSharpRatio = Evaluator.StrategiesPerformanceSharpRatio(strategiesPortfolioTracker);

            StreamWriter performanceFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "StrategyPerformance.txt");
            performanceFile.WriteLine("model strategy1 strategy2 strategy3 strategy4 strategy5 strategy6 strategy7 strategy8 strategy9");
            for (int period = 0; period < modelPortfolioTracker.Count; period++)
            {
                string line = modelPortfolioTracker[period].ToString() + " " + String.Join(" ", strategiesPortfolioTracker[period]);
                performanceFile.WriteLine(line.Trim());
            }
            performanceFile.Close();

            StreamWriter sharpRatioFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "SharpRatio.txt");
            sharpRatioFile.WriteLine("model SharpRatio");
            sharpRatioFile.WriteLine(modelSharpRatio.ToString());
            for (int straIdx = 0; straIdx < numOfStrategies; straIdx++ )
            {
                sharpRatioFile.WriteLine(String.Format("SharpRatio of Strategy {0}", straIdx + 1));
                sharpRatioFile.WriteLine(strategiesSharpRatio[straIdx].ToString());
            }
            sharpRatioFile.Close();
        }

        public static void StrategyTracker()
        {
            StrategySelByLarry.Simulator simulator = new StrategySelByLarry.Simulator();
            simulator.LoadDefault();

            string symbol = "601988-SSE";
            int interval = 1;
            char level = '1';
            decimal initMoney = 9000;
            int numOfStrategies = simulator.strategies.Count();

            DateTime start = new DateTime(2010, 1, 1, 8, 0, 0);
            DateTime end = new DateTime(2015, 1, 1, 8, 0, 0);

            List<List<decimal>> strategiesPortfolioTracker = new List<List<decimal>>();
            List<decimal> strategiesInitMoney = new List<decimal>();
            for (int i = 0; i < numOfStrategies; i++)
            {
                strategiesInitMoney.Add(initMoney);
            }
            strategiesPortfolioTracker.Add(strategiesInitMoney);

            DataAPI.DataAPI api = new DataAPI.DataAPI("10.6.88.154", 5672, "rollen", "root", "DATA_STORE_MANAGER", "10.6.88.154", 60, null);
            api.Start();

            int dayCount = 0;
            for (DateTime startDate = start; startDate < end; startDate = startDate.AddDays(1))
            {
                List<AxiomObjects.Bar> bars = api.GetHistoricalBarSync(symbol, level, startDate, startDate.AddDays(1), interval);
                if (bars.Count <= 10)
                {
                    continue;
                }

                Trader Trader = new Trader
                {
                    CommissionFeeNTax = Convert.ToDecimal(0.0002),
                    CurrentMarket = "ANY",
                    TotalSequences = 6000,
                    name = "minute",
                    simulator = simulator,
                    seqSpan = TimeSpan.FromDays(1),
                    period = Periodicity.Minutely,
                    Start = startDate,
                    End = startDate.AddDays(1),
                };

                strategiesPortfolioTracker.Add(Trader.StrategiesMinutelyDayPeriodTrade(strategiesPortfolioTracker[dayCount], bars));

                dayCount++;
                string text = String.Format("{0} to {1} finished", startDate, startDate.AddDays(1));
                Console.WriteLine(text);
            }
            api.Stop();

            ////////
            ////////totalMoney
            StreamWriter performanceFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "StrategyPerformance.txt");
            string title = "Strategy1";
            for (int counter = 1; counter < numOfStrategies; counter++ )
            {
                title += " " + String.Format("Strategy{0}", counter+1);
            }
            performanceFile.WriteLine(title);
            for (int period = 0; period < strategiesPortfolioTracker.Count; period++)
            {
                string line = String.Join(" ", strategiesPortfolioTracker[period]);
                performanceFile.WriteLine(line.Trim());
            }
            performanceFile.Close();

            ////////
            ////////strategyReturn
            List<List<decimal>> strategiesReturn = Evaluator.StrategiesPerformanceReturn(strategiesPortfolioTracker);
            StreamWriter strategyReturnFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "StrategyReturn.txt");
            title = "Strategy1";
            for (int counter = 1; counter < numOfStrategies; counter++)
            {
                title += " " + String.Format("Strategy{0}", counter + 1);
            }
            strategyReturnFile.WriteLine(title);
            for (int period = 0; period < strategiesReturn.Count; period++ )
            {
                string line = String.Join(" ", strategiesReturn[period]);
                strategyReturnFile.WriteLine(line.Trim());
            }
            strategyReturnFile.Close();

            ////////
            ////////SharpRario
            List<decimal> strategiesSharpRatio = Evaluator.StrategiesPerformanceSharpRatio(strategiesPortfolioTracker);
            StreamWriter sharpRatioFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "SharpRatio.txt");
            for (int straIdx = 0; straIdx < numOfStrategies; straIdx++)
            {
                sharpRatioFile.WriteLine(String.Format("SharpRatio of Strategy {0}", straIdx + 1));
                sharpRatioFile.WriteLine(strategiesSharpRatio[straIdx].ToString());
            }
            sharpRatioFile.Close();
        }
    }
}