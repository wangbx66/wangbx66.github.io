﻿using Microsoft.MSR.CNTK.Extensibility.Managed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyEval
{
    public class ModelExecutor
    {
        public static List<List<float>> FloatPrecision(string modelFilePath, List<List<float>> marketInfo)
        {
            List<List<float>> modelPrediction = new List<List<float>>();

            try
            {
                /*using (var model = new IEvaluateModelManagedF())
                {
                    model.CreateNetwork(string.Format("modelPath=\"{0}\"", modelFilePath), -1);

                    foreach (List<float> period in marketInfo)
                    {
                        var inputs = new Dictionary<string, List<float>>();
                        inputs.Add("features", period);

                        List<float> outputs = new List<float>();
                        outputs = model.Evaluate(inputs, "activation");

                        modelPrediction.Add(outputs);
                    }
                }*/
                var model = new IEvaluateModelManagedF();

                model.CreateNetwork(string.Format("modelPath=\"{0}\"", modelFilePath), -1);

                foreach (List<float> period in marketInfo)
                {
                    var inputs = new Dictionary<string, List<float>>();
                    inputs.Add("features", period);

                    List<float> outputs = new List<float>();
                    outputs = model.Evaluate(inputs, "activation");

                    modelPrediction.Add(outputs);
                }

                model.Dispose();
            }
            catch (CNTKException ex)
            {
                Console.WriteLine("Error: {0}\nNative CallStack: {1}\n Inner Exception: {2}", ex.Message, ex.NativeCallStack, ex.InnerException != null ? ex.InnerException.Message : "No Inner Exception");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}\nCallStack: {1}\n Inner Exception: {2}", ex.Message, ex.StackTrace, ex.InnerException != null ? ex.InnerException.Message : "No Inner Exception");
            }

            return modelPrediction;
        }

        public static List<List<double>> DoublePrecision(string modelFilePath, List<List<double>> marketInfo)
        {
            List<List<double>> modelPrediction = new List<List<double>>();

            try
            {
                var model = new IEvaluateModelManagedD();

                model.CreateNetwork(string.Format("modelPath=\"{0}\"", modelFilePath), -1);

                foreach (List<double> period in marketInfo)
                {
                    var inputs = new Dictionary<string, List<double>>();
                    inputs.Add("features", period);

                    List<double> outputs = new List<double>();
                    outputs = model.Evaluate(inputs, "activation");

                    modelPrediction.Add(outputs);
                }

                model.Dispose();
            }
            catch (CNTKException ex)
            {
                Console.WriteLine("Error: {0}\nNative CallStack: {1}\n Inner Exception: {2}", ex.Message, ex.NativeCallStack, ex.InnerException != null ? ex.InnerException.Message : "No Inner Exception");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}\nCallStack: {1}\n Inner Exception: {2}", ex.Message, ex.StackTrace, ex.InnerException != null ? ex.InnerException.Message : "No Inner Exception");
            }

            return modelPrediction;
        }
    }
}
