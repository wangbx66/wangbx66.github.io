﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyEval
{
    class Evaluator
    {
        public static decimal ModelPerformanceSharpRatio(List<decimal> modelPortfolioTracker)
        {
            decimal sharpRatio = 0;
            List<decimal> returnList = new List<decimal>();
            for (int elementCount = 0; elementCount < modelPortfolioTracker.Count - 1; elementCount++)
            {
                returnList.Add((modelPortfolioTracker[elementCount + 1] - modelPortfolioTracker[elementCount]) / modelPortfolioTracker[elementCount]);
            }
            Tuple<decimal, decimal> t = MeanStd(returnList);
            if (t.Item2 == 0)
            {
                sharpRatio = 0;
            }
            else
            {
                sharpRatio = t.Item1 / t.Item2;
            }
            return sharpRatio;
        }

        public static List<decimal> StrategiesPerformanceSharpRatio(List<List<decimal>> strategiesPortfolioTracker)
        {
            List<decimal> strategiesSharpRatio = new List<decimal>();

            for (int idxStra = 0; idxStra < strategiesPortfolioTracker[0].Count; idxStra++)
            {
                decimal sharpRatio = 0;
                List<decimal> singleStrategyReturnList = new List<decimal>();
                for (int i = 0; i < strategiesPortfolioTracker.Count - 1; i++ )
                {
                    singleStrategyReturnList.Add((strategiesPortfolioTracker[i + 1][idxStra] - strategiesPortfolioTracker[i][idxStra]) / strategiesPortfolioTracker[i][idxStra]);
                }
                Tuple<decimal, decimal> t = MeanStd(singleStrategyReturnList);
                if (t.Item2 == 0)
                {
                    sharpRatio = 0;
                }
                else
                {
                    sharpRatio = t.Item1 / t.Item2;
                }
                strategiesSharpRatio.Add(sharpRatio);
            }

            return strategiesSharpRatio;
        }

        public static List<decimal> ModelPerformance_Return(List<decimal> modelPortfolioTracker)
        {
            List<decimal> modelReturn = new List<decimal>();
            for (int elementCount = 0; elementCount < modelPortfolioTracker.Count - 1; elementCount++)
            {
                modelReturn.Add((modelPortfolioTracker[elementCount + 1] - modelPortfolioTracker[elementCount]) / modelPortfolioTracker[elementCount]);
            }
            return modelReturn;
        }

        public static List<List<decimal>> StrategiesPerformanceReturn(List<List<decimal>> strategiesPortfolioTracker)
        {
            List<List<decimal>> strategiesPerformanceReturn = new List<List<decimal>>();
            for (int period = 0; period < strategiesPortfolioTracker.Count - 1; period++)
            {
                List<decimal> periodReturn = new List<decimal>();
                for (int idxStra = 0; idxStra < strategiesPortfolioTracker[period].Count; idxStra++)
                {
                    //periodReturn.Add((strategiesPortfolioTracker[period + 1][idxStra] - strategiesPortfolioTracker[period][idxStra]) / strategiesPortfolioTracker[period][idxStra] * 1000);
                    periodReturn.Add(Convert.ToDecimal((Math.Log(Convert.ToDouble(strategiesPortfolioTracker[period + 1][idxStra] / strategiesPortfolioTracker[period][idxStra])) * 1000)));
                }
                strategiesPerformanceReturn.Add(periodReturn);
            }
            return strategiesPerformanceReturn;
        }

        public static Tuple<decimal, decimal> MeanStd(List<decimal> valueList)
        {
            double M = 0.0;
            double S = 0.0;
            int k = 1;
            foreach (decimal value in valueList)
            {
                double tmpM = M;
                M += (Convert.ToDouble(value) - tmpM) / k;
                S += (Convert.ToDouble(value) - tmpM) * (Convert.ToDouble(value) - M);
                k++;
            }
            return Tuple.Create<decimal, decimal>(Convert.ToDecimal(M), Convert.ToDecimal(Math.Sqrt(S / (k - 2))));
        }
    }
}
