﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Text.RegularExpressions;

using ModulusFE.TASDK;

namespace TrainingDataDump
{
    public class DatasetDumper
    {
        public Simulator simulator;
        public TimeSpan seqSpan;
        public int interval = 2;

        public string name;
        public int TotalSequences = -1;
        public double CommissionFeeNTax = -1;
        public DateTime Start = new DateTime(2010, 1, 1, 8, 0, 0);
        public DateTime End = new DateTime(2015, 10, 31, 8, 0, 0);
        public string CurrentMarket = null;

        public void SingleSymbolData(string style = "cntk", string tradingSymbol = "")
        {
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            double minimumPriceGap = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "MinimumGap", "0.15"));
            double minimumVolume = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "MinimumVolume", "2e6"));
            int precision = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "Precision", "7"));
            double decay = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "Decay", "0.95"));
            int windowLength = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "WindowLength", "45"));
            int explorationLength = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            string mqServer = ConfigurationManager.AppSettings["MqServer"];
            ushort mqPort = Convert.ToUInt16(ConfigurationManager.AppSettings["MqPort"]);
            string mqUser = ConfigurationManager.AppSettings["MqUser"];
            string mqPassword = ConfigurationManager.AppSettings["MqPassword"];
            string requestQueue = ConfigurationManager.AppSettings["RequestQueue"];
            string httpServer = ConfigurationManager.AppSettings["DataStoreManagerIp"];
            ushort httpPort = Convert.ToUInt16(ConfigurationManager.AppSettings["DataStoreManagerPort"]);

            Dictionary<string, List<double>> globalStatistics = new Dictionary<string, List<double>>();
            StreamWriter networkOutputFileRaw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}-raw.pdat", style));
            StreamWriter statisticOutputFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + name + @"-data-statistic.txt");

            simulator.executors.Add(Simulator.Larry_AlterPos(CommissionFeeNTax, decay, windowLength, explorationLength, trailLength, interval, simulator));
            FeaturesSource featuresSource = new FeaturesSource();
            DataCleaner dataCleaner = new DataCleaner();
            BarsQualityChecker checker = new BarsQualityChecker();
            DataAPI.DataAPI api = new DataAPI.DataAPI(mqServer, mqPort, mqUser, mqPassword, requestQueue, httpServer, httpPort, null);
            api.Start();

            int idxSeq = 0;
            for (DateTime start = Start; start < End; start = start + seqSpan)
            {
                List<AxiomObjects.Bar> TradingSymbolBars = api.GetHistoricalBarSync(tradingSymbol, '1', start, start + seqSpan, interval);

                //rule out barList which less than minimumPeriods info
                //for value of minimumPeriods, please refer FilterSetting.ini
                string filterFile = AppDomain.CurrentDomain.BaseDirectory + @"FilterSetting.ini";
                int minimumPeriods = Convert.ToInt32(INIOperationClass.INIGetStringValue(filterFile, "infoFilter", "minimumPeriods", "30"));
                if (TradingSymbolBars == null || checker.minimumBarsRecord(TradingSymbolBars, minimumPeriods) || checker.minimumVolumn(TradingSymbolBars))
                {
                    continue;
                }
                if (style == "cntk" | style == "cntk-incre")
                {
                    networkOutputFileRaw.Write(idxSeq);
                }

                DateTime historicalStart = start - seqSpan;
                DateTime historicalEnd = start;
                do
                {
                    historicalStart = historicalStart - seqSpan;
                    historicalEnd = historicalEnd - seqSpan;
                } while (api.GetHistoricalBarSync(tradingSymbol, '1', historicalStart, historicalEnd, interval).Count <= minimumPeriods);
                List<AxiomObjects.Bar> historicalTradingSymbolBars = api.GetHistoricalBarSync(tradingSymbol, '1', historicalStart, historicalEnd, interval);

                List<AxiomObjects.Bar> twoDaySeq = dataCleaner.BarsListCombiner(TradingSymbolBars, historicalTradingSymbolBars);

                //data smothing
                //currently, method SmothData_test do nothing at all, should be developed in the future if keep position to next day
                dataCleaner.SmothData_test(twoDaySeq);

                //use Dictionary here in order to connect different features lists from different data source through datetime
                List<Dictionary<DateTime, List<double>>> timeDominFeaturesList = new List<Dictionary<DateTime, List<double>>>();
                timeDominFeaturesList.Add(featuresSource.TradeScript_Indicator(TradingSymbolBars, historicalTradingSymbolBars, twoDaySeq));

                List<List<double>> rawFeatures = TimeDominFeaturesConstructor(timeDominFeaturesList);
                List<string> features = dataCleaner.FeaturesList_ChangeToString(rawFeatures);

                //calculate profit
                Navigator DatabaseNavigator = PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
                List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
                dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
                DatabaseNavigator = PeriodicUtils.GetDatabaseNavigator(TradingSymbolBars);
                List<List<List<double>>> slidingWindowProfitsList = new List<List<List<double>>>();
                foreach (Simulator.Tracker executor in simulator.executors)
                {
                    slidingWindowProfitsList.Add(executor(DatabaseNavigator, tradeSignals, globalStatistics));
                }
                StrategyEvaluator.CorrelationAnalyse(tradeSignals, globalStatistics);

                //dump features and profits in the format according to different libraries requirements
                foreach (List<List<double>> slidingWindowProfits in slidingWindowProfitsList)
                {
                    int lineIdx = 0;
                    foreach (List<double> profits in slidingWindowProfits)
                    {
                        double bestProfit = profits.Max();
                        for (int i = 0; i < profits.Count; i++)
                        {
                            profits[i] = Math.Round(bestProfit - profits[i], precision) * 100;//realloss
                            //profits[i] = Math.Round(-profits[i], precision);
                        }
                        if (style == "spa")
                        {
                            networkOutputFileRaw.WriteLine(String.Join(" ", profits));
                        }
                        else if (style == "cntk")
                        {
                            string X = String.Join(" ", features[lineIdx]);
                            string Y = String.Join(" ", profits);
                            networkOutputFileRaw.WriteLine(String.Format(" |X {0} |Y {1}", X, Y));
                        }
                        lineIdx++;
                    }
                }

                idxSeq++;
                if (idxSeq == TotalSequences)
                {
                    break;
                }

                Console.WriteLine(String.Format("{0} to {1} has been finished", start, start.AddDays(1)));
            }

            api.Stop();
            Console.WriteLine("Total {0} Sequences", idxSeq);

            //statistic part
            statisticOutputFile.WriteLine("marketReturn = {0}", globalStatistics["totalMarketReturn"][0] / idxSeq);
            statisticOutputFile.WriteLine("PerfectPlay = {0}", globalStatistics["totalPerfectPlayReturn"][0] / idxSeq);
            for (int idxStra = 0; idxStra < globalStatistics["totalTrades"].Count; idxStra++)
            {
                statisticOutputFile.WriteLine("Strategy {0}", idxStra);
                statisticOutputFile.WriteLine("averageTrades = {0}", globalStatistics["totalTrades"][idxStra] / idxSeq);
                statisticOutputFile.WriteLine("averageStrategyReturn = {0}", globalStatistics["totalStrategyReturn"][idxStra] / idxSeq);
            }
            for (int idxStra1 = 0; idxStra1 < simulator.strategies.Count; idxStra1++)
            {
                statisticOutputFile.WriteLine("strategy {0} correlation", idxStra1);
                for (int idxStra2 = 0; idxStra2 < simulator.strategies.Count; idxStra2++)
                {
                    globalStatistics[String.Format("correlation {0}", idxStra1)][idxStra2] = Math.Abs(globalStatistics[String.Format("correlation {0}", idxStra1)][idxStra2]) / Convert.ToDouble(idxSeq);
                    statisticOutputFile.WriteLine("correlation w/ {0} = {1}", idxStra2, globalStatistics[String.Format("correlation {0}", idxStra1)][idxStra2]);
                }
                globalStatistics[String.Format("correlation {0}", idxStra1)].RemoveAt(idxStra1);
                statisticOutputFile.WriteLine("strategy {0} correlation total {1}", idxStra1, globalStatistics[String.Format("correlation {0}", idxStra1)].Average());
            }

            networkOutputFileRaw.Close();
            statisticOutputFile.Close();

            return;
        }

        public void MutiSymbolData(string style = "cntk", string tradingSymbol = "")
        {
            string iniFile = AppDomain.CurrentDomain.BaseDirectory + @"Strategy.ini";
            double minimumPriceGap = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "MinimumGap", "0.15"));
            double minimumVolume = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "MinimumVolume", "2e6"));
            int precision = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "Precision", "7"));
            double decay = Convert.ToDouble(INIOperationClass.INIGetStringValue(iniFile, name, "Decay", "0.95"));
            int windowLength = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "WindowLength", "45"));
            int explorationLength = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "ExplorationLength", "30"));
            int trailLength = Convert.ToInt32(INIOperationClass.INIGetStringValue(iniFile, name, "TrailLength", "0"));

            string mqServer = ConfigurationManager.AppSettings["MqServer"];
            ushort mqPort = Convert.ToUInt16(ConfigurationManager.AppSettings["MqPort"]);
            string mqUser = ConfigurationManager.AppSettings["MqUser"];
            string mqPassword = ConfigurationManager.AppSettings["MqPassword"];
            string requestQueue = ConfigurationManager.AppSettings["RequestQueue"];
            string httpServer = ConfigurationManager.AppSettings["DataStoreManagerIp"];
            ushort httpPort = Convert.ToUInt16(ConfigurationManager.AppSettings["DataStoreManagerPort"]);

            Dictionary<string, List<double>> globalStatistics = new Dictionary<string, List<double>>();
            StreamWriter networkOutputFileRaw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}-raw.pdat", style));
            StreamWriter statisticOutputFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + name + @"-data-statistic.txt");

            List<string> symbols = new List<string>();
            StreamReader symbolFile = new System.IO.StreamReader(@"..\..\..\..\SymbolsFile\" + tradingSymbol +"_RelatedSymbols");
            string line;
            while ((line = symbolFile.ReadLine()) != null)
            {
                line = line.Trim();
                symbols.Add(Regex.Split(line, " ")[0]);
            }
            symbolFile.Close();

            simulator.executors.Add(Simulator.Larry_AlterPos(CommissionFeeNTax, decay, windowLength, explorationLength, trailLength, interval, simulator));
            FeaturesSource featuresSource = new FeaturesSource();
            DataCleaner dataCleaner = new DataCleaner();
            BarsQualityChecker checker = new BarsQualityChecker();
            DataAPI.DataAPI api = new DataAPI.DataAPI(mqServer, mqPort, mqUser, mqPassword, requestQueue, httpServer, httpPort, null);
            api.Start();

            int idxSeq = 0;
            for (DateTime start = Start; start < End; start = start + seqSpan)
            {
                foreach (string symbol in symbols)
                {
                    if (idxSeq == TotalSequences)
                    {
                        break;
                    }

                    List<AxiomObjects.Bar> TradingSymbolBars = api.GetHistoricalBarSync(symbol, '1', start, start + seqSpan, interval);

                    //rule out barList which less than minimumPeriods info
                    //for value of minimumPeriods, please refer SystemSetting.ini
                    string filterFile = AppDomain.CurrentDomain.BaseDirectory + @"FilterSetting.ini";
                    int minimumPeriods = Convert.ToInt32(INIOperationClass.INIGetStringValue(filterFile, "infoFilter", "minimumPeriods", "30"));
                    if (TradingSymbolBars == null || checker.minimumBarsRecord(TradingSymbolBars, minimumPeriods) || checker.minimumVolumn(TradingSymbolBars))
                    {
                        continue;
                    }
                    if (style == "cntk" | style == "cntk-incre")
                    {
                        networkOutputFileRaw.Write(idxSeq);
                    }

                    DateTime historicalStart = start - seqSpan;
                    DateTime historicalEnd = start;
                    do
                    {
                        historicalStart = historicalStart - seqSpan;
                        historicalEnd = historicalEnd - seqSpan;
                    } while (api.GetHistoricalBarSync(tradingSymbol, '1', historicalStart, historicalEnd, interval).Count <= minimumPeriods);
                    List<AxiomObjects.Bar> historicalTradingSymbolBars = api.GetHistoricalBarSync(tradingSymbol, '1', historicalStart, historicalEnd, interval);

                    List<AxiomObjects.Bar> twoDaySeq = dataCleaner.BarsListCombiner(TradingSymbolBars, historicalTradingSymbolBars);

                    //data smothing
                    //currently, method SmothData_test do nothing at all, should be developed in the future if keep position to next day
                    dataCleaner.SmothData_test(twoDaySeq);

                    //use Dictionary here in order to connect different features lists from different data source through datetime
                    List<Dictionary<DateTime, List<double>>> timeDominFeaturesList = new List<Dictionary<DateTime, List<double>>>();
                    timeDominFeaturesList.Add(featuresSource.TradeScript_Indicator(TradingSymbolBars, historicalTradingSymbolBars, twoDaySeq));

                    List<List<double>> rawFeatures = TimeDominFeaturesConstructor(timeDominFeaturesList);
                    List<string> features = dataCleaner.FeaturesList_ChangeToString(rawFeatures);

                    //calculate profit
                    Navigator DatabaseNavigator = PeriodicUtils.GetDatabaseNavigator(twoDaySeq);
                    List<int[]> tradeSignals = simulator.GetTradeSignals(DatabaseNavigator);
                    dataCleaner.RemoveHistoricalTradeSignals(tradeSignals, historicalTradingSymbolBars);
                    DatabaseNavigator = PeriodicUtils.GetDatabaseNavigator(TradingSymbolBars);
                    List<List<List<double>>> slidingWindowProfitsList = new List<List<List<double>>>();
                    foreach (Simulator.Tracker executor in simulator.executors)
                    {
                        slidingWindowProfitsList.Add(executor(DatabaseNavigator, tradeSignals, globalStatistics));
                    }
                    StrategyEvaluator.CorrelationAnalyse(tradeSignals, globalStatistics);

                    //dump features and profits in the format according to different libraries requirements
                    foreach (List<List<double>> slidingWindowProfits in slidingWindowProfitsList)
                    {
                        int lineIdx = 0;
                        foreach (List<double> profits in slidingWindowProfits)
                        {
                            double bestProfit = profits.Max();
                            for (int i = 0; i < profits.Count; i++)
                            {
                                profits[i] = Math.Round(bestProfit - profits[i], precision) * 100;//realloss
                                //profits[i] = Math.Round(-profits[i], precision);
                            }
                            if (style == "spa")
                            {
                                networkOutputFileRaw.WriteLine(String.Join(" ", profits));
                            }
                            else if (style == "cntk")
                            {
                                string X = String.Join(" ", features[lineIdx]);
                                string Y = String.Join(" ", profits);
                                networkOutputFileRaw.WriteLine(String.Format(" |X {0} |Y {1}", X, Y));
                            }
                            lineIdx++;
                        }
                    }

                    idxSeq++;
                }
                Console.WriteLine(String.Format("{0} to {1} has been finished", start, start.AddDays(1)));
            }

            api.Stop();
            Console.WriteLine("Total {0} Sequences", idxSeq);

            //statistic part
            statisticOutputFile.WriteLine("marketReturn = {0}", globalStatistics["totalMarketReturn"][0] / idxSeq);
            statisticOutputFile.WriteLine("PerfectPlay = {0}", globalStatistics["totalPerfectPlayReturn"][0] / idxSeq);
            for (int idxStra = 0; idxStra < globalStatistics["totalTrades"].Count; idxStra++)
            {
                statisticOutputFile.WriteLine("Strategy {0}", idxStra);
                statisticOutputFile.WriteLine("averageTrades = {0}", globalStatistics["totalTrades"][idxStra] / idxSeq);
                statisticOutputFile.WriteLine("averageStrategyReturn = {0}", globalStatistics["totalStrategyReturn"][idxStra] / idxSeq);
            }
            for (int idxStra1 = 0; idxStra1 < simulator.strategies.Count; idxStra1++)
            {
                statisticOutputFile.WriteLine("strategy {0} correlation", idxStra1);
                for (int idxStra2 = 0; idxStra2 < simulator.strategies.Count; idxStra2++)
                {
                    globalStatistics[String.Format("correlation {0}", idxStra1)][idxStra2] = Math.Abs(globalStatistics[String.Format("correlation {0}", idxStra1)][idxStra2]) / Convert.ToDouble(idxSeq);
                    statisticOutputFile.WriteLine("correlation w/ {0} = {1}", idxStra2, globalStatistics[String.Format("correlation {0}", idxStra1)][idxStra2]);
                }
                globalStatistics[String.Format("correlation {0}", idxStra1)].RemoveAt(idxStra1);
                statisticOutputFile.WriteLine("strategy {0} correlation total {1}", idxStra1, globalStatistics[String.Format("correlation {0}", idxStra1)].Average());
            }

            networkOutputFileRaw.Close();
            statisticOutputFile.Close();

            return;
        }

        public void TrainingDatasetNormalize(string style = "cntk", int sampleCap = 30000)
        {
            Console.WriteLine("Normalizing dataset for {0}", style);
            StreamReader networkOutputFileRaw = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}-raw.pdat", style));

            int NFeatures = 0;
            int NStrategies = 0;
            string line;
            bool once = true;
            int cnt = 0;
            List<List<double>> features = new List<List<double>>();
            List<List<double>> strategies = new List<List<double>>();
            string[] c;
            //while ((line = networkOutputFileRaw.ReadLine()) != null && cnt < sampleCap)
            while ((line = networkOutputFileRaw.ReadLine()) != null)
            {
                if (line.Trim() == "")
                {
                    continue;
                }
                cnt++;
                if (once)
                {
                    c = line.Split('|');
                    foreach (string s in c)
                    {
                        string z = s.Trim();
                        string[] p = z.Split(' ');
                        if (z.StartsWith("X"))
                        {
                            NFeatures = p.Length - 1;//identifier X itself
                        }
                        else if (z.StartsWith("Y"))
                        {
                            NStrategies = p.Length - 1;//identifier Y itself
                        }
                    }
                    once = false;
                }

                c = line.Split('|');
                string[] x = c[1].Trim().Split(' ');
                string[] y = c[2].Trim().Split(' ');

                for (int i = 1; i < x.Length; i++)
                {
                    if (i > features.Count)
                    {
                        features.Add(new List<double>());
                    }
                    features[i - 1].Add(Convert.ToDouble(x[i]));
                }

                for (int i = 1; i < y.Length; i++)
                {
                    //if (i >= strategies.Count)
                    if (i > strategies.Count)
                    {
                        strategies.Add(new List<double>());
                    }
                    strategies[i - 1].Add(Convert.ToDouble(y[i]));
                }

            }

            StreamWriter meanStdFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "MeanStd.txt");
            List<double> meanx = new List<double>(new double[features.Count]);
            List<double> stdx = new List<double>(new double[features.Count]);
            List<double> numOfx = new List<double>(new double[features.Count]);
            List<double> meany = new List<double>(new double[strategies.Count]);
            List<double> stdy = new List<double>(new double[strategies.Count]);
            for (int i = 0; i < features.Count; i++)
            {
                Tuple<double, double, double> t = MeanStd(features[i]);
                meanx[i] = t.Item1;
                stdx[i] = t.Item2;
                numOfx[i] = t.Item3;
            }
            for (int i = 0; i < strategies.Count; i++)
            {
                Tuple<double, double, double> t = MeanStd(strategies[i]);
                meany[i] = t.Item1;
                stdy[i] = t.Item2;
            }
            meanStdFile.WriteLine(String.Join(" ", meanx));
            meanStdFile.WriteLine(String.Join(" ", stdx));
            meanStdFile.WriteLine(String.Join(" ", numOfx));
            meanStdFile.Close();

            double[] xprime = new double[features.Count];
            double[] yprime = new double[strategies.Count];
            string lineprime;
            networkOutputFileRaw = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}-raw.pdat", style));
            StreamWriter networkOutputFile = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + name + String.Format(@"-data-{0}.pdat", style));
            int my_flag = 0;
            while ((line = networkOutputFileRaw.ReadLine()) != null)
            {
                my_flag++;
                if (line.Trim() == "")
                {
                    continue;
                }
                c = line.Split('|');
                string[] x = c[1].Trim().Split(' ');
                string[] y = c[2].Trim().Split(' ');

                for (int i = 1; i < x.Length; i++)
                {
                    if (stdx[i - 1] == 0)
                    {
                        xprime[i - 1] = 0;
                        continue;
                    }
                    xprime[i - 1] = (Convert.ToDouble(x[i]) - meanx[i - 1]) / stdx[i - 1];
                    //yprime[i - 1] = (Convert.ToDouble(y[i]) - meany[i - 1]) / stdy[i - 1];
                }

                for (int i = 1; i < y.Length; i++)
                {
                    if (stdy[i - 1] == 0)
                    {
                        yprime[i - 1] = 0;
                    }
                    yprime[i - 1] = (Convert.ToDouble(y[i]) - meany[i - 1]) / stdy[i - 1];
                }

                lineprime = c[0] + "|X " + String.Join<double>(" ", xprime) + " |" + c[2];
                networkOutputFile.WriteLine(lineprime);
            }

            networkOutputFile.Close();
        }

        public List<List<double>> TimeDominFeaturesConstructor(List<Dictionary<DateTime, List<double>>> timeDominFeaturesList)
        {
            List<List<double>> rawFeatures = new List<List<double>>();
            List<List<double>> features = new List<List<double>>();
            DataCleaner dataCleaner = new DataCleaner();

            //remove bad dictionary which contains less than minimumPeriods information
            //for minimumPeriods value, please refer to SystemSetting.ini
            string filterFile = AppDomain.CurrentDomain.BaseDirectory + @"FilterSetting.ini";
            int minimumPeriods = Convert.ToInt32(INIOperationClass.INIGetStringValue(filterFile, "infoFilter", "minimumPeriods", "30"));
            for (int rawSourceIdx = 0; rawSourceIdx < timeDominFeaturesList.Count; rawSourceIdx++)
            {
                if (timeDominFeaturesList[rawSourceIdx].Count < minimumPeriods)
                {
                    timeDominFeaturesList.RemoveAt(rawSourceIdx);
                }
            }

            int numOfFeaturesSource = timeDominFeaturesList.Count;

            if (numOfFeaturesSource == 1)
            {
                foreach(var item in timeDominFeaturesList[0])
                {
                    rawFeatures.Add(item.Value);
                }

                //features = rawFeatures;
                features = dataCleaner.RemoveAbsoluteValue(rawFeatures);
            }
            else if (numOfFeaturesSource > 1)
            {
                Dictionary<DateTime, List<double>> baseTable = timeDominFeaturesList[0];
                foreach (var item in baseTable)
                {
                    for (int sourceIdx = 1; sourceIdx < numOfFeaturesSource; sourceIdx++)
                    {
                        if (!timeDominFeaturesList[sourceIdx].ContainsKey(item.Key))
                        {
                            List<DateTime> dictionaryKey = new List<DateTime>(timeDominFeaturesList[sourceIdx].Keys);
                            List<double> zeroList = new List<double>(new double[timeDominFeaturesList[sourceIdx][dictionaryKey[0]].Count]);
                            item.Value.AddRange(zeroList);
                        }
                        else
                        {
                            item.Value.AddRange(timeDominFeaturesList[sourceIdx][item.Key]);
                        }
                    }

                    rawFeatures.Add(item.Value);
                }

                //features = rawFeatures;
                features = dataCleaner.RemoveAbsoluteValue(rawFeatures);
            }

            return features;
        }

        public static Tuple<double, double, double> MeanStd(List<double> valueList)
        {
            double M = 0.0;
            double S = 0.0;
            int k = 1;
            foreach (double value in valueList)
            {
                double tmpM = M;
                M += (value - tmpM) / k;
                S += (value - tmpM) * (value - M);
                k++;
            }
            return Tuple.Create<double, double, double>(M, Math.Sqrt(S / (k - 2)), k);
        }
    }
}
