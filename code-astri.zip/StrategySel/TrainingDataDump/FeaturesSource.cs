﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;

using AxiomObjects;
using ModulusFE.TASDK;
using Modulus.TradeScript;

namespace TrainingDataDump
{
    public class FeaturesSource
    {
        public FeaturesSource()
        {
            ;
        }

        public Dictionary<DateTime, List<double>> TradeScript_Indicator(List<AxiomObjects.Bar> tradingBars, List<AxiomObjects.Bar> historicalTradingSymbolBars, List<AxiomObjects.Bar> twoDaySeq)
        {
            Dictionary<DateTime, List<double>> featuresList = new Dictionary<DateTime, List<double>>();
            string feature;
            string featureString = " ";
            int featureIdx = 0;
            StreamReader featuresReader = new StreamReader(@"..\..\..\..\FeaturesFile\TradeScriptFeatures");
            while ((feature = featuresReader.ReadLine()) != null)
            {
                if (featureIdx == 0)
                {
                    featureString = feature.Trim();
                    featureIdx++;
                }
                else
                {
                    featureString = featureString + " + " + feature.Trim();
                }
            }

            try 
            {
                ScriptOutput o = new ScriptOutput();
                o.License = "XRT93NQR79ABTW788XR48";

                foreach (Bar bar in twoDaySeq)
                {
                    o.AppendRecord(bar.Time,
                        Convert.ToDouble(bar.Open), Convert.ToDouble(bar.High), Convert.ToDouble(bar.Low), Convert.ToDouble(bar.Close),
                        Convert.ToInt64(bar.Volume));
                }

                List<TaSdkField> fields = new List<TaSdkField>(o.GetScriptOutput(featureString.Trim()));
                for (int i = historicalTradingSymbolBars.Count; i < fields.First().Data.Count; i++)
                {
                    List<double> line = new List<double>();
                    for (int j = 1; j < fields.Count(); j++)
                    {
                        if (Double.IsNaN(fields[j][i]))
                        {
                            line.Add(0);
                        }
                        else
                        {
                            line.Add(fields[j][i]);
                        }
                    }

                    featuresList.Add(twoDaySeq[i].Time, line);
                }
            }
            catch (Exception ex)
            {
                Log.debug(MethodBase.GetCurrentMethod() + " Exception: " + ex);
            }

            return featuresList;
        }
    }
}
