﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingDataDump
{
    public class BarsQualityChecker
    {
        public BarsQualityChecker()
        {
            ;
        }

        public bool minimumBarsRecord(List<AxiomObjects.Bar> tradingBars, int minimumPeriods)
        {
            if (tradingBars.Count <= minimumPeriods)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool minimumVolumn(List<AxiomObjects.Bar> tradingBars)
        {
            double length = tradingBars.Count;
            int fifthLength = Convert.ToInt32(Math.Ceiling((length / 5)));
            int volumnBarsCount = 0;
            for (int period = 0; period < tradingBars.Count; period++)
            {
                if (tradingBars[period].Volume == 0)
                {
                    volumnBarsCount++;
                }
            }

            if (volumnBarsCount >= fifthLength)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
