﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AxiomObjects;
using System.Reflection;

namespace TrainingDataDump
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                MinuteInterval("600135-SSE");
            }
            catch(Exception ex)
            {
                Log.debug(MethodBase.GetCurrentMethod() + " Exception: " + ex);
            }
        }

        static void MinuteInterval(string symbol = "")
        {
            int maxStrategiesNum = 15;

            Simulator simulator = new Simulator();
            //simulator.LoadDefault();
            StrategiesReader strategyReader = new StrategiesReader();
            strategyReader.csvStrategiesLoader(simulator, maxStrategiesNum);

            DatasetDumper dumper = new DatasetDumper
            {
                CommissionFeeNTax = 0.003,
                CurrentMarket = "ANY",
                TotalSequences = 6000,
                name = "minute",
                seqSpan = TimeSpan.FromDays(1),
                simulator = simulator,
                interval = 1,

                Start = new DateTime(2016, 5, 1, 8, 0, 0),
                End = new DateTime(2016, 6, 1, 8, 0, 0),
            };

            dumper.SingleSymbolData("cntk", symbol);
            //dumper.MutiSymbolData("cntk", symbol);
            dumper.TrainingDatasetNormalize("cntk");
        }
    }
}
