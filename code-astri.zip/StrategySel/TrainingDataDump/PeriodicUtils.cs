﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

//using CommonObjects;

using ModulusFE.TASDK;
using ModulusFE;

namespace TrainingDataDump
{
    public class PeriodicUtils
    {

        // Period utils are mainly used for periodic e.g. minute-interval and day-interval, trading. It handles objects "Bar" exist in CommonObjects w/o order book information.

        /*
         * DumpOutputString: Get a string in human-understandable vector representation of the input list of bars
         * GetDatabaseNavigator: Convert list of bars into a TASDK compatible object
         * PreprocessBar: Embed a bar into vector space
        */

        public delegate List<Decimal> BarPreProcessor(Decimal Open, Decimal High, Decimal Low, Decimal Close, long Volume, Decimal previousClose, int precision);

        public static String DumpOutputString(List<AxiomObjects.Bar> bars, int precision, double minimumVolume, double minimumPriceGap, BarPreProcessor barPreprocessor, List<double> additionalInfo)
        {
            // Will return empty string if this being a bad bar
            StringBuilder outputString = new StringBuilder("");
            List<double> volumes = new List<double>(new double[bars.Count]);
            List<Decimal> closes = new List<Decimal>(new Decimal[bars.Count]);
            
            Decimal previousClose = 0;
            foreach (AxiomObjects.Bar bar in bars)
            {
                volumes.Add(bar.Volume);
                closes.Add(bar.Close);
                if (previousClose == 0)
                {
                    previousClose = bar.Close;
                }
                List <Decimal> barInfo = barPreprocessor(bar.Open, bar.High, bar.Low, bar.Close, bar.Volume, previousClose, precision);

                outputString.Append(String.Join<Decimal>(" ", barInfo) + " ");
                if (additionalInfo.Count > 0)
                {
                    outputString.Append(String.Join<double>(" ", additionalInfo) + " ");
                }
                previousClose = bar.Close;
            }

            // We should filter out inactive stocks. It's now judged by thresholding the total volume and the largest price gap. This filter is specified for minute-interval trading w/ classic bars
            if (volumes.Sum() < minimumVolume || Math.Abs(closes.Max() - closes.Min()) < Convert.ToDecimal(minimumPriceGap))
            {
                outputString = new StringBuilder("");
            }
            if (!(outputString.ToString() == ""))
            {
                outputString.Remove(outputString.Length - 1, 1);
                //outputString.Remove(outputString.Length - 1);
            }
            return outputString.ToString();
        }

        public static Navigator GetDatabaseNavigator(List<AxiomObjects.Bar> bars)
        {
            Navigator DBNavigator;
            Recordset DBRecordSet = new Recordset();
            
            Field Open = new Field(bars.Count, "Open");
            Field High = new Field(bars.Count, "High");
            Field Low = new Field(bars.Count, "Low");
            Field Close = new Field(bars.Count, "Close");
            Field Volume = new Field(bars.Count, "Volume");
            // The field DateTime is only to feed ZScript 
            Field DateTime = new Field(bars.Count, "DateTime");

            // When using minute-inerval data, we have 240 bars/day (Originally 241 bars/day from GTADatabaseStock, but the 240-th bar was always with a zero volume and was hence removed by PeriodicDBLoader). The first bar usually starts at 9:30am. High and Low etc. of each bar is the high or low within the minute and are usually very close to the close price.
            // For volume information which scales unbounded, to normalize it to mostly in (-1,1) region, I take the logarithmic value of it here. When there's no volume, other dimensions should be forced to be zeros, if not already zeros (see PreprocessBar).
            int idxBar = 0;
            foreach (AxiomObjects.Bar bar in bars)
            {
                // IMPORTANT: For fields construction, index should be from 1.
                idxBar++;

                Open.Value(idxBar, Convert.ToDouble(bar.Open));
                High.Value(idxBar, Convert.ToDouble(bar.High));
                Low.Value(idxBar, Convert.ToDouble(bar.Low));
                Close.Value(idxBar, Convert.ToDouble(bar.Close));
                Volume.Value(idxBar, bar.Volume);
                //DateTime.Value(idxBar, bar.Date.Ticks);
                DateTime.Value(idxBar, bar.Time.Ticks);
            }
            
            DBRecordSet.AddField(Open);
            DBRecordSet.AddField(High);
            DBRecordSet.AddField(Low);
            DBRecordSet.AddField(Close);
            DBRecordSet.AddField(Volume);
            DBRecordSet.AddField(DateTime);
            
            DBNavigator = new Navigator();
            DBNavigator.Recordset_ = DBRecordSet;
            return DBNavigator;
        }

        public static Decimal RelativePrice(Decimal number, Decimal standard, int precision)
        {
            return Math.Round((number - standard) / standard, precision);
        }

        // The function PreprocessBar are used both when the training dataset is being dumped and when testing data is fed into the prediction model. The back-end system should use exact output of outputString.

        public static BarPreProcessor PreprocessBar = delegate(Decimal open, Decimal high, Decimal low, Decimal close, long volume, Decimal previousClose, int precision)
        {
            List<Decimal> networkInput = new List<Decimal>(new Decimal[3]);

            if (!(close > 0) || !(previousClose > 0))
            {
                return networkInput;
            }

            if (volume == 0)
            {
                if (!(close == previousClose) || !(close == high) || !(close == open) || !(close == low))
                {
                    return networkInput;
                }
            }

            networkInput[0] = Math.Round((high - low) / close, precision) * 250;
            networkInput[1] = RelativePrice(close, previousClose, precision) * 750;
            networkInput[2] = Convert.ToDecimal((Math.Log(Convert.ToDouble(volume + 1))) / 3.5);
            return networkInput;
        };

        public static BarPreProcessor PreprocessBar5 = delegate (Decimal open, Decimal high, Decimal low, Decimal close, long volume, Decimal previousClose, int precision)
        {
            List<Decimal> networkInput = new List<Decimal>(new Decimal[5]);

            if (!(close > 0) || !(previousClose > 0))
            {
                return networkInput;
            }

            networkInput[0] = Math.Round((high - close) / close, precision) * 250;
            networkInput[1] = Math.Round((close - low) / close, precision) * 250;
            networkInput[2] = Math.Round((close - open) / close, precision) * 250;
            networkInput[3] = RelativePrice(close, previousClose, precision) * 750;
            networkInput[4] = Convert.ToDecimal((Math.Log(Convert.ToDouble(volume + 1))) / 3.5);
            return networkInput;
        };
    }
}
