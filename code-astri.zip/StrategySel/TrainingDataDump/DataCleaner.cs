﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AxiomObjects;

namespace TrainingDataDump
{
    public class DataCleaner
    {
        public DataCleaner()
        {
            ;
        }

        public double RelativePrice(double number, double standard, int precision)
        {
            return Math.Round((number - standard) / standard, precision);
        }

        public List<List<double>> RemoveAbsoluteValue(List<List<double>> features)
        {
            //remove absolute value
            int numOfFeatures = features[0].Count;
            for (int period = features.Count - 1; period >= 0; period--)
            {
                if (period == 0)
                {
                    for (int featureIdx = 0; featureIdx < numOfFeatures; featureIdx++)
                    {
                        features[period][featureIdx] = 0;
                    }
                    break;
                }
                else
                {
                    /*
                    for (int featureIdx = 0; featureIdx < numOfFeatures; featureIdx++)
                    {
                        double denominator;
                        if (features[period - 1][featureIdx] == -1)
                        {
                            denominator = 1;
                        }
                        else
                        {
                            denominator = features[period - 1][featureIdx] + 1;
                        }
                        features[period][featureIdx] = (features[period][featureIdx] - features[period - 1][featureIdx]) / denominator;
                    }
                    */

                    double bxIndex_Zero = Math.Round((features[period][1] - features[period][3]) / features[period][3], 7);
                    double bxIndex_One = Math.Round((features[period][3] - features[period][2]) / features[period][3], 7);
                    double bxIndex_Two = Math.Round((features[period][3] - features[period][0]) / features[period][3], 7);
                    double bxIndex_Three = RelativePrice(features[period][3], features[period - 1][3], 7);
                    double bxIndex_Four = Math.Log(features[period][4] + 1) / 3.5;

                    features[period][0] = bxIndex_Zero;
                    features[period][1] = bxIndex_One;
                    features[period][2] = bxIndex_Two;
                    features[period][3] = bxIndex_Three;
                    features[period][4] = bxIndex_Four;
                }
            }

            return features;
        }

        public List<AxiomObjects.Bar> BarsListCombiner(List<AxiomObjects.Bar> tradingSymbolBars, List<AxiomObjects.Bar> historicalTradingSymbolBars)
        {
            List<AxiomObjects.Bar> twoDaySeq = new List<AxiomObjects.Bar>();

            foreach (Bar period in historicalTradingSymbolBars)
            {
                twoDaySeq.Add(period);
            }

            foreach (Bar period in tradingSymbolBars)
            {
                twoDaySeq.Add(period);
            }

            return twoDaySeq;
        }

        public void RemoveHistoricalTradeSignals(List<int[]> tradeSignals, List<AxiomObjects.Bar> historicalTradingSymbolBars)
        {
            for (int straIdx = 0; straIdx < tradeSignals.Count; straIdx++)
            {
                tradeSignals[straIdx] = tradeSignals[straIdx].Skip(historicalTradingSymbolBars.Count).ToArray();
            }
        }

        public List<string> FeaturesList_ChangeToString(List<List<double>> featuresList)
        {
            List<string> features = new List<string>();

            for (int period = 0; period < featuresList.Count; period++)
            {
                string line = String.Join(" ", featuresList[period]);
                features.Add(line);
            }

            return features;
        }

        public List<List<float>> FeaturesList_ChangeToFloat(List<List<double>> featuresList)
        {
            List<List<float>> target = new List<List<float>>();
            for (int i = 0; i < featuresList.Count; i++)
            {
                List<float> line = new List<float>();
                for (int j = 0; j < featuresList[i].Count; j++)
                {
                    line.Add((float)featuresList[i][j]);
                }
                target.Add(line);
            }
            return target;
        }

        public void SmothData_test(List<AxiomObjects.Bar> tradingSymbolBars)
        {
            ;
        }
    }
}
