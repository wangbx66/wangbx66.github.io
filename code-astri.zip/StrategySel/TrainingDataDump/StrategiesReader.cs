﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TrainingDataDump
{
    public class StrategiesReader
    {
        public StrategiesReader()
        {
            ;
        }

        public void LongOnly(Simulator simulator)
        {
            string path = @"..\..\..\..\StrategiesSets";
            var files = Directory.GetFiles(path, "*.txt");

            simulator.strategies.Add(BuildinStrategies.WiselySleeping());
            simulator.takeProfitNStopLoss.Add(new double[4] { 0, 0, 0, 0});

            foreach (var file in files)
            {
                StreamReader strategy = new StreamReader(file);
                int rowIdx = 0;
                string line;
                string buyScript = "LOW>HIGH";
                string sellScript = "LOW>HIGH";
                string exitLong = "LOW>HIGH";
                string exitShort = "LOW>HIGH";
                double longTakeProfit = 100;
                double longStopLoss = 100;
                double shortTakeProfit = 100;
                double shortStopLoss = 100;

                while ((line = strategy.ReadLine()) != null)
                {
                    if (rowIdx == 0)
                    {
                        buyScript = line.Trim();
                        rowIdx++;
                    }
                    else if (rowIdx == 1)
                    {
                        sellScript = line.Trim();
                        rowIdx++;
                    }
                    else if (rowIdx == 2)
                    {
                        longTakeProfit = Convert.ToDouble(line.Trim());
                        rowIdx++;
                    }
                    else if (rowIdx == 3)
                    {
                        longStopLoss = Convert.ToDouble(line.Trim());
                        rowIdx++;
                    }
                }

                simulator.strategies.Add(BuildinStrategies.ZScript(buyScript, sellScript, exitLong, exitShort));
                simulator.takeProfitNStopLoss.Add(new double[4] { longTakeProfit, longStopLoss, shortTakeProfit, shortStopLoss });
            }
        }

        public void csvStrategiesLoader(Simulator simulator, int maxStrategiesNum)
        {
            simulator.strategies.Add(BuildinStrategies.WiselySleeping());
            simulator.takeProfitNStopLoss.Add(new double[4] { 0, 0, 0, 0 });

            string strategiesFile = @"..\..\..\..\Strategies\2016-11-16_strategies.csv";
            var data = File.ReadAllLines(strategiesFile).Skip(1);

            int totalStrategieCount = 0;
            foreach (string line in data)
            {
                if (totalStrategieCount > maxStrategiesNum - 1)
                {
                    break;
                }

                var values = line.Split(',');
                string buyScript = values[1].Trim();
                string sellScript = values[2].Trim();
                string exitLong = values[3].Trim();
                string exitShort = values[4].Trim();
                double longTakeProfit = Convert.ToDouble(values[5].Trim());
                double longStopLoss = Convert.ToDouble(values[6].Trim());
                double shortTakeProfit = Convert.ToDouble(values[7].Trim());
                double shortStopLoss = Convert.ToDouble(values[8].Trim());

                buyScript = buyScript.Replace(";", ",");
                sellScript = sellScript.Replace(";", ",");
                exitLong = exitLong.Replace(";", ",");
                exitShort = exitShort.Replace(";", ",");

                simulator.strategies.Add(BuildinStrategies.ZScript(buyScript, sellScript, exitLong, exitShort));
                simulator.takeProfitNStopLoss.Add(new double[4] { longTakeProfit, longStopLoss, shortTakeProfit, shortStopLoss });

                totalStrategieCount++;
            }
        }
    }
}
