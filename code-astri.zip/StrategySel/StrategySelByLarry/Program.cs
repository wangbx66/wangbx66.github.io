﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using AxiomObjects;
using System.Reflection;

namespace StrategySelByLarry
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DataAPIMinuteInterval();
            }
            catch (Exception ex)
            {
                Log.debug(MethodBase.GetCurrentMethod() + " Exception: " + ex);
                //throw;
            }
        }

        static void DataAPIMinuteInterval()
        {
            Simulator simulator = new Simulator();
            StrategiesReader strategyReader = new StrategiesReader();
            //simulator.LoadDefault();
            strategyReader.LongOnly(simulator);

            DataAPIDumper dumper = new DataAPIDumper
            {
                CommissionFeeNTax = 0.0002,
                CurrentMarket = "ANY",
                TotalSequences = 6000,
                name = "minute",
                seqSpan = TimeSpan.FromDays(1),
                simulator = simulator,
                interval = 1,

                Start = new DateTime(2014, 1, 1, 8, 0, 0),
                End = new DateTime(2015, 1, 1, 8, 0, 0),
                //Start = globalStartDate,
                //End = globalEndDate, 
            };

            //dumper.TrainingDatasetDump_ExData("cntk");
            dumper.TrainingDatasetDump_MultiData("cntk", "600623-SSE");
            dumper.TrainingDatasetNormalize("cntk");
        }
    }
}
