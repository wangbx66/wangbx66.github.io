﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace StrategySelByLarry
{
    public class StrategiesReader
    {
        public StrategiesReader()
        {
            ;
        }

        public void LongOnly(Simulator simulator)
        {
            string path = @"..\..\..\..\StrategiesSets";
            var files = Directory.GetFiles(path, "*.txt");

            simulator.strategies.Add(BuildinStrategies.WiselySleeping());
            simulator.takeProfitNStopLoss.Add(new double[4] { 0, 0, 0, 0});

            foreach (var file in files)
            {
                StreamReader strategy = new StreamReader(file);
                int rowIdx = 0;
                string line;
                string buyScript = "LOW>HIGH";
                string sellScript = "LOW>HIGH";
                string exitLong = "LOW>HIGH";
                string exitShort = "LOW>HIGH";
                double longTakeProfit = 100;
                double longStopLoss = 100;
                double shortTakeProfit = 100;
                double shortStopLoss = 100;

                while ((line = strategy.ReadLine()) != null)
                {
                    if (rowIdx == 0)
                    {
                        buyScript = line.Trim();
                        rowIdx++;
                    }
                    else if (rowIdx == 1)
                    {
                        sellScript = line.Trim();
                        rowIdx++;
                    }
                    else if (rowIdx == 2)
                    {
                        longTakeProfit = Convert.ToDouble(line.Trim());
                        rowIdx++;
                    }
                    else if (rowIdx == 3)
                    {
                        longStopLoss = Convert.ToDouble(line.Trim());
                        rowIdx++;
                    }
                }

                simulator.strategies.Add(BuildinStrategies.ZScript(buyScript, sellScript, exitLong, exitShort));
                simulator.takeProfitNStopLoss.Add(new double[4] { longTakeProfit, longStopLoss, shortTakeProfit, shortStopLoss });
            }
        }
    }
}
