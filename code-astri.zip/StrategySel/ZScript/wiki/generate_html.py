import re
import os
alpha = re.compile('[^0-9a-zA-Z ]')
blk = re.compile(' +')

def ascii(s):
    tmp = alpha.sub('', s)
    return blk.sub(' ', tmp.strip())

with open('outs', 'w') as fw, open('contents') as fp:
    fw.write('<!-- Generating Sidebar Navigation -->\n\n')
    fw.write('<ul class="sidebar_menu">\n')
    for line in fp:
        line = line.strip().split('.')[0]
        if line.startswith('+'):
            category = line[1:].strip()
            fw.write('<li><a href="#{category_anchor}">{category_lower}</a></li>'.format(category_anchor=ascii(category).lower().replace(' ', '_'), category_lower=category.lower()) + '\n')
    fw.write('</ul>\n\n')
    fw.write('<!-- Generating categorical Navigation -->\n\n')
    fp.seek(0)
    for line in fp:
        line = line.strip().split('.')[0]
        if 'Script' in line and 'Reversal' not in line:
            continue
        if line.startswith('+'):
            try:
                fw.write(end_str)
            except:
                pass
            category = line[1:].strip()
            fw.write('<section class="row" id="{category_anchor}">\n' \
                     '     <div class="row">\n' \
                     '        <div class="col-xs-12 col-md-12">\n' \
                     '            <h3>{category}</h3>\n' \
                     '            <ul>\n'.format(
                     category_anchor=ascii(category).lower().replace(' ', '_'),
                     category=category))
            end_str = '            </ul>\n' \
                      '        </div>\n' \
                      '    </div>\n' \
                      '    <div class="row"> </div>\n' \
                      '    <div class="row">\n' \
                      '        <div class="col-xs-12 col-md-12">\n' \
                      '            <a href="#" class="btn btn-primary" role="button">Back to Top</a>\n' \
                      '        </div>\n' \
                      '    </div>\n' \
                      '</section> <!-- {category_lower} -->\n\n\n'.format(
                      category_lower=category.lower())
        else:
            term = line.strip()
            fw.write('    '*4 + '<li><a href="category/{term_anchor}.html">{term}</a></li>'.format(term_anchor=ascii(term).lower().replace(' ', '_'), term=term) + '\n')
    fw.write(end_str)
