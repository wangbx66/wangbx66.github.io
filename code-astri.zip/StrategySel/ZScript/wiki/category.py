import re
import os

alpha = re.compile('[^0-9a-zA-Z ]')
blk = re.compile(' +')
paragraph = re.compile('content_under_category')
title = re.compile('term_under_category')
term_id = re.compile('term_id_under_category')
previous_term = re.compile('previous_term')
next_term = re.compile('next_term')

def ascii(s):
    tmp = alpha.sub('', s)
    return blk.sub(' ', tmp.strip())

anchor_query = {}
anchors = ['../index.html']
for idx, line in enumerate(open('handcraft')):
    if not line.startswith('**'):
        continue
    term = line.strip().split('**')[1]
    if term.startswith('END'):
        continue
    anchor = ascii(term).lower().replace(' ', '_') + '.html'
    anchors.append(anchor)
anchors.append('../index.html')
for idx in range(len(anchors)):
    if not (idx==0 or idx==len(anchors)-1):
        anchor_query[anchors[idx]] = (anchors[idx-1], anchors[idx+1])

html = open('category/base.html').read()
active = False
content = ''
for idx, line in enumerate(open('handcraft')):
    if line.startswith('**'):
        if content:
            print(term)
            anchor = ascii(term).lower().replace(' ', '_') + '.html'
            previous, next = anchor_query[anchor]
            with open('category/' + ascii(term).lower().replace(' ', '_') + '.html', 'w') as fw:
                content1 = paragraph.sub(content, html)
                content2 = title.sub(term, content1)
                content3 = term_id.sub(ascii(term).lower().replace(' ', '_'), content2)
                content4 = previous_term.sub(previous, content3)
                content5 = next_term.sub(next, content4)
                fw.write(content5)
        term = line.strip().split('**')[1]
        content = ''
    if line.startswith('$paragraph'):
        active = not active
        continue
    if active:
        content += line
