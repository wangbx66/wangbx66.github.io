1. run generate_html.py and get the index structure in outs (use contents)
2. paste the html in outs into the template, and save it as index.html (use index.html template html/images/js/css)
3. run category.py and get all subpages in category dir (use handcraft and base.html)
4. open index.html with browser
